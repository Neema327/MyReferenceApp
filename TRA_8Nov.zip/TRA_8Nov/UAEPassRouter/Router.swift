//
//  Router.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 12/30/18.
//  Copyright © 2018 Waqas Qadeer Soomro. All rights reserved.
//

import UIKit
import WebKit
@objc public class Router: NSObject {

    @objc public static let shared = Router()
    @objc public var uaePassToken: String!
    @objc public var webView: WKWebView!
    /// private constructor
    public override init() {
        uploadSignDocumentResponse = nil
        uaePassConfig = UAEPassConfigQA()
        webView = WKWebView()
        uaePassToken = ""
    }
    var uaePassConfig: UAEPassConfigProtocol
    var uploadSignDocumentResponse: UploadSignDocumentResponse?

    // MARK: - Signing the document methods -
    func startSigningProcess(uaePassToken: String, signingParams: UAEPAssSigningParameters?, pdfName: String) {
        showLoader(message: "Downloading file to be signed")
        Service.shared.downloadPdf(pdfName: pdfName, uaePassToken: uaePassToken, completion: { (_, _) in
            self.dismissLoader()
            self.showLoader(message: "Getting UAE PASS Token")
            var requestData = UAEPassSigningRequest()
            requestData.serviceType = UAEPassServiceType.token
            requestData.tokenParams = TokenParams.getInitialisedObject()
            requestData.processParams = signingParams
            self.normalUAEPassRequest(requestData: requestData, pdfName: pdfName)
        }, onError: { _ in
            self.dismissLoader()
        })
    }
    func normalUAEPassRequest(requestData: UAEPassSigningRequest, pdfName: String) {
        Service.shared.normalUAEPassRequest(requestData: requestData, completion: { response in
            self.dismissLoader()
            self.showLoader(message: "Uploading document to be signed")
            if response == "DONE" {
                Service.shared.uploadDocument(requestData: requestData, pdfName: pdfName) { response, success in
                    // open the webview
                    self.dismissLoader()
                    if success == true {
                        let document = response?.documents?.first
                        let sss = document?.content ?? ""
                        if let range = sss.range(of: "documents/") {
                            let presentedViewController = UIApplication.topViewController() as? UserProfileViewController
                            presentedViewController?.pdfName = sss[range.upperBound...].trimmingCharacters(in: .whitespaces)
                            let pdfID = response?.documents?[0].content?.slice(from: "documents/", to: "/content") ?? ""
                            presentedViewController?.pdfID = pdfID
                            Router.shared.uploadSignDocumentResponse = response
                            self.loadUAEPASSWebView(stringURL: response?.tasks?.pending?.first?.url ?? "")
                        }
                    } else {
                    }
                }
            }
        }, onError: { error in
            print(error)
        })
    }

    func downloadSignedODF(pdfID: String, pdfName: String) {
        Service.shared.downloadSignedPdf(pdfID: pdfID, pdfName: pdfName, completion: { (_, _) in
            self.dismissLoader()
            let presentedViewController = UIApplication.topViewController() as? UserProfileViewController
            let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let fileURL = URL(fileURLWithPath: documentsPath, isDirectory: true).appendingPathComponent(pdfName)
            presentedViewController?.showPDFFile(fileURL: fileURL)
        }, onError: { _ in
            self.dismissLoader()
        })
    }

    // MARK: - Hide/Show Loader -
    public func showLoader(message: String? = nil) {
        let presentedViewController = UIApplication.topViewController() as? UserProfileViewController
        presentedViewController?.startAnimating(message: message, type: .pacman)
    }
    public func dismissLoader() {
        let presentedViewController = UIApplication.topViewController() as? UserProfileViewController
        presentedViewController?.stopAnimating()
    }

    @objc func loadUAEPASSWebView(stringURL: String) {
        let presentedViewController = UIApplication.topViewController() as? UserProfileViewController
        presentedViewController?.loadUAEPASSWebView(stringURL: stringURL)
    }
}

extension String {
    func slice(from: String, to: String) -> String? {
        return (range(of: from)?.upperBound).flatMap { substringFrom in
            (range(of: to, range: substringFrom..<endIndex)?.lowerBound).map { substringTo in
                String(self[substringFrom..<substringTo])
            }
        }
    }
}
