# UAE Pass Demo App

UAE Pass Demo App is a sample app to show you how to use UAE Pass for :

- App to app login.
- Login with WebView inside the app .. incase if UAE Pass not installed in the same device.
- Getting user profile details.
- Download smaple document.
- Sign donwnloaded document.
- View signed doscument.

# Should do !

- Add your QA client ID and client Pass in UAEPassConfigQA.
- Add your production client ID and client Pass in UAEPassConfigProduction.
- Add UAE Pass scheme in info.plist


# Check !
- testSignData.json is very important file as this is signing info which you should pass to UAE Pass app and it's expected to be recieved from the back end and it's required to be reconfigured to add your own app scheme.

**Smart Dubai, SDDTeam**
