//
//  DVBaseViewController.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/25/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//Test commit

import UIKit

public class DVBaseViewController: UIViewController {

    override public func viewDidLoad() {
        
        let localeCode = DVCommon.currentSelectedLanguage
        DVLocalization.sharedInstance.setLanguage(languageCode: localeCode)
        if localeCode  == "en" {
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
            DVConstants.uaepassArabicLocalization = false
        } else if  localeCode  == "ar" {
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
            DVConstants.uaepassArabicLocalization = true
        }
    }
}
