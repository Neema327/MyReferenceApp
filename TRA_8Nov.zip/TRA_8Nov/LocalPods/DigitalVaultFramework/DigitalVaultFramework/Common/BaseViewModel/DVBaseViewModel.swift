//
//  DVBaseViewModel.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/25/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import Foundation

typealias DVVMProtocols = Loader

class DVBaseViewModel: DVVMProtocols {
}
