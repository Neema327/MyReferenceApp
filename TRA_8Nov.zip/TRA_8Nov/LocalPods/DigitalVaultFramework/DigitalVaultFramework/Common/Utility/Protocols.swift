//
//  Protocols.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/30/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import UIKit

protocol Loader {}

extension Loader {

    func showLoader() {
        if let topViewController = DVCommon.topViewController {
            var activityIndicator: UIActivityIndicatorView = UIActivityIndicatorView()

            activityIndicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
            activityIndicator.center = topViewController.view.center
            activityIndicator.backgroundColor = UIColor(red: 0.16, green: 0.17, blue: 0.21, alpha: 1)
            activityIndicator.layer.cornerRadius = 6
            activityIndicator.center = topViewController.view.center
            activityIndicator.hidesWhenStopped = true
            activityIndicator.style = UIActivityIndicatorView.Style.whiteLarge
            activityIndicator.tag = 100
            topViewController.view.addSubview(activityIndicator)
            activityIndicator.startAnimating()
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }

    func hideLoader() {
        if let topViewController = DVCommon.topViewController {
            let activityIndicator = topViewController.view.viewWithTag(100) as? UIActivityIndicatorView

            activityIndicator?.stopAnimating()
            activityIndicator?.removeFromSuperview()
            UIApplication.shared.endIgnoringInteractionEvents()
        }
    }
}

protocol AlertMessages {}

extension AlertMessages {

    func showAlert(title: String? = nil, message: String?, buttons: [UIAlertAction]? = nil) {
        //show alert
    }
}
