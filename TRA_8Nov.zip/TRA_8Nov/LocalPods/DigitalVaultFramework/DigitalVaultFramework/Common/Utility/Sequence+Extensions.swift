//
//  Sequence+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by Lija George on 12/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

extension Sequence {
    func sorted<T: Comparable>(by keyPath: KeyPath<Element, T>) -> [Element] {
        return sorted { lhs, rhs in
            return lhs[keyPath: keyPath] < rhs[keyPath: keyPath]
        }
    }
}
