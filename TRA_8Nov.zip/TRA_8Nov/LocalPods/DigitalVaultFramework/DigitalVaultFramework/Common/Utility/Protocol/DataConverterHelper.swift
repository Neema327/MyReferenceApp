//
//  DataConverterHelper.swift
//  DigitalVaultApp
//
//  Created by Lija George on 03/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

class DataConverterHelper: DataConverter {

    func prepareData(jsonFile: String, completionHandler: @escaping SuccessDataClosure, failureHandler: @escaping FailureDataClosure) {

        guard let bundle = Bundle.createBundle("DigitalVaultFramework"),
            let path = bundle.path(forResource: jsonFile, ofType: "json") else {
//                print( "Json file path not found")
                return
        }

//        guard let path = Bundle.main.path(forResource: jsonFile, ofType: "json")  else {
//            return
//        }
        do {
            let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
            completionHandler(true, data)
        } catch (let error as NSError) {
            failureHandler(false, error.localizedDescription as? Error)
        }

    }
}
