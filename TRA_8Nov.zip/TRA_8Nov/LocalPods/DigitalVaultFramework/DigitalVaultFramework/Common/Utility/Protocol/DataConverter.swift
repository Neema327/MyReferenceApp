//
//  DataConverter.swift
//  DigitalVaultApp
//
//  Created by Lija George on 03/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

protocol DataConverter {
    func prepareData(jsonFile: String, completionHandler: @escaping SuccessDataClosure,
                          failureHandler: @escaping FailureDataClosure)
}
