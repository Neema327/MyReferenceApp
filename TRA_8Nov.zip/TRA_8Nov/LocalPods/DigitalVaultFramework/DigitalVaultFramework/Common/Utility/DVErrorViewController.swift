//
//  DVErrorViewController.swift
//  DigitalVaultFramework
//
//  Created by Saiaswanth on 8/18/19.
//

import UIKit

class DVErrorViewController: UIViewController {

    @IBOutlet weak var errorView: UIView!
    @IBOutlet weak var errorTitleLabel: UILabel!
    @IBOutlet weak var errorImageView: UIImageView!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var retryButton: UIButton!

    private var okHandler: (() -> Void)?
    private var retryHandler: (() -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()

    }

//    func updateUI(with title: String, image: UIImage, andRetry needed: Bool) {
//
//        errorView.setViewsLayer(layer: errorView.layer, shouldLayerBorderClearColor: false)
//
//        okButton.setTitle(DVConstants.ButtonTitles.Error_Ok, for: .normal)
//        retryButton.setTitle(DVConstants.ButtonTitles.Error_Retry, for: .normal)
//
//        errorTitleLabel.text = title
//        errorImageView.image = image
//        retryButton.isHidden = !needed
//    }

    func updateUI(with title: String, image: UIImage?, retryNeeded: Bool, cancelNeeded: Bool, okHandler: @escaping DVErrorOkClosure, retryHandler: @escaping DVErrorRetryClosure) {

        self.okHandler = okHandler
        self.retryHandler = retryHandler

        errorView.setViewsLayer(layer: errorView.layer, shouldLayerBorderClearColor: false)
        errorView.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)

        okButton.setTitle(DVConstants.ButtonTitles.errorOk, for: .normal)
        retryButton.setTitle(DVConstants.ButtonTitles.errorRetry, for: .normal)
        retryButton.isHidden = true
        errorTitleLabel.text = title

        if cancelNeeded || retryNeeded {
            retryButton.isHidden = false
        }

        if cancelNeeded {
            retryButton.setTitle(DVConstants.ButtonTitles.errorCancel, for: .normal)
        }

        if let errorImage = image {
            errorImageView.image = errorImage
            errorImageView.isHidden = false
        } else {
            errorImageView.isHidden = true
        }

    }

    @IBAction func okButtonTapped(_ sender: Any) {

        if let okHandler = okHandler {
            okHandler()
        }
    }

    @IBAction func retryButtonTapped(_ sender: Any) {

        if let retryHandler = retryHandler {
            retryHandler()
        }
    }
}
