//
//  UIAlertController+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by Lija George on 16/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

extension UIAlertController {
    static func sortOptionsActionSheet() -> UIAlertController {
        let sortOptionActionSheet = UIAlertController(title: nil, message: "", preferredStyle: .actionSheet)
        let boldFont = UIFont.systemFont(ofSize: 20, weight: UIFont.Weight.bold)
        let attributedString = NSAttributedString(string: DVLocalization.sharedInstance.localize(string: sortTitle), attributes: [
            NSAttributedString.Key.font: boldFont,
            NSAttributedString.Key.foregroundColor: UIColor(hexString: SortOptionsHex.alertMessage.rawValue)])
        sortOptionActionSheet.setValue(attributedString, forKey: "attributedMessage")
        return sortOptionActionSheet
    }

    // Showing Alert with Title and Message
    static func showAlertWith(title: String, message: String) -> UIAlertController {
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(
            title: "OK",
            style: .default, handler: nil))
        return alertVC
    }
}
