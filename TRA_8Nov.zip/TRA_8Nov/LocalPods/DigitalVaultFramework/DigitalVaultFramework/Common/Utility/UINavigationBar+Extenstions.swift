//
//  UINavigationBar+Extenstions.swift
//  SampleAppForDV
//
//  Created by Lija George on 09/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

//Extension for Navigation bar
extension UINavigationBar {
//    static func applyNavBarStyle () {
////        UINavigationBar.appearance().barTintColor = UIColor.init(patternImage: UIImage(named:"top-header-bg"),
//        
////        let topHeaderImage = UIImage(contentsOfFile:DVCommon.digitalVaultResourceBundlePath + "top-header-bg.png")
////        self.view.backgroundColor = UIColor(patternImage: bgImage!)
////        let img = UIImage(named: "top-header-bg")
//        let img = DVCommon.getImage(named: "top-header-bg.png")
//        UINavigationBar.appearance().tintColor = .white
//        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
//        UINavigationBar.appearance().shadowImage = UIImage()
//        UINavigationBar.appearance().setBackgroundImage(img, for: .default)
//        UINavigationBar.appearance().isTranslucent = false
//    }
}
