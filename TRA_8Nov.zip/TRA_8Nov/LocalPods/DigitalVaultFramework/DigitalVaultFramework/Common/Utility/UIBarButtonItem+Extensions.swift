//
//  UIBarButtonItem+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by Lija George on 19/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit
extension UIBarButtonItem {
    static func button(image: UIImage, title: String, target: Any, action: Selector) -> UIBarButtonItem {
        let button = UIButton()
        button.setImage(image, for: .normal)
       // button.addTarget(target, action: action, for: .touchUpInside)
        button.setTitle(title, for: .normal)
        button.sizeToFit()
        return UIBarButtonItem(customView: button)
    }
}
