//
//  UISearchBar+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 11/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import  UIKit
//
//extension UISearchBar {
//        func searchBarWithColor(color: UIColor) {
//            let searchImg = DVCommon.getImage(named: "search-bg.png")//UIImage(named: "search-bg")
//            let crossImg = DVCommon.getImage(named: "close.png")//UIImage(named: "close")
//            self.setBackgroundImage(searchImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .any, barMetrics: UIBarMetrics.default)
//            let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
//            textFieldInsideSearchBar?.backgroundColor = UIColor.clear
//            if DVConstants.uaepassArabicLocalization {
//               textFieldInsideSearchBar?.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)
//                self.semanticContentAttribute = .forceRightToLeft
//            }
//            let glassIconView = textFieldInsideSearchBar?.leftView as? UIImageView
//            glassIconView?.image = glassIconView?.image?.withRenderingMode(.alwaysTemplate)
//            let crossIconView = textFieldInsideSearchBar?.value(forKey: "_clearButton") as? UIButton
//            crossIconView?.setImage(crossImg, for: .normal)
//            textFieldInsideSearchBar?.textColor = color
//            let textFieldInsideSearchBarLabel = textFieldInsideSearchBar!.value(forKey: "placeholderLabel") as? UILabel
//            glassIconView?.tintColor = color
//            crossIconView?.tintColor = color
//            textFieldInsideSearchBarLabel?.textColor = color
//    }
//}
