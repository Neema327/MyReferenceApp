//
//  DVLocalization.swift
//  DigitalVaultFramework
//
//  Created by MSP on 28/09/19.
//
import Foundation
import UIKit

class DVLocalization:NSObject {
    
    var selectedBundle: Bundle!
    public static let sharedInstance = DVLocalization()
    
    override init() {
        super.init()
        selectedBundle = Bundle.main
    }
    
    func localizedStringForKey(key:String, comment:String) -> String {
        return selectedBundle.localizedString(forKey: key, value: comment, table: nil)
    }
    
    func localize(string: String) -> String {
        return selectedBundle.localizedString(forKey: string, value: string, table: nil)
    }
    
    func localizedImagePathForImage(imagename:String, type:String) -> String {
        guard let imagePath =  selectedBundle.path(forResource: imagename, ofType: type) else {
            return ""
        }
        return imagePath
    }
    
    func setLanguage(languageCode:String) {
        
        guard let bundle = Bundle.createBundle("DigitalVaultFramework"),
            let _ = bundle.path(forResource: "DigitalVault", ofType: "bundle") else {
//                print( "DigitalVault not found")
                return
        }
       if let languageDirectoryPath = bundle.path(forResource: languageCode, ofType: "lproj") {
            selectedBundle = Bundle.init(path: languageDirectoryPath)
        } else {
            resetLocalization()
        }
    }
    
    func resetLocalization() {
        guard let bundle = Bundle.createBundle("DigitalVaultFramework"),
            let _ = bundle.path(forResource: "DigitalVault", ofType: "bundle") else {
//                print( "DigitalVault not found")
                return
        }
        selectedBundle = bundle
    }
}
