//
//  UIFont+Extensions.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 01/10/19.
//

import Foundation

extension UIFont {
    public class func loadAllFonts() {
        
        registerFont(with: "Dubai-Bold.ttf")
        registerFont(with: "Dubai-Light.ttf")
        registerFont(with: "Dubai-Medium.ttf")
        registerFont(with: "Dubai-Regular.ttf")
        registerFont(with: "GE-SS-Two-Bold.otf")
        registerFont(with: "GE-SS-Two-Light.otf")
        registerFont(with: "GE-SS-Two-Medium.otf")
    }
 
    static func registerFont(with filenameString: String) {
        
        let pathForResourceString = DVCommon.digitalVaultResourceBundlePath + filenameString
        if let fontData = NSData(contentsOfFile: pathForResourceString) {
            if let dataProvider = CGDataProvider(data: fontData) {
                if let fontRef = CGFont(dataProvider) {
                    var errorRef: Unmanaged<CFError>? = nil
                    if (CTFontManagerRegisterGraphicsFont(fontRef, &errorRef) == false) {
                        NSLog("Failed to register font - register graphics font failed - this font may have already been registered in the main bundle.")
                    }
                }
            }
        }
    }
}
