//
//  UIView+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 11/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

extension UIView {

    func setViewsLayer(layer: CALayer, shouldLayerBorderClearColor: Bool) {
        layer.borderWidth = 0.5
        layer.cornerRadius = 15.0

        if shouldLayerBorderClearColor {
            layer.borderColor = UIColor.clear.cgColor
        } else {
            layer.borderColor = UIColor.lightGray.cgColor
        }

    }
    func setUpRoundedCornerView(view: UIView) {
        (view is UITableView) ?  (view.layer.masksToBounds = true) :  (view.layer.masksToBounds = false)
        view.backgroundColor = UIColor.white
        view.layer.shadowOffset = CGSize(width: 0, height: 4)
        view.layer.shadowRadius = 16.0
        view.layer.shadowOpacity = 0.08
        view.layer.cornerRadius = 12.0
        view.layer.shadowColor = UIColor.colorFromHex(rgbValue: 0xAA68F).cgColor

    }

    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
        layer.borderColor = UIColor.lightGray.cgColor
    }
}
