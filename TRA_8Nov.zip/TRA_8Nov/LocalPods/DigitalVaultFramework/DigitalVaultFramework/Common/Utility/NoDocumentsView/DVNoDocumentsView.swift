//
//  NoDocumentsView.swift
//  Alamofire
//
//  Created by Neema Naidu on 29/08/19.
//

import UIKit

class DVNoDocumentsView: UIView {
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
