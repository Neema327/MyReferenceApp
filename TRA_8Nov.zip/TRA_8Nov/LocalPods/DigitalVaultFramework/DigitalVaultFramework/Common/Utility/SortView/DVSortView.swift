//
//  DVSortView.swift
//  DigitalVaultFramework
//
//  Created by Neema Naidu on 27/08/19.
//

import UIKit
protocol DVSortViewDelegate: class {
    func displaySortDetailView(categoryStr: String)
    func cancelAction()
}
class DVSortView: UIView {

    @IBOutlet weak var containerViewTitleLabel: UILabel!
    @IBOutlet weak var containerViewCancelButton: UIButton!
    @IBOutlet weak var documentCategoryTableView: UITableView!
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    weak var delegate: DVSortViewDelegate?

    var categoryList: [String]?

    override func awakeFromNib() {
        super.awakeFromNib()
//        registerCellWithIdentifier("DVCategoryCell")
        UITableView.registerCellWithIdentifier(cellIdentifier: "DVCategoryCell", tblVw: documentCategoryTableView)

    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    func numberOfRows() -> NSInteger {
       return categoryList?.count ?? 0
    }
    @IBAction func cancelBtnTapped(_ sender: Any) {
        self.delegate?.cancelAction()
    }
    func configureSortView(windowFrame: UIView) {
        if DVConstants.uaepassArabicLocalization {
            containerViewTitleLabel.font = UIFont(name: ArabicFont.bold.rawValue, size: 20.0)
            containerViewCancelButton.titleLabel?.font = UIFont(name: ArabicFont.regular.rawValue, size: 20.0)
        }
        var viewHeight: CGFloat = 0
        tableViewHeightConstraint.constant = CGFloat(70 * (numberOfRows()))
        if numberOfRows() <= 2 {
            viewHeight = containerViewTitleLabel.frame.size.height + containerViewCancelButton.frame.size.height + 20 + CGFloat(70 * (categoryList?.count ?? 0))
            documentCategoryTableView.isScrollEnabled = false
        } else {
            viewHeight = containerViewTitleLabel.frame.size.height + containerViewCancelButton.frame.size.height + 20 + CGFloat(70 * 2)
            documentCategoryTableView.isScrollEnabled = true
        }
        frame = CGRect(x: 0, y: windowFrame.frame.height - viewHeight, width: windowFrame.frame.size.width, height: viewHeight)
        containerViewTitleLabel.text = Documents.sortBy
        containerViewCancelButton.setTitle(Documents.cancelButtonTitle, for: .normal)
//        self.setViewsLayer(layer: self.layer, shouldLayerBorderClearColor: false)
        self.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)
    }
}

extension DVSortView: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let catList = categoryList {
           self.delegate?.displaySortDetailView(categoryStr: catList[indexPath.row])
        }
    }
}

extension DVSortView: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfRows()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let categoryCell = tableView.dequeueReusableCell(withIdentifier: "DVCategoryCell", for: indexPath)
        categoryCell.selectionStyle = UITableViewCell.SelectionStyle.none
        if DVConstants.uaepassArabicLocalization {
           categoryCell.textLabel?.font = UIFont(name: ArabicFont.regular.rawValue, size: 20.0)
        }
        if let catList = categoryList {
            categoryCell.textLabel?.text = catList[indexPath.row]
        }
        return categoryCell
    }
}
