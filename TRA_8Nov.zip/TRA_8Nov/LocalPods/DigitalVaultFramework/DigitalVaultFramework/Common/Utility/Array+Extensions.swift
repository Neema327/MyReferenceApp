//
//  Array+Extensions.swift
//  DigitalVaultAppSample
//
//  Created by Lija George on 12/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

extension Array {
    func propertySorted<T: Comparable>(_ property: (Element) -> T, sortOrder: Int) -> [Element] {
        if sortOrder == 0 {//asc
            return sorted(by: {property($0) < property($1)})
        } else {
            return sorted(by: {property($0) > property($1)})
        }
    }

    func unique<T: Hashable>(map: ((Element) -> (T))) -> [Element] {
        var set = Set<T>()
        var arrayOrdered = [Element]()
        for value in self {
            if !set.contains(map(value)) {
                set.insert(map(value))
                arrayOrdered.append(value)
            }
        }
        return arrayOrdered
    }
}
