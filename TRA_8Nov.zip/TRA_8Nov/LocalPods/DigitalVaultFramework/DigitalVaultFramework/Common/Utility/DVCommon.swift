//
//  DVCommon.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/30/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import Foundation
import UIKit
import WebKit
import Kingfisher
import PromiseKit

struct DVCommon {
    static let errorViewController = DVErrorViewController(nibName: "DVErrorViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
    static let window = UIApplication.shared.keyWindow

    static var authToken: String?
    static var presentmentToken: String?
    static var accessToken: String?
    static var currentSelectedLanguage: String = "en"

    static var bearerToken = "Bearer "
    static var token = "UAEPassToken"
    static let maxOfficialDocsPage = 2
    static let maxUnOfficialDocsPage = 2
    static var isSignFlowFromDocuments = false
    static var isPresentmentAppToAppFlow = false
    static var digitalVaultResourceBundlePath: String {
        guard let bundle = Bundle.createBundle("DigitalVaultFramework"),
            let mainBundlePath = bundle.path(forResource: "DigitalVault", ofType: "bundle") else {
//               print( "DigitalVault not found")
                return ""
        }

        return mainBundlePath + "/"
    }

    static let topViewController = UIApplication.topMostViewController()

    static func getLanguage() -> String {
        if let appleLanguages = UserDefaults.standard.object(forKey: "AppleLanguages") as? [String] {
            let prefferedLanguage = appleLanguages[0]
            if prefferedLanguage.contains("-") {
                let array = prefferedLanguage.components(separatedBy: "-")
                return array[0]
            }
            return prefferedLanguage

        }
        return ""
    }

    static func decodeResponse<T: Codable>(type: T.Type ,respData:Data?, errorData: Error?,decodeOpt:DecodeOption) -> Promise<Any> {
        return Promise {  seal in
            if let rsData = respData {//If json is available
                if let respError =  errorData {//If error ! = nil
                        seal.reject(respError)
                } else {
                    do {
                        
                        switch decodeOpt {
                        case .model:
                            let model = try JSONDecoder().decode(T.self, from: rsData)
                            seal.fulfill(model)
                        case .data:
                            seal.fulfill(rsData)
                        case .html:
                            seal.fulfill(rsData)
                        case .jsonString:
                            seal.fulfill(rsData)
                        case .put:
                            seal.fulfill(rsData)
                        case .unReadCount:
                            seal.fulfill(rsData)
                        }
                        
                    } catch {
                        let error = NSError(domain: dvErrorDomain, code: DVStatusCode.messageExtractionError.rawValue, userInfo: [dvServerErrorKey:  dvMessageExtractError])
                        seal.reject(error)
                    }
                }
            } else if let error = errorData  as NSError? {
//                print(error)
                seal.reject(error)
            } else {
                let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
                seal.reject(error)
            }
        }
    }
    static func localize(string inputString: String) -> String {
       let localizedText = DVLocalization.sharedInstance.selectedBundle.localizedString(forKey: inputString, value:inputString , table:"" )
        return localizedText
        //return NSLocalizedString(inputString, comment: inputString)
    }

    static func getImage(named imageName: String) -> UIImage {
        if let requiredImage = UIImage(contentsOfFile: digitalVaultResourceBundlePath + imageName) {
            return requiredImage
        }
        return UIImage()
    }

    static func getDVBundle() -> Bundle? {
        return Bundle.createBundle("DigitalVaultFramework")
    }

//    static func getErrorMesg(error serviceError: Error) -> DVError {
//        let servError = serviceError as NSError
//        let serviceError =
//            NSError(domain: servError.domain,
//                    code: servError.code,
//                    userInfo: [
//                        NSLocalizedDescriptionKey: "Error_406",
//                        NSLocalizedFailureReasonErrorKey: "",
//                        NSLocalizedRecoverySuggestionErrorKey: ""
//                ])
//        if let dvServiceError = serviceError as? DVError{
//            return serviceError as! DVError
//        }
//        //return serviceError as! DVError
//    }

    static func showError(serviceError: Error, withSuccess okHandler: (() -> Void)?, andFailure retryHandler: (() -> Void)?) {
       let error =  serviceError as NSError
        var errorMessage = ""
        if let errorString = error.userInfo[dvServerErrorKey] as? String {
            errorMessage = errorString
        } else {
            errorMessage = dvServerErrorMessage
        }
//       let errorCode = error.code
//        var imageName = "test err msg"
//        var errorMessage = "test err msg"
//        var servErr = DVStatusCode.badRequest
//
//        if(errorCode == DVStatusCode.badRequest.rawValue || errorCode == DVStatusCode.infoRequired.rawValue || errorCode == DVStatusCode.notFound.rawValue) {
//            imageName = "Error_\(error.code).png"
//            servErr = DVStatusCode(rawValue: errorCode)!
//        } else if errorCode == 1000 {
//           imageName = "Error_500.png"
//            errorMessage = "test err msg"
//           servErr = DVStatusCode(rawValue: 1000)! //
//        } else {
//            imageName = "Error_500.png"
//            errorMessage = "test err msg"
//            servErr = DVStatusCode(rawValue: DVStatusCode.serverError.rawValue)!
//        }
//
//        errorMessage = serviceErrorMesg[servErr] ?? ServerError.generic
//        //let errorImage = DVCommon.getImage(named: imageName)
            self.showErrorView(with: errorMessage, image: nil, retryNeeded: false, cancelNeeded: false, okHandler: {
            
            if let successHandler = okHandler, isPresentmentAppToAppFlow {
                successHandler()
            }
            DispatchQueue.main.async {
                self.removeErrorView()
            }
        }, retryHandler: {
        })
    }

    static func showErrorView(with title: String, image: UIImage?, retryNeeded: Bool, cancelNeeded: Bool, okHandler: @escaping DVErrorOkClosure, retryHandler: @escaping DVErrorRetryClosure) {

        errorViewController.loadView()
        errorViewController.updateUI(with: title, image: image, retryNeeded: retryNeeded, cancelNeeded: cancelNeeded, okHandler: okHandler, retryHandler: retryHandler)

        errorViewController.view.frame = (window?.rootViewController?.view.bounds)!
        errorViewController.view.tag = 101

        window?.rootViewController?.addChild(errorViewController)
        window?.addSubview(errorViewController.view)
    }

    static func removeErrorView() {
        window?.viewWithTag(101)?.removeFromSuperview()
        errorViewController.removeFromParent()
    }

    static func displayActivityIndicatorView(with message: String) {
        DVEventHandler.sharedInstance.showOrHideLoader(with: true, and: message)
    }
    static func hideActivityIndicatorView() {
        DVEventHandler.sharedInstance.showOrHideLoader(with: false, and: "")
    }
    
//    static func getDeviceLanguage()->String{
////        guard let bundle = Bundle.createBundle("DigitalVaultFramework"),
////            let _ = bundle.path(forResource: "DigitalVault", ofType: "bundle") else {
////                print( "DigitalVault not found")
////                return ""
////        }
////
////        let deviceLang = bundle.localizedString(forKey: "Language", value:"Language" , table:"" )
////        return deviceLang
//        return DVLocalization.sharedInstance.getDeviceLanguage()
//
//    }

}

extension KingfisherManager {
    class func clearCache() {
        KingfisherManager.shared.cache.cleanExpiredMemoryCache()
        KingfisherManager.shared.cache.cleanExpiredDiskCache()
    }
}

extension Data {

    var utf8String: String? {
        return string(as: .utf8)
    }

    func string(as encoding: String.Encoding) -> String? {
        return String(data: self, encoding: encoding)
    }
}

extension WKWebView {
    class func clean() {
        guard #available(iOS 9.0, *) else {return}
        HTTPCookieStorage.shared.removeCookies(since: Date.distantPast)
        WKWebsiteDataStore.default().fetchDataRecords(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes()) { records in
            records.forEach { record in
                WKWebsiteDataStore.default().removeData(ofTypes: record.dataTypes, for: [record], completionHandler: {})
            }
        }
    }
}

extension UITableView {
    class func registerCellWithIdentifier(cellIdentifier: String, tblVw: UITableView) {
        guard let bundle = Bundle.createBundle("DigitalVaultFramework") as Bundle? else {
            fatalError("DigitalVaultFramework bundle not found")
        }
        let cellNib = UINib(nibName: cellIdentifier, bundle: bundle)
        tblVw.register(cellNib, forCellReuseIdentifier: cellIdentifier)
    }
}
extension UIButton {
    class func centerTextAndImage(spacing: CGFloat, button: UIButton) {
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: spacing)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: spacing, bottom: 0, right: 0)
    }

}
