//
//  DVLocalizedError.swift
//  Pods
//
//  Created by MSP on 23/08/19.
//

import Foundation

protocol DVLocalizedError: Error {
    var errorDescription: String? { get }
}

enum DVError {
    case serviceError(Int)
    case networkError(Int)
    case frameworkError(Int)
}

enum DVStatusCode: Int {
    case success            = 200
    case authCode           = 204
    case badRequest         = 400
    case loginFailed        = 401
    case infoRequired       = 402
    case userDisabled       = 403
    case notFound           = 404
    case methodNotAllowed   = 405
    case notAcceptable      = 406
    case serverError        = 500
    case noConnection       = -1009
    case timeOutError       = -1001
    case fileWriteFailedError    = 1000
    case messageExtractionError = 1001
    case authenticationError = 1002
}

extension DVError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .serviceError(let errorCode):
            return "code is (\(errorCode))"
        case .networkError(let errorCode):
               return "nw error code is (\(errorCode))"
            default: return ""
        }
    }

    var failureReason: String? {
        switch self {
        case .serviceError:
            return "failure Reason."
        default: return ""
        }

    }

    var recoverySuggestion: String? {
        switch self {
        case .serviceError:
            return "recoverySuggestion"
            default: return ""
        }
    }
}
