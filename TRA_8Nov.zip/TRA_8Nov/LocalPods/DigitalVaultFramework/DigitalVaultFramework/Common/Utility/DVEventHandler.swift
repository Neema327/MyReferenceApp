//
//  EventHandler.swift
//  Alamofire
//
//  Created by Saiaswanth on 7/9/19.
//

import Foundation
import SwiftEventBus
import IQKeyboardManagerSwift
import Kingfisher

enum DVModules: Int {
    case request = 1
    case notification
    case documents
    case myQRCode
    case selfSign
}

enum DVFrameworkAPI: Int {
    case notificationCount = 1
}

public class DVEventHandler {
    
    public static let sharedInstance = DVEventHandler()
    var accessToken: String? = ""
    let semaphore = DispatchSemaphore(value: 0)
    init() {
        IQKeyboardManager.shared.enable = true
    }
    
    func setImageCacheExpiryDays() {
        let cache  = ImageCache.default
        cache.memoryStorage.config.expiration = .days(cacheExpiryInDays)
        cache.diskStorage.config.expiration = .days(cacheExpiryInDays)
    }
    
    open func loadEventHandler() {
        setImageCacheExpiryDays()
        loadDVModule()
        pinConfirmationStatus()
        storeToVaultRequest()
        getRenewedUAEPassAccessToken()
        fetchNotificationUnreadCount()
        launchPresentmentDetails()
        UIFont.loadAllFonts() //Sai need to check where we have to call in the integrated code
    }
    
    // Swiftbus event for loading modules
    private func loadDVModule() {
        
        SwiftEventBus.onMainThread(self, name: "DV_LoadModule") { result in
            
            if let result = result,
                let moduleDictionary = result.userInfo,
                let currentLanguage = moduleDictionary["currentLanguage"] as? String,
                let moduleId = moduleDictionary["moduleId"] as? Int {
                
                var viewControllerIdentifier = ""
                var storyboardName = ""
                
                DVCommon.currentSelectedLanguage = currentLanguage
                DVCommon.isPresentmentAppToAppFlow = false
                
                self.setAuthToken(moduleDictionary: moduleDictionary)
                
                if let module = DVModules(rawValue: moduleId) {
                    
                    switch module {
                    case .request:
                        if let uaePassNavigationController = moduleDictionary["navigationController"] as? UINavigationController {
                            let requestCredentialViewController = DVIssuersListViewController(nibName: "DVIssuersListViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
                            requestCredentialViewController.isFromHome = true
                            uaePassNavigationController.pushViewController(requestCredentialViewController, animated: true)
                        }
                        
                    case .notification:
                        let notificationListViewController = DVNotificationsListViewController(nibName: "DVNotificationsListViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
                        if let uaePassNavigationController = moduleDictionary["navigationController"] as? UINavigationController {
                            uaePassNavigationController.pushViewController(notificationListViewController, animated: true)
                        }
                        
                        //Sai: Uncomment during integration
                        if DVConstants.uaepassIntegerationEnabled && !DVConstants.uaepassDemoIntegration {
                            var viewDictionary = [String: Any]()
                            viewDictionary["viewController"] = notificationListViewController
                            notificationListViewController.loadViewIfNeeded()
                            SwiftEventBus.post("UP_LoadNotificationView", userInfo: viewDictionary)
                        }
                    case .documents:
                        
                        let issuedCredentialViewController = DVDocumentsViewController(nibName: "DVDocumentsViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
                        issuedCredentialViewController.isDocumentSelectionFlow = false
                        if let uaePassNavigationController = moduleDictionary["navigationController"] as? UINavigationController {
                            uaePassNavigationController.pushViewController(issuedCredentialViewController, animated: true)
                        }
                        
                        //Sai: Uncomment during integration
                        if DVConstants.uaepassIntegerationEnabled && !DVConstants.uaepassDemoIntegration {
                            var viewDictionary = [String: Any]()
                            viewDictionary["viewController"] = issuedCredentialViewController
                            SwiftEventBus.post("UP_LoadDocumentsView", userInfo: viewDictionary)
                        }
                    case .myQRCode:
                        if let uaePassNavigationController = moduleDictionary["navigationController"] as? UINavigationController {
                            viewControllerIdentifier = "MyQRCodeViewController"
                            storyboardName = "DVMyQRCode"
                            let viewController = UIStoryboard(name: storyboardName, bundle: Bundle.createBundle("DigitalVaultFramework")).instantiateViewController(withIdentifier: viewControllerIdentifier)
                            uaePassNavigationController.pushViewController(viewController, animated: true)
                        }
                        
                    case .selfSign: break
//                        print("Self sign selected")
                    }
                }
            }
        }
    }
    
    private func setAuthToken(moduleDictionary: [AnyHashable : Any]) {
        
        if let currentAccessToken = moduleDictionary["accessToken"] as? String, DVConstants.uaepassIntegerationEnabled {
            DVCommon.accessToken = currentAccessToken
            DVCommon.authToken = "accessToken " + currentAccessToken
        }
        
        if !DVConstants.uaepassAccessTokenIntegration {
            if let emiratesId =  moduleDictionary["emiratesId"] as? String {
                DVCommon.authToken = "accessToken " + emiratesId
            } else {
                DVCommon.authToken = "accessToken " + "784198906873744"
            }
        }
    }
    
    // Sending EventBus event to UAEPass to sign url
    func sign(url: String, wihtLoader message: String) {
        
        var signUrlDictionary = [String: String]()
        signUrlDictionary["url"] = url
        signUrlDictionary["loaderMessage"] = message
        SwiftEventBus.post("UP_SignUrl", userInfo: signUrlDictionary)
    }
    
    // Sending EventBus event to UAEPass to launch sign screen
    func launchSignScreen() {
        
        var signFlowDictionary = [String: Any]()
        signFlowDictionary["status"] = DVCommon.isSignFlowFromDocuments
        SwiftEventBus.post("UP_LaunchSignScreen", userInfo: signFlowDictionary)
    }
    
    //Sending EventBus event to UAEPass for showing an alert
    func showAlert(with message: String) {
        
        var alertDictionary = [String: String]()
        alertDictionary["message"] = message
        SwiftEventBus.post("UP_DisplayAlert", userInfo: alertDictionary)
    }
    
    // Sending Eventbus event to UAEPAss for showing or hiding activity indicator
    func showOrHideLoader(with status: Bool, and message: String) {
        
        var loaderDictionary = [String: Any]()
        loaderDictionary["status"] = status
        loaderDictionary["message"] = message
        
        SwiftEventBus.post("UP_ShowOrHideActivityIndicator", userInfo: loaderDictionary)
    }
    
    //Sending EventBus event to UAEPass for launching Pin Screen
    func showPinScreen() {
        
        SwiftEventBus.post("UP_ShowPinScreen")
    }
    
    func getRenewedAccessToken() -> String? {
        accessToken = ""
        SwiftEventBus.post("UP_GetRenewedAccessToken")
        let timeout = DispatchTime.now() + .seconds(60)
        
        if semaphore.wait(timeout: timeout) == .timedOut {
            return ""
        }
        return self.accessToken
    }
    
    // For de-registering eventbus events related to target
    func deRegisterEventBusEvent(for target: AnyObject) {
        
        SwiftEventBus.unregister(target)
    }
    
    //Sending EventBus event to UAE Pass to send the store to vault response
    func postStoreToVaultResponse() {
        SwiftEventBus.post("UP_StoreToVaultResponse")
    }
    
    //For downloading document from UAE Pass
    func downloadDocument(with fileName: String) {
        
        var dowloadDocumentDictionary = [String: Any]()
        dowloadDocumentDictionary["fileName"] = fileName
        
        SwiftEventBus.post("UP_DownloadDocument", userInfo: dowloadDocumentDictionary)
    }
    
    // For getting notification count
    func getNotificationCount() {
        
        let notificationListViewModel = DVNotificationListViewModel()
        notificationListViewModel.getUnreadNotificationCount().done({ [weak self] (notificationCount) in
            
            if let notificationUnreadCount = notificationCount as? Int {
                self?.postNotificationUnreadStatus(with: notificationUnreadCount)
            }
        })
    }
    
    //Sending EventBus event to UAE Pass for posting unread notification count
    private func postNotificationUnreadStatus(with count: Int) {
        
        var notificationUnreadCountDictionary = [String: Any]()
        
        notificationUnreadCountDictionary["count"] = count
        SwiftEventBus.post("UP_NotificationUnreadCount", userInfo: notificationUnreadCountDictionary)
    }
    
    //For loading store to documents screen
    private func storeToVaultRequest() {
        
        SwiftEventBus.onMainThread(self, name: "DV_StoreToVaultRequest") { result in
            
            if let result = result,
                let storeToVaultDictionary = result.userInfo,
                let currentLanguage = storeToVaultDictionary["currentLanguage"] as? String,
                let isSignFlowFromDocuments = storeToVaultDictionary["isSignFlowFromDocuments"] as? Bool,
                let signedDocumentUrl = storeToVaultDictionary["documentUrl"] as? String, let uaePassViewController = storeToVaultDictionary["currentViewController"] as? UIViewController {
                
                DVCommon.isSignFlowFromDocuments = isSignFlowFromDocuments
                DVCommon.currentSelectedLanguage = currentLanguage
                DVCommon.isPresentmentAppToAppFlow = false
                
                if let currentAccessToken = storeToVaultDictionary["accessToken"] as? String, DVConstants.uaepassIntegerationEnabled {
                    DVCommon.accessToken = currentAccessToken
                    DVCommon.authToken = "accessToken " + currentAccessToken
                }
                
                if !DVConstants.uaepassAccessTokenIntegration {
                    if let emiratesId =  storeToVaultDictionary["emiratesId"] as? String {
                        DVCommon.authToken = "accessToken " + emiratesId
                    } else {
                        DVCommon.authToken = "accessToken " + "784198906873744"
                    }
                }
                
                let documentUrl = signedDocumentUrl
                let uaePassViewController = uaePassViewController
                
                let viewController = UIStoryboard(name: "DVStoreToVault", bundle: Bundle.createBundle("DigitalVaultFramework")).instantiateViewController(withIdentifier: "DVStoreToVaultViewController")
                
                if let storeToVaultViewController = viewController as? DVStoreToVaultViewController {
                    
                    storeToVaultViewController.documentUrl = documentUrl
                    
                    storeToVaultViewController.view.frame = uaePassViewController.view.bounds
                    uaePassViewController.addChild(storeToVaultViewController)
                    uaePassViewController.view.addSubview(storeToVaultViewController.view)
                }
            }
        }
    }
    
    // For fetching unread notification count
    private func fetchNotificationUnreadCount() {
        
        SwiftEventBus.onMainThread(self, name: "DV_FetchNotificationCount") { [weak self] result in
            SwiftEventBus.postToMainThread("DV_UpdateNotificationList")
            if let result = result,
                let notificationUnreadCountDictionary = result.userInfo {
                self?.getNotificationCount()
                
//                if let currentAccessToken = notificationUnreadCountDictionary["accessToken"] as? String, DVConstants.uaepassIntegerationEnabled {
//                    DVCommon.accessToken = currentAccessToken
//                    DVCommon.authToken = "accessToken " + currentAccessToken
//                }
//
//                if !DVConstants.uaepassAccessTokenIntegration {
//                    if let emiratesId =  notificationUnreadCountDictionary["emiratesId"] as? String {
//                        DVCommon.authToken = "accessToken " + emiratesId
//                    } else {
//                        DVCommon.authToken = "accessToken " + "784198906873744"
//                    }
//                }
                
            }
        }
    }
    
    //For confirmation screen status from UAEPass screen
    private func pinConfirmationStatus() {
        
        SwiftEventBus.onMainThread(self, name: "DV_PinConfirmation") { _ in
            
            //            if let result = result, let pinConfirmationStatusDict = result.userInfo, let pinConfirmationStatus = pinConfirmationStatusDict["status"] {
            //               // print("Pin confirmation status: \(pinConfirmationStatus)")
            //            }
        }
    }
    
    //Sending EventBus event to UAE Pass for setting External operation resolver
    func startUAEPassOperationsResolving() {
        SwiftEventBus.post("UP_startOperationsResolving")
    }
    
    func stopUAEPassOperationResolving() {
        SwiftEventBus.post("UP_stopOperationsResolving")
    }
    
    //For renewed token from UAE Pass
    private func getRenewedUAEPassAccessToken() {
        
        SwiftEventBus.onBackgroundThread(self, name: "DV_GetRenewedAccessToken") { result in
            
            if let result = result, let accessTokenResponseDictionary = result.userInfo,
                let renewedAccessToken = accessTokenResponseDictionary["accessToken"] as? String {
//                print("DV getRenewedUAEPassAccessToken\(renewedAccessToken)")
                self.accessToken = renewedAccessToken
                self.semaphore.signal()
            } else {
                self.accessToken = ""
                self.semaphore.signal()
            }
        }
    }
    
    // For loading presentment details screen in full screen for app to app flow
    private func launchPresentmentDetails() {
        
        SwiftEventBus.onMainThread(self, name: "DV_LaunchPresentmentDetails") {  result in
            
            if let result = result,
                let presentmentDetailsDictionary = result.userInfo,
                let requestId = presentmentDetailsDictionary["requestId"] as? String,
                let accessToken = presentmentDetailsDictionary["accessToken"] as? String,
                let successUrl = presentmentDetailsDictionary["successUrl"] as? String,
                let failureUrl = presentmentDetailsDictionary["failureUrl"] as? String,
                let clientId = presentmentDetailsDictionary["clientId"] {
                
                let presentmentDetailsViewController = DVPresentmentDetailViewController(nibName: "DVPresentmentDetailViewController", bundle: DVCommon.getDVBundle())
                DVCommon.isPresentmentAppToAppFlow = true
//                presentmentDetailsViewController.isPresentmentAppToAppFlow = true
                presentmentDetailsViewController.apptoAppSuccessUrlString = successUrl
                presentmentDetailsViewController.apptoAppFailureUrlString = failureUrl
                presentmentDetailsViewController.isNotificationFlow = false
                presentmentDetailsViewController.alertMessageId = requestId
                DVCommon.presentmentToken = "accessToken " + accessToken
                
                let presentmentDetailsNavViewController: UINavigationController = UINavigationController(rootViewController: presentmentDetailsViewController)
                UIApplication.shared.keyWindow?.rootViewController?.present(presentmentDetailsNavViewController, animated: true, completion: nil)
            }
        }
    }
}
