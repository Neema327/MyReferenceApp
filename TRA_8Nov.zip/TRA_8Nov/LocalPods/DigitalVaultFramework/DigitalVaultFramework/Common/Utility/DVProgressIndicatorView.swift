//
//  ProgressIndicatorView.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 25/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit
//Custom class for adding activityindicator
class DVProgressIndicatorView {
    private var activityIndicator = UIActivityIndicatorView(style: .gray)
// adding the activityindicator to the specified view and settign the constraints
    func addActivityIndicatorToTheView(view: UIView) {
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = UIColor.colorFromHex(rgbValue: 0x454F63)

        view.addSubview(activityIndicator)
        activityIndicator.isHidden = true
        activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
// dispalying/hiding the activityindicator
    func displayActivityIndicatorView(show: Bool) {
        if show {
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
        }
         activityIndicator.isHidden = !show
    }
}
