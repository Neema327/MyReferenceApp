//
//  DVConstants.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/30/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import UIKit

public typealias SuccessDataClosure = (_ status: Bool, _ data: Data?) -> Void
public typealias FailureDataClosure = (_ status: Bool, _ error: Error?) -> Void

struct DVConstants {
    static var uaepassIntegerationEnabled :Bool = true
    static var uaepassAccessTokenIntegration: Bool = true
    static var uaepassDemoIntegration: Bool = true // Sai: Make it true if you are working with DEMO UAE Pass.
    static var enableBackButton = false
    static var uaepassArabicLocalization: Bool = false
    
    static var docsSearchMode: SearchMode = .none
    static var notificationListMode: SearchMode = .none
    static var notificationState: NotificationState = .none
    static let documentNameMaxLength = 25
    
    static let stateRead = "READ"
    static let stateUnRead = "UNREAD"
    static let stateActionTaken = "ACTION_TAKEN"
    
    static let selfUploadLimitErrorCode = "MAX_SELF_UPLOAD_LIMIT_REACHED"
    static let selfSignAcceptKey = "selfSignAccepted"
    static let requestIdKey = "requestId"
    static let documentIdKey = "documentId"
    
    static let placeholderLargeImage = UIImage(contentsOfFile: DVCommon.digitalVaultResourceBundlePath + "logo-placeholder-ico.png") ?? nil
    static let placeholderSmallImage = UIImage(contentsOfFile: DVCommon.digitalVaultResourceBundlePath + "logo.png")
    
    static let viewEvidenceJScript = "var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width', initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'); document.getElementsByTagName('head')[0].appendChild(meta);"
    
    static let transperentViewTag = 101
    static let sortViewTag = 102
    
    enum PresentmentSection:Int {
        case detail = 0
        case personal = 1
        case mandatory = 2
        case optional = 3
        case additionalInfo = 4
    }

    struct Strings {
        static let emptyString = ""
        static let incomingDateTimeFormat = "dd MMM yyyy HH:mm:ss"
        static let displayArabicDateTimeFormat = "hh:mm a  dd-MM-yyyy"
        static let displayDateTimeFormat = "dd MMM yyyy  hh:mm a"
        //Store to Vault
        static let storeToVaultSuccessMessage = DVLocalization.sharedInstance.localize(string: "Successfully Stored to Vault")
        static let storeToVaultFailureMessage = DVLocalization.sharedInstance.localize(string: "Document not uploaded successfully")
    }

    struct ButtonTitles {
        //ErrorViewController
        static let errorOk = DVLocalization.sharedInstance.localize(string: "OK")
        static let errorRetry = DVLocalization.sharedInstance.localize(string: "Retry")
        static let errorCancel = DVLocalization.sharedInstance.localize(string: "Cancel")

    }
}

let sortTitle = "Sort By"

enum DecodeOption:Int {
    case model
    case data
    case html
    case put
    case jsonString
    case unReadCount
}

enum ArabicFont: String {
    case light = "Dubai-Light"
    case medium = "Dubai-Medium"
    case regular = "Dubai-Regular"
    case bold = "Dubai-Bold"
    case twoBold = "GESSTwoBold-Bold"
    case twoLight = "GESSTwoLight-Light"
    case twoMedium = "GESSTwoMedium-Medium"
}

enum DocsModelType {
    case official
    case unOfficial
}
enum AlertState {
    case unRead
    case read
    case actionTaken
}
enum SortOptionsHex: String {
    case alertMessage = "#00A36A"
    case actionTitle = "#78849E"
}
enum SortOrders {
    case name
    case date
}
enum DocumentsViewType {
    case normalDocSelection
    case arabicLangDocSelection
    case onlyOfficialDocsSelection
}
enum TableRefreshType {
    case docsAvailable
    case noDocsAvailable
    case dataError
}

enum SearchMode {
    case none
    case searchBar
    case searchButton
    case pagination
}
enum NotificationState {
    case none
    case nonactionableRead
    case actionableRead
    case actionableActionTaken
}

typealias HeaderParams = [String: String]
typealias RequestParams = [String: Any]
typealias RequestArrayParams = [String: Any]

let timeOutInterval = 31.0
let backGroundQueue = "com.dv.serviceq"
let langArabic = "&lang=ar"
let langArabicNotificationDetail = "?lang=ar"
struct Constants {
    static let Types: [String] = ["O1", "O2"]
}
enum HttpMethod: String {
    case GET
    case POST
    case PUT
}

enum DeveloperSettings :String {
    case offshoreSimulator
    case offshoreDevice
    case onsiteSimulator
    case onsiteDevice
    
}

enum Environment: String {
    case development
    case qa
    case staging
}

let selectedDeveloperSettings:DeveloperSettings = .offshoreSimulator

let selectedEnvironment: Environment = .staging

var baseURL : String {
    get {
        switch selectedEnvironment {
        case .development:
            return "http://172.27.2.4"
        case .qa:
            return "https://apitest.dv.government.net.ae"
        case .staging:
            return "https://apistage.dv.government.net.ae"
        }
    }
}

var authURL : String {
    get {
        switch selectedEnvironment {
        case .development:
             return "http://172.27.2.4"
        case .qa:
            return "https://apitest.dv.government.net.ae"
        case .staging:
            return "https://apistage.dv.government.net.ae"
        }
    }
}

//let baseURL = "http://172.27.2.4"
//let authURL = "http://172.27.2.4"
//Dev: "http://172.27.2.4"
//QA: https://apitest.dv.government.net.ae
//Staging: https://apistage.dv.government.net.ae

let apiVersion = "/api/v1.0"

enum EndPoint: String {
    case login = "/login"
    case officialDocsDefault = "/credentials/?type=ISSUED&size=10&page="
    case unofficialDocsDefault = "/credentials/?type=SELF&size=10&page="
    case storeToVaultDocumentCategories = "/credential-document-types?type=BOTH"
//    case store_to_vault_confirm_service = "/credentials/"
    case issuersListLogo = "/partners/"
    case officialDocsDetail = "/credentials/"
    case issuersListDefault = "/report/report-credentials-groupedBy-partners?sort=PartnerName"
    case credentialRequest = "/credential-requests/"
    case presentmentDetails = "/presentation-requests/?alertMessageId="
    case appToAppPresentmentDetails = "/presentation-requests/?requestId="
    case notificationList = "/alert-messages/?size=10&page="
    case presentmentDocAddReplace =  "/presentation-requests/"
    case updateNotificationState  = "/alert-messages/"
    case notificationUnreadCount = "/alert-messages/unreadcount"
    case makePresentment = "/presentations?requestId="
    case sharePresentment = "/presentations/share?uaePassDocumentID="
    case processIdStatusCheck = "/presentations/signerProcess?uaePassProcessId="
}

enum ContentType: String {
    case json = "application/json"
    case pdf  = "application/pdf"
    case html = "text/html"
}

enum SortOrder: String {
    case none
    case asc
    case desc
}

let authorization = "Authorization"
let token = "Token"
let accept = "Accept"
let type = "type"
let description = "description"
let content = "Content-Type"
let dvErrorDomain = "com.DV.Error"

let dvServerErrorKey = "serverErrorKey"
let dvFileDownloadErrorKey = "fileDownloadErrorKey"
let dvServerErrorMessage = DVLocalization.sharedInstance.localize(string: "Internal Error, please try again")
let dvNoNetworkErrorMessage = DVLocalization.sharedInstance.localize(string: "No internet connection")
let dvMessageExtractError = "MessageExtraction Error"
let dvAuthError = DVLocalization.sharedInstance.localize(string: "Authentication Error, please try again")

public typealias SuccessClosure = (_ status: Bool, _ data: String) -> Void
public typealias FailureClosure = (_ status: Bool, _ error: Error) -> Void

//typealias SuccessDataClosure = (_ status: Bool, _ data: Data?) -> Void

public typealias DVErrorOkClosure = () -> Void
public typealias DVErrorRetryClosure = () -> Void

let serviceErrorMesg = [DVStatusCode.badRequest: ServerError.badRequest,
                        DVStatusCode.loginFailed: ServerError.loginFailed,
                        DVStatusCode.serverError: ServerError.generic,
                        DVStatusCode.userDisabled: ServerError.generic,
                        DVStatusCode.fileWriteFailedError: fileWriteFailedErrorMessage,
                        DVStatusCode.notFound: ServerError.generic] as [DVStatusCode: String]

let dvDataError = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [NSLocalizedDescriptionKey: ServerError.generic])

let dvFileWriteError = NSError(domain: dvErrorDomain, code: DVStatusCode.fileWriteFailedError.rawValue, userInfo: [NSLocalizedDescriptionKey: fileWriteFailedErrorMessage])

struct Documents {
    static let selectAll =              DVLocalization.sharedInstance.localize(string: "Select all")
    static let download =               DVLocalization.sharedInstance.localize(string: "Download")
    static let viewDetails =               DVLocalization.sharedInstance.localize(string: "View Details")
    static let viewEvidence =           DVLocalization.sharedInstance.localize(string: "View Evidence")
    static let officialSegmentTitle =   DVLocalization.sharedInstance.localize(string: "Requested")
    static let selfSignedSegmentTitle = DVLocalization.sharedInstance.localize(string: "Uploaded")
    static let cancelButtonTitle =      DVLocalization.sharedInstance.localize(string: "Cancel")
    static let unselectButtonTitle =    DVLocalization.sharedInstance.localize(string: "Unselect")
    static let removeDocsTitle =        DVLocalization.sharedInstance.localize(string: "Remove Document")
    static let search =                 DVLocalization.sharedInstance.localize(string: "Search")
    static let sortBy =                 DVLocalization.sharedInstance.localize(string: "Sort By")
    static let remove =                 DVLocalization.sharedInstance.localize(string: "Remove")
    static let add =                    DVLocalization.sharedInstance.localize(string: "Add")
    static let select =                 DVLocalization.sharedInstance.localize(string: "Select")
    static let sort =                   DVLocalization.sharedInstance.localize(string: "Sort")
    static let docsTile =               DVLocalization.sharedInstance.localize(string: "Documents")
    static let docTile =                DVLocalization.sharedInstance.localize(string: "Document")//unused
    static let nameSort =               DVLocalization.sharedInstance.localize(string: "Name")
    static let dateSort =               DVLocalization.sharedInstance.localize(string: "Date")
    static let docRemovalSuccessMsg =   DVLocalization.sharedInstance.localize(string: "You have successfully removed")
    static let docsRemovalSuccessMsg =  DVLocalization.sharedInstance.localize(string: "You have successfully removed the document(s)")
    static let singleDocSelcted =          DVLocalization.sharedInstance.localize(string: "Document Selected")
    static let multipleDocSelcted =     DVLocalization.sharedInstance.localize(string: "Documents Selected")
    static let noRecordsMsg =              DVLocalization.sharedInstance.localize(string: "No Records for")
    static let validKeySearchMsg =      DVLocalization.sharedInstance.localize(string: "Sorry we could not find any document titled")
    static let noDocsMsg =              DVLocalization.sharedInstance.localize(string: "No Documents Available")
    static let addDocsMsg =             DVLocalization.sharedInstance.localize(string: "You can request a document by clicking on Add")
    static let uploadDocsMsg =             DVLocalization.sharedInstance.localize(string: "You can upload a document by clicking on Add")
    static let downloadSuccessMessage = DVLocalization.sharedInstance.localize(string: "You have successfully  downloaded document")
    static let digitalVault =           DVLocalization.sharedInstance.localize(string: "Digital Vault")
    static let downloadErrorAlert =     DVLocalization.sharedInstance.localize(string: "Multi-selection for download is not allowed")
    static let documentSelectMessage =     DVLocalization.sharedInstance.localize(string: "Please select a document")
    static let multipleDocsRemoveError = DVLocalization.sharedInstance.localize(string: "Are you sure you want to remove the document(s)?")
    static let singleDocsRemoveError = DVLocalization.sharedInstance.localize(string: "Are you sure you want to remove the document?")
    static let category = DVLocalization.sharedInstance.localize(string: "Category")
}

struct Notifications {
    static let title =                  DVLocalization.sharedInstance.localize(string: "Notification")
    static let notificationsTitle =     DVLocalization.sharedInstance.localize(string: "Notifications")
    static let viewDetails =            DVLocalization.sharedInstance.localize(string: "Notification Details")
    static let allow =                  DVLocalization.sharedInstance.localize(string: "Allow")
    static let notAvailable =           DVLocalization.sharedInstance.localize(string: "Unavailable")
    static let replace =                DVLocalization.sharedInstance.localize(string: "Replace")
    static let expired =                DVLocalization.sharedInstance.localize(string: "Expired")
    static let reasonOfRequest =        DVLocalization.sharedInstance.localize(string: "Reason for request")
    static let reason =                 DVLocalization.sharedInstance.localize(string: "Reason")
    static let requestID =              DVLocalization.sharedInstance.localize(string: "Reference No")
    static let needHelp =               DVLocalization.sharedInstance.localize(string: "Do you need help?")
    static let mandatoryDocs =          DVLocalization.sharedInstance.localize(string: "Mandatory Documents")
    static let optionalDocs =           DVLocalization.sharedInstance.localize(string: "Optional Documents")
    static let Request =                DVLocalization.sharedInstance.localize(string: "Request")//not used
    static let requestedBy =            DVLocalization.sharedInstance.localize(string: "Requested by")
    static let requestedOn =            DVLocalization.sharedInstance.localize(string: "On")
    static let requestforSharing =      DVLocalization.sharedInstance.localize(string: "Request for Sharing")
    static let personalDetails =      DVLocalization.sharedInstance.localize(string: "Personal Details")
    static let additionalInfo =      DVLocalization.sharedInstance.localize(string: "Additional Information")
    static let exitTitle =           DVLocalization.sharedInstance.localize(string: "Exit")
    static let shareSuccessMessage =  DVLocalization.sharedInstance.localize(string: "Your information is shared with")
    static let shared =  DVLocalization.sharedInstance.localize(string: "Shared")
    
}

struct StoreToVault {
    static let storeToDocumentsTitle =      DVLocalization.sharedInstance.localize(string: "Document Category")
    static let newCategoryTitle =            DVLocalization.sharedInstance.localize(string: "New Category")
    static let documentName =                DVLocalization.sharedInstance.localize(string: "Document Name")
    static let success =                DVLocalization.sharedInstance.localize(string: "Success")
    static let successMessage =           DVLocalization.sharedInstance.localize(string: "Your document has been stored successfully")
    static let okTitle =                DVLocalization.sharedInstance.localize(string: "OK")
    static let storeToDocuments =                DVLocalization.sharedInstance.localize(string: "Store to Documents")
    static let confirmButtonTitle = DVLocalization.sharedInstance.localize(string: "Store to Documents")
    static let documentNameTitle = DVLocalization.sharedInstance.localize(string: "Document Name")
    static let documetNameLengthValidation = DVLocalization.sharedInstance.localize(string: "Name should not exceed 25 chars")
    static let documetNameSpecialCharacterValidation = DVLocalization.sharedInstance.localize(string: "Special characters not allowed")
    static let documentNamePlaceholder = DVLocalization.sharedInstance.localize(string: "Enter the Document Name")
    static let storageLimitErrorText = DVLocalization.sharedInstance.localize(string: "Size limit(100 MB) exceeded. Please free up some space to store new document")
    static let download =               DVLocalization.sharedInstance.localize(string: "Download")
    static let exit =           DVLocalization.sharedInstance.localize(string: "Exit")
}

//Neema has to check and add the missing strings in Localizable file
struct IssuersList {
    static let sortTitle = DVLocalization.sharedInstance.localize(string: "Sort")
    static let searchTitle = DVLocalization.sharedInstance.localize(string: "Search")
    static let requestTitle = DVLocalization.sharedInstance.localize(string: "Add Document")
    static let sortByName = DVLocalization.sharedInstance.localize(string: "Name")
    static let added = DVLocalization.sharedInstance.localize(string: "Added")
    static let inProgress = DVLocalization.sharedInstance.localize(string: "In-Progress")
    static let validkeySearchMesssage =      DVLocalization.sharedInstance.localize(string: "Sorry we could not find any match for")
}

struct Confirm {
    static let title = DVLocalization.sharedInstance.localize(string: "New Request")
    static let agreeDocumentText = DVLocalization.sharedInstance.localize(string: "I confirm my details and consent to request for the document")
    static let confirmButtonTitle = DVLocalization.sharedInstance.localize(string: "Confirm")
    static let confirmdescTitle = DVLocalization.sharedInstance.localize(string: "Below details will be used while requesting for the document")
}

struct  Success {
    static let message = DVLocalization.sharedInstance.localize(string: "You will be notified once the document is added")
    static let okButtonTitle = DVLocalization.sharedInstance.localize(string: "OK")
    static let title = DVLocalization.sharedInstance.localize(string: "Success")
}

struct ServerError {
    static let badRequest =      DVLocalization.sharedInstance.localize(string: "Internal Error, Please contact support desk")
    static let generic =      DVLocalization.sharedInstance.localize(string: "Internal Error, Please contact support desk")
    static let notFound =            DVLocalization.sharedInstance.localize(string: "Service temporarily not available, please try again")
    static let loginFailed =                DVLocalization.sharedInstance.localize(string: "Session Time out, please login and try again")
}

struct LoaderMessages {
    static let presentmentDetails = DVLocalization.sharedInstance.localize(string: "Please wait we are loading the information, Kindly do not close the app")
    static let defaultMessage = DVLocalization.sharedInstance.localize(string: "Please wait we are loading the information, Kindly do not close the app")
    static let downloadMessage = DVLocalization.sharedInstance.localize(string: "Your file is downloading. \n Please wait for few seconds")
    static let shareFlow = DVLocalization.sharedInstance.localize(string: "Please wait while we share the documents with")
}

struct ApptoAppMessages {
    static let userExitMessage = DVLocalization.sharedInstance.localize(string: "UserExit")
    static let serviceErrorMessage = DVLocalization.sharedInstance.localize(string: "SystemError")
}

let fileWriteFailedErrorMessage = DVLocalization.sharedInstance.localize(string: "Download Failed")
let cacheExpiryInDays = 3
