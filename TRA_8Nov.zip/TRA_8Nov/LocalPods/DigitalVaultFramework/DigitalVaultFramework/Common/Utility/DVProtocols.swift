//
//  DVProtocols.swift
//  DigitalVaultAppSample
//
//  Created by Lija George on 12/07/19.
//  Copyright © 2019 TRA. All rights reserved.
//

import Foundation
import UIKit

public protocol PresentmentDocCellConfigurable where Self: UITableViewCell {
    associatedtype ModelType
    /// Configure tableview cell
    func configureDocCell(with objectData: ModelType?, exprFlag: Bool?)
}
