//
//  DVFileManager.swift
//  DigitalVaultFramework
//
//  Created by Neema Naidu on 04/09/19.
//

import Foundation
import PromiseKit

class DVFileManager {
     let fileManager = FileManager.default
}

extension DVFileManager {

    struct DocumentLocation {
        static var documentLocation: String = ""
    }

    var documentLocation: String {
        get {
            return DocumentLocation.documentLocation
        }
        set(newValue) {
            DocumentLocation.documentLocation = newValue
        }
    }

    func writeEvidenceDataToDocumentsDirectory(credentialName: String, writeData: Data) throws {
        let path =  (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("Credential")
        do {
            if !fileManager.fileExists(atPath: path) {
                try fileManager.createDirectory(atPath: path, withIntermediateDirectories: true, attributes: nil)
            }
//            print(path)
            let url = URL(fileURLWithPath: path, isDirectory: true)
            let documentPath = url.appendingPathComponent("\(credentialName).pdf")
            let urlString: String =  documentPath.path
            let success =  fileManager.createFile(atPath: urlString as String, contents: writeData, attributes: nil)
            if !success {
                throw dvFileWriteError
            } else {
                documentLocation = urlString
            }
        } catch let error as NSError {
//            print("Error: \(error.localizedDescription)")
            throw dvFileWriteError
        }
    }
    func isDocumentExistInDocumentDirectory(credentialId: String) -> Bool {
        let documentPath = (self.getDirectoryPath() as URL).appendingPathComponent("\(credentialId).pdf")
        let urlString: String = documentPath.path
        let fileExists =  fileManager.fileExists(atPath: urlString)
        documentLocation = urlString
        return fileExists
    }
    func getDocumentFromDocumentDirectory(credentialId: String) -> Data? {
        let documentPath = (self.getDirectoryPath() as URL).appendingPathComponent("\(credentialId).pdf")
        let urlString: String = documentPath.path
        if fileManager.fileExists(atPath: urlString) {
            let documentUrl = URL(fileURLWithPath: urlString, isDirectory: true)
            do {
                let document = try Data(contentsOf: documentUrl)
                return document
            } catch let error as NSError {
//                print("Error: \(error.localizedDescription)")
                return nil
            }
        } else {
            return nil
        }
    }
    func getDirectoryPath() -> URL {
        let path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("Credential")
        let url = URL(fileURLWithPath: path, isDirectory: true)
        return url
    }
    func deleteDocumentFromDirectory(credentialId: String) {
        let documentPath = (self.getDirectoryPath() as URL).appendingPathComponent("\(credentialId).pdf")
        let urlString: String = documentPath.path
        do {
            if fileManager.fileExists(atPath: urlString) {
                try fileManager.removeItem(atPath: urlString)
            } else {
            }
        } catch let error as NSError {
//            print("Error: \(error.localizedDescription)")
        }
    }

}
extension DVFileManager {
    func getEvidenceData(credentialId: String, credentialName: String, needToWrite: Bool, completionHandler: @escaping SuccessDataClosure,
                         failureHandler: @escaping FailureClosure) {
        self.getEvidencePDFData(credentialId: credentialId, needToWrite: needToWrite)
            .done({ (data) in
                guard let evidenceData = data as? Data else {
                    failureHandler(false, dvDataError)
                    return
                }
                if needToWrite {
                    do {
                        try self.writeEvidenceDataToDocumentsDirectory(credentialName: credentialName, writeData: evidenceData)
                        //not passing the data as it is only saving the data in docs directory
                        completionHandler(true, nil)
                    } catch let error as NSError {
//                        print("Error: \(error.localizedDescription)")
                        failureHandler(false, error)
                    }
                } else { //passing the data to display in pdf view
                    completionHandler(true, evidenceData)
                }
            })
            .catch { error in
                failureHandler(false, error) //need to change
        }
    }

    //To view credential's evidence pdf
    func getEvidencePDFData(credentialId: String, needToWrite: Bool) -> Promise<Any> {
        return Promise {  seal in

            let  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + credentialId + "/evidence"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken
            headerParams[accept] = ContentType.pdf.rawValue
            headerParams[type] = "text"
            headerParams[description] = ""

            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (pdfData) in
                        seal.fulfill(pdfData)
                    }).catch { error in
                        seal.reject(error)
                }
                
//                if let jsonData = jsonResponse {
//                    seal.fulfill(jsonData)
//                } else {
//                    if let error = respError {
//                        seal.reject(error)
//                    } else {
//                        let error = NSError(domain: dvErrorDomain, code: 0, userInfo: [NSLocalizedDescriptionKey: "message"])
//                        seal.reject(error)
//                    }
//                }

            }
        }
    }
}
