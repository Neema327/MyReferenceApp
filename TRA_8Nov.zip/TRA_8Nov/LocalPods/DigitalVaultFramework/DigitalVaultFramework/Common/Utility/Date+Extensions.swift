//
//  Date+Extensions.swift
//  DigitalVault
//
//  Created by Neema Naidu on 01/08/19.
//

import Foundation

extension Date {
    static func getFormattedDate(date: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = DVConstants.Strings.incomingDateTimeFormat
        if let date = dateFormatter.date(from: date) {
            if DVConstants.uaepassArabicLocalization {
                dateFormatter.dateFormat = DVConstants.Strings.displayArabicDateTimeFormat
            } else {
                dateFormatter.dateFormat = DVConstants.Strings.displayDateTimeFormat
            }
            let dateString = dateFormatter.string(from: date)
            return dateString
        }
        return nil
    }
}
