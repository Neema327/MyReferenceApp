//
//  Extensions.swift
//  DigitalVault
//
//  Created by Saiaswanth on 6/30/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import Foundation
import UIKit

// Commenting below code to get topViewController. Because, already this code was present in UAEPassDemo code

public extension UIApplication {

    class func topMostViewController(baseViewController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let navigationController = baseViewController as? UINavigationController {
            return topMostViewController(baseViewController: navigationController.visibleViewController)
        }
        if let tabController = baseViewController as? UITabBarController {
            let moreNavigationController = tabController.moreNavigationController

            if let topController = moreNavigationController.topViewController, topController.view.window != nil {
                return topMostViewController(baseViewController: topController)
            } else if let selected = tabController.selectedViewController {
                return topMostViewController(baseViewController: selected)
            }
        }
        if let presented = baseViewController?.presentedViewController {
            return topMostViewController(baseViewController: presented)
        }
        return baseViewController
    }
}

extension String {

    mutating func localizedString() -> String {

        return NSLocalizedString(String(self), comment: String(self))
    }
}

extension Bundle {

    /// Creates a bundle that is on a particular module
    /// - Parameter moduleName: The name of the module (framework)
    /// - Returns: NSBundle if a bundle if found, otherwise nil
    public static func createBundle(_ moduleName: String) -> Bundle? {

        guard let urlString = Bundle.main.path(forResource: moduleName, ofType: "framework", inDirectory: "Frameworks") as String? else {
            return nil
        }
        return Bundle(url: URL(fileURLWithPath: urlString))
    }
}
