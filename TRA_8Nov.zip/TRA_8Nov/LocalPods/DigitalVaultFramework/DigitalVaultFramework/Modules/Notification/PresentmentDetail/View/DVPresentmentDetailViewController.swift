//
//  DVPresentmentDetailViewController..swift
//  DigitalVaultFramework

//  Created by Lija George on 09/08/19.
//  View class for Presentment Details screen

import UIKit
import SwiftEventBus

class DVPresentmentDetailViewController: UIViewController {
    @IBOutlet var presentmentDetailTableView: UITableView!
    @IBOutlet var titleLabel: UILabel!
    
    let presentmentDetailViewModel = DVPresentmentDetailViewModel()
    let notificationListViewModel = DVNotificationListViewModel()
    var alertMessageId: String?
    var isNavigatedForDocumentSelection = false
    var isDocumentAddReplaceSuccess = false
    var alertStatus: String?
    var isNotificationFlow = false
    var apptoAppSuccessUrlString: String?
    var apptoAppFailureUrlString: String?
    
    lazy private var presentmentDetailDataSource: DVPresentmentDetailDataSource = {
        let presentmentDetailDataSrc = DVPresentmentDetailDataSource()
        return presentmentDetailDataSrc
    }()
    lazy private var activityIndicatorView: DVProgressIndicatorView = {
        let progressIndicatorView = DVProgressIndicatorView()
        return progressIndicatorView
    }()
    lazy var exitButton: UIBarButtonItem = {
        let exitButton = UIBarButtonItem(title: Notifications.exitTitle,
                                                  style: UIBarButtonItem.Style.plain,
                                                  target: self, action: #selector(exitButtonAction))
        return exitButton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        applyNavBarStyle()
        presentmentDetailViewModel.isNotificationFlow = isNotificationFlow
        configureNotificationDetailView()
        configureLocalizationFonts()
        getSignUrlStatus()
        
        if DVCommon.isPresentmentAppToAppFlow || isNotificationFlow {
            loadPresentmentDetails()
        } else {
            (alertStatus == DVConstants.stateUnRead) ? updateNotificationState() : loadPresentmentDetails()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
        if isNavigatedForDocumentSelection {
            isNavigatedForDocumentSelection = false
            if isDocumentAddReplaceSuccess {
                isDocumentAddReplaceSuccess = false
                presentmentDetailViewModel.presentmentDetail = nil
                loadPresentmentDetails()
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}

extension DVPresentmentDetailViewController {
    func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            titleLabel.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 28.0)
        }
    }
    private func applyNavBarStyle () {
        let topHeaderBGImg = DVCommon.getImage(named: "top-header-bg.png")
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(topHeaderBGImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        self.navigationController?.navigationBar.isTranslucent = false
    }
    
    private func loadNotificationUnreadCount() {
        DVEventHandler.sharedInstance.getNotificationCount()
    }
    
    //fetching the presentment data from server and refreshing the tableview
    private func loadPresentmentDetails() {
        displayActivityIndicatorView(with: LoaderMessages.presentmentDetails)
        presentmentDetailViewModel.alertMessageId = alertMessageId
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.presentmentDetailViewModel.fetchPresentmentDetailsData(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.refreshTableView()
                    self?.loadNotificationUnreadCount()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.refreshTableView()
                    self?.loadNotificationUnreadCount()
                    if DVCommon.isPresentmentAppToAppFlow {
                        DVCommon.showError(serviceError: error, withSuccess: {
                            self?.handlePresentmentFailure(with: ApptoAppMessages.serviceErrorMessage)
                        } , andFailure: nil)
                    } else {
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
                }
            })
        }
    }
    private func updateNotificationState() {
        displayActivityIndicatorView(with: LoaderMessages.presentmentDetails)
        presentmentDetailViewModel.alertMessageId = alertMessageId
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.presentmentDetailViewModel.updateNotificationState(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVConstants.notificationState = .actionableRead
                    self?.hideActivityIndicatorView()
                    self?.loadPresentmentDetails()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                }
            })
        }
    }
    private func configureNotificationDetailView() {
        if DVCommon.isPresentmentAppToAppFlow {
            let rightBarButton = exitButton
            self.navigationItem.rightBarButtonItem = rightBarButton
            self.navigationItem.hidesBackButton = true //Sai has to check and confiorm this required or not
            self.titleLabel.text = Notifications.title
        } else {
            if alertStatus == DVConstants.stateActionTaken {
                self.titleLabel.text = Notifications.viewDetails
            } else {
                self.titleLabel.text = Notifications.requestforSharing
            }
        }
        registerTableViewCells()
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        self.presentmentDetailTableView.separatorColor = UIColor.clear
        self.presentmentDetailDataSource.tableView = self.presentmentDetailTableView
        presentmentDetailTableView.delegate = presentmentDetailDataSource
        presentmentDetailTableView.dataSource = presentmentDetailDataSource
        presentmentDetailTableView.estimatedRowHeight = 60
        presentmentDetailTableView.setUpRoundedCornerView(view: presentmentDetailTableView)
        activityIndicatorView.addActivityIndicatorToTheView(view: self.view)
    }
    private func registerTableViewCells() {
        UITableView.registerCellWithIdentifier(cellIdentifier: DVNotificationMandatoryDocTableViewCell.identifier, tblVw: self.presentmentDetailTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: DVNotificationOptionalDocTableViewCell.identifier, tblVw: self.presentmentDetailTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: DVNotificationDetailTextTableViewCell.identifier, tblVw: self.presentmentDetailTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: DVPresentmentDetailTableViewCell.identifier, tblVw: self.presentmentDetailTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: DVPresentmentPersonalDetailTableViewCell.identifier, tblVw: self.presentmentDetailTableView)
        
    }
    //refreshing the tableview withthe updated data
    private func refreshTableView() {
        self.presentmentDetailDataSource.presentmentDetailViewModel = self.presentmentDetailViewModel
        self.presentmentDetailDataSource.tableView = self.presentmentDetailTableView
        self.presentmentDetailDataSource.delegate = self
        self.presentmentDetailDataSource.alertState = self.presentmentDetailViewModel.getTheAlertState(stateAlert: self.alertStatus ?? "")
        self.presentmentDetailTableView.delegate = self.presentmentDetailDataSource
        self.presentmentDetailTableView.dataSource = self.presentmentDetailDataSource
        self.presentmentDetailTableView.reloadData()
    }
    private func displayActivityIndicatorView(with message: String) {
        DVEventHandler.sharedInstance.showOrHideLoader(with: true, and: message)
    }
    private func hideActivityIndicatorView() {
        DVEventHandler.sharedInstance.showOrHideLoader(with: false, and: "")
    }
    private func showAlertWith(title: String, message: String) {
        let alertVc = UIAlertController.showAlertWith(title: title, message: message)
        self.present(alertVc, animated: true, completion: nil)
    }
    //fetching the presentment data from server and refreshing the tableview
    private func makePresentation() {
        NSLog("Start Make presentment")
        displayActivityIndicatorView(with: presentmentDetailViewModel.getLoaderMessage())
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.presentmentDetailViewModel.makePresentment(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    guard let presentmentUrl = self?.presentmentDetailViewModel.getPresentmentShareUrl(), let loaderMessage = self?.presentmentDetailViewModel.getLoaderMessage() else {
                        return
                    }
                    NSLog("Make presentment success")
                    self?.checkStatus(url: presentmentUrl, with: loaderMessage)
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    NSLog("Make presentment failure")
                    if DVCommon.isPresentmentAppToAppFlow {
                        DVCommon.showError(serviceError: error, withSuccess: {
                            self?.handlePresentmentFailure(with: ApptoAppMessages.serviceErrorMessage)
                        } , andFailure: nil)
                    } else {
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
                }
            })
        }
    }
    
    private func checkStatus(url: String, with loaderMessage: String) {
        presentmentDetailViewModel.checkStatus(url: url, completionHandler: { [weak self] (status, _) in
            
            if status {
                self?.hideActivityIndicatorView()
                self?.signPresentment(url: url, with: loaderMessage)
            } else {
                self?.startSharePresentation(statusMessage: "failed")
            }
            }, failureHandler: { [weak self] (status, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    if DVCommon.isPresentmentAppToAppFlow {
                        DVCommon.showError(serviceError: error, withSuccess: {
                            self?.handlePresentmentFailure(with: ApptoAppMessages.serviceErrorMessage)
                        } , andFailure: nil)
                    } else {
                        DVCommon.showError(serviceError: error, withSuccess: nil , andFailure: nil)
                    }
                }
        })
    }
    
    private func signPresentment(url: String, with loaderMessage: String) {
        DVEventHandler.sharedInstance.sign(url: url, wihtLoader: loaderMessage)
    }
    
    private func getSignUrlStatus() {
        SwiftEventBus.unregister(self, name: "DV_SignUrlStatus")
        SwiftEventBus.onMainThread(self, name: "DV_SignUrlStatus") { [weak self] result in
            if let result = result, let signUrlStatusDictionary = result.userInfo,
                let statusMessage = signUrlStatusDictionary["statusMessage"] as? String {
                self?.startSharePresentation(statusMessage: statusMessage)
            } else {
                self?.hideActivityIndicatorView()
                let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
                
                if DVCommon.isPresentmentAppToAppFlow {
                    DVCommon.showError(serviceError: error, withSuccess: {
                        self?.handlePresentmentFailure(with: ApptoAppMessages.serviceErrorMessage)
                    } , andFailure: nil)
                } else {
                    DVCommon.showError(serviceError: error, withSuccess: nil , andFailure: nil)
                }
            }
        }
    }

    private func startSharePresentation(statusMessage: String) {
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.presentmentDetailViewModel.sharePresentment(statusMessage: statusMessage, completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVConstants.notificationState = .actionableActionTaken
                    self?.hideActivityIndicatorView()
                    self?.navigateToSuccessScreen()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    if DVCommon.isPresentmentAppToAppFlow {
                        DVCommon.showError(serviceError: error, withSuccess: {
                            self?.handlePresentmentFailure(with: ApptoAppMessages.serviceErrorMessage)
                        } , andFailure: nil)
                    } else {
                        DVCommon.showError(serviceError: error, withSuccess: nil , andFailure: nil)
                    }
                }
            })
        }
    }
    private func navigateToSuccessScreen() {
        let successNotificationViewController = DVNotifiedViewController(nibName: "DVNotifiedViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
        let succesImageName = "success_multiple_docs_ico"
        let alerMessage = presentmentDetailViewModel.prepareSuccessMessage() ?? ""
        successNotificationViewController.loadView()
        let notifiedImage = DVCommon.getImage(named: succesImageName)
        successNotificationViewController.isPresentmentAppToAppFlow = DVCommon.isPresentmentAppToAppFlow
        successNotificationViewController.apptoappSuccessUrl = apptoAppSuccessUrlString
        successNotificationViewController.isFromPresentmentFlow = true
        successNotificationViewController.updateNotifiedUI(title: DVConstants.Strings.emptyString, subTitle: Notifications.requestforSharing, alertTitle: alerMessage, image: notifiedImage)
        self.navigationController?.pushViewController(successNotificationViewController, animated: true)
    }
    
    private func handlePresentmentFailure(with message: String) {
        DVCommon.isPresentmentAppToAppFlow = false
        if var failureUrlString = apptoAppFailureUrlString {
            failureUrlString = failureUrlString + "?status=\(message)"
            if let url = URL(string: failureUrlString) {
                UIApplication.shared.open(url, options: [:]) { _ in
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
}

extension DVPresentmentDetailViewController {
    @IBAction func exitButtonAction(sender: UIBarButtonItem) {
        handlePresentmentFailure(with: ApptoAppMessages.userExitMessage)
    }
}
extension DVPresentmentDetailViewController: DVPresentmentDetailDataSourceDelegate {
    func startMakePresentation() {
        makePresentation()
    }

    func displayAddOrReplaceDocument(with presentmentDocDetails: [String: Any]) {
        isNavigatedForDocumentSelection = true
        let documentsViewController = DVDocumentsViewController(nibName: "DVDocumentsViewController", bundle: DVCommon.getDVBundle())
        documentsViewController.isDocumentSelectionFlow = true
        documentsViewController.presentmentDocDetails = presentmentDocDetails
        documentsViewController.delegate = self

        let navDocsViewController: UINavigationController = UINavigationController(rootViewController: documentsViewController)
        self.present(navDocsViewController, animated: true, completion: nil)
    }
    func displayDocumentDetailView(with vcid: String, isOfficial: Bool, docName: String) {
        if isOfficial {
            let credentialViewController = DVViewCredentialViewController(nibName: "DVViewCredentialViewController", bundle: DVCommon.getDVBundle())
            credentialViewController.detailTitle = docName
            credentialViewController.credentialId = vcid
            self.navigationController?.pushViewController(credentialViewController, animated: true)
        } else {
            let evidenceViewController = DVViewEvidenceViewContoller(nibName: "DVViewEvidenceViewContoller", bundle: DVCommon.getDVBundle())
            evidenceViewController.detailTitle = docName
            evidenceViewController.credentialId = vcid
            evidenceViewController.isFromOfficial = isOfficial
            evidenceViewController.isFromNotificationFlow = true
            self.navigationController?.pushViewController(evidenceViewController, animated: true)
        }
    }
}

extension DVPresentmentDetailViewController: DVDocumentsDelegate {
    func presentmentDocAddOrReplaceSucces(with success: Bool) {
        isDocumentAddReplaceSuccess = success
    }
}
