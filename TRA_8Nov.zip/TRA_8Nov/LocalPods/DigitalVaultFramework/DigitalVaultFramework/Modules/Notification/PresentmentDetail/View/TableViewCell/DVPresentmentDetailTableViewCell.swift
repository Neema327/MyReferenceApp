//
//  DVPresentmentDetailTableViewCell.swift
//  DigitalVaultFramework
//
//  Created by Neema Naidu on 08/08/19.
//  TablView cell class for the detail section of Presentment Detail screen
//

import UIKit
import Kingfisher

protocol DVPresentmentDetailTableViewCellDelegate: class {
    func performAllowButtonAction(index: Int)
}
class DVPresentmentDetailTableViewCell: UITableViewCell {
    @IBOutlet var allowButton: UIButton!
    @IBOutlet weak var requestedByLabel: UILabel!
    @IBOutlet var iconImgView: UIImageView!
    @IBOutlet weak var requestedOnLabel: UILabel!
    @IBOutlet var partnerNameLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var reasonOfReqTitleLabel: UILabel!
    @IBOutlet var reasonOfReqTextLabel: UILabel!
    @IBOutlet weak var imageViewWidthConstraint: NSLayoutConstraint!

    weak var delegate: DVPresentmentDetailTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        allowButton.setTitle(Notifications.allow, for: .normal)
        allowButton.setViewsLayer(layer: allowButton.layer, shouldLayerBorderClearColor: true)
        
        if DVConstants.uaepassArabicLocalization {
            allowButton.titleLabel?.font = UIFont(name: ArabicFont.regular.rawValue, size: 17)
            requestedOnLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 14)
            dateLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 14)
            reasonOfReqTitleLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 16)
            reasonOfReqTextLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 17)
        }
    }
    /// Configure the Presentment Detail Cell with title, partner name,  created on and partner image
    /// - Parameters:
    ///   - partnerId: service provider id for getting the partner logo
    ///   - requestTitle: title of the notification request
    ///   - partnerName: partner name
    ///   - createdOn: created on/last updated notification date
    ///   - expiryFlag: expiry flag
    func configurePresentmentDetailCell(with partnerId: String?, requestTitle: String?, partnerName: String?, createdOn: String?, expiryFlag: Bool?) {
        self.reasonOfReqTitleLabel.textColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        self.requestedByLabel.textColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        self.requestedOnLabel.textColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        self.dateLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        self.partnerNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        
        let requestedByLabelText = NSMutableAttributedString(string: Notifications.requestedBy + " ", attributes:[
            NSAttributedString.Key.foregroundColor: UIColor.colorFromHex(rgbValue: 0x78849E),
            NSAttributedString.Key.font: ((DVConstants.uaepassArabicLocalization == true) ?  UIFont(name: ArabicFont.regular.rawValue, size: 14) ?? UIFont.systemFont(ofSize: 14.0): UIFont.systemFont(ofSize: 14.0))])
        requestedByLabelText.append(NSMutableAttributedString(string: (partnerName ?? ""), attributes:[
            NSAttributedString.Key.foregroundColor: UIColor.colorFromHex(rgbValue: 0x454F63)]))
        
        self.requestedByLabel.attributedText = requestedByLabelText
        self.requestedOnLabel.text = Notifications.requestedOn
        if let createdDateString = Date.getFormattedDate(date: createdOn ?? "") {
            self.dateLabel.text = createdDateString
        }
        if let issuerId = partnerId {
            let  iconURL  =  baseURL + apiVersion + EndPoint.issuersListLogo.rawValue + "\(issuerId)" + "/icon"
            addIconImage(partnerIdUrlString: iconURL)
        } else {
            self.iconImgView.contentMode = .scaleAspectFill
            self.iconImgView.image = DVConstants.placeholderLargeImage
            self.imageViewWidthConstraint.constant = 105.0
        }
    }
    func addIconImage(partnerIdUrlString: String) {
        self.iconImgView.contentMode = .scaleToFill
        var newWidth = CGFloat()
        self.iconImgView.kf.cancelDownloadTask()
        self.iconImgView.kf.indicatorType = .activity
        let  iconURL  =  partnerIdUrlString
        if let url = URL(string: iconURL) {

            self.iconImgView.kf.setImage(
                with: url,
                placeholder: DVConstants.placeholderLargeImage,
                options:
                [.waitForCache, .loadDiskFileSynchronously, .transition(.none)],
                progressBlock: nil) {
                result in
                switch result {
                case .success(let value):
                    self.iconImgView.contentMode = .scaleAspectFit
                    let ratio = value.image.size.width / value.image.size.height
                    newWidth = self.iconImgView.frame.height * ratio
                    self.imageViewWidthConstraint.constant = newWidth
                case .failure(let error):
                    self.iconImgView.contentMode = .scaleAspectFill
                    self.iconImgView.image = DVConstants.placeholderLargeImage
                    self.imageViewWidthConstraint.constant = 105.0
                }
            }

        }
    }
    @IBAction func allowButtonAction(sender: UIButton) {
        self.delegate?.performAllowButtonAction(index: sender.tag)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }

    static var identifier: String {
        return String(describing: self)
    }

}
