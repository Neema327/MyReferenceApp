//
//  DVNotificationOptionalDocTableViewCell.swift
//  DigitalVaultFramework
//
//  Created by Lija on 08/08/19.
//  TablView cell class for Optional Docs in Presentment Details screen
//

import UIKit
protocol DVPresentmentDocTableViewCellDelegate: class {
    func addButtonAction(sender: UIButton, cell: UITableViewCell)
    func showDocDetailAction(cell: UITableViewCell)
}

class DVNotificationOptionalDocTableViewCell: UITableViewCell {
    @IBOutlet weak var optionalDocImageView: UIImageView!
    @IBOutlet weak var credentialDocNameLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var stackViewBottomConstriant: NSLayoutConstraint!
    @IBOutlet weak var arrowImageView: UIImageView!

    weak var delegate: DVPresentmentDocTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        if DVConstants.uaepassArabicLocalization {
            credentialDocNameLabel.font =  UIFont(name: ArabicFont.regular.rawValue, size: 18)
            arrowImageView.image = DVCommon.getImage(named: "link_arrow_left")
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        credentialDocNameLabel.addGestureRecognizer(tap)
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }

    static var identifier: String {
        return String(describing: self)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    @IBAction func addButtonAction(sender: UIButton) {
        self.delegate?.addButtonAction(sender: sender, cell: self)
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.delegate?.showDocDetailAction(cell: self)
    }
    func updateImage(imageName: String) {
        let tempCredentialImage = UIImage(contentsOfFile: DVCommon.digitalVaultResourceBundlePath + imageName)
        optionalDocImageView.image = tempCredentialImage

    }
    /// Configure the Optional Document Cell depending on the matched/not matched scenarios
    /// and the notification state - shared/expired/read and unread
    /// - Parameters:
    ///   - objectData: current document object
    ///   - exprFlag:   current notification expiry flag
    func configureDocCell(with objectData: RequestedDocument?, exprFlag: Bool?) {
        guard let optionalDoc = objectData else {
            return
        }
        var expiryFlag: Bool = false
        if let expFlag = exprFlag {
            expiryFlag = expFlag
        }
        credentialDocNameLabel.text = optionalDoc.documentName ?? ""
        //"Offical docs if it already matched, it can't be matched/replcaed again. But for Unofficial
        //it can be replaced".
        if let assignedCredential = optionalDoc.assignedCredential {
            configureDocCellForAlreadyMatched(with: optionalDoc, assignedCredential: assignedCredential)
        } else { // "assignedCredential": null  - need to display Add button in case of both Official or UnOfficial docs
            addButton.isHidden = false
            credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
            if let selfSignAccepted = optionalDoc.selfSignedAccepted {
                if selfSignAccepted {
                    addButton.setTitle(Documents.select, for: .normal)
                    arrowImageView.isHidden = false
                    updateImage(imageName: "unofficial_doc_small_ico.png")
                } else {
                    addButton.setTitle(Notifications.notAvailable, for: .normal)
                    arrowImageView.isHidden = true
                    addButton.isUserInteractionEnabled = false
                    updateImage(imageName: "mandatory-docs-ico.png")
                    addButton.setTitleColor(UIColor.colorFromHex(rgbValue: 0xEB6D72), for: .normal)
                }
            }
        }
        if expiryFlag {
            addButton.isHidden = true
            arrowImageView.isHidden = true
        }
    }
    
    /// Configuring the already matched document cell
    /// - Parameters:
    ///   - mandatoryDoc: document object
    ///   - assignedCredential: assigned credential object
     func configureDocCellForAlreadyMatched(with optionalDoc: RequestedDocument, assignedCredential: AssignedCredential) {
        if let vcid = assignedCredential.vcID {
            if !vcid.isEmpty {
                if let assuranceLevel = assignedCredential.credentialAssuranceLevel {
                    if assuranceLevel == "SELF" {
                        addButton.isHidden = false
                        arrowImageView.isHidden = false
                        addButton.setTitle(Notifications.replace, for: .normal)
                        credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
                        updateImage(imageName: "unofficial_doc_small_ico.png")
                    } else {
                        if let selfSignAccepted = optionalDoc.selfSignedAccepted {
                            credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
                            if assuranceLevel == "ISSUED" {
                                updateImage(imageName: "mandatory-docs-ico.png")
                            } else if assuranceLevel == "VERIFIED"{
                                updateImage(imageName: "mandatory-docs-ico.png")
                            }
                            if selfSignAccepted {
                                addButton.isHidden = false
                                arrowImageView.isHidden = false
                                addButton.setTitle(Notifications.replace, for: .normal)
                            } else {
                                addButton.isHidden = true
                                arrowImageView.isHidden = true
                                //addButton.setTitle("Replace", for: .normal)
                                
                            }
                        }
                        
                    }
                } else {
                    if let selfSignAccepted = optionalDoc.selfSignedAccepted {
                        if selfSignAccepted {
                            updateImage(imageName: "unofficial_doc_small_ico.png")
                        } else {
                            updateImage(imageName: "mandatory-docs-ico.png")
                        }
                    }
                    addButton.isHidden = true
                    arrowImageView.isHidden = true
                    credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
                }
            } else {
                addButton.isHidden = false
                credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
                if let selfSignAccepted = optionalDoc.selfSignedAccepted {
                    if selfSignAccepted {
                        addButton.setTitle(Documents.select, for: .normal)
                        arrowImageView.isHidden = false
                        credentialDocNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
                        updateImage(imageName: "unofficial_doc_small_ico.png")
                    } else {
                        addButton.setTitle(Notifications.notAvailable, for: .normal)
                        arrowImageView.isHidden = true
                        addButton.isUserInteractionEnabled = false
                        addButton.setTitleColor(UIColor.colorFromHex(rgbValue: 0xEB6D72), for: .normal)
                        updateImage(imageName: "mandatory-docs-ico.png")
                    }
                }
            }
            }
     }
}
