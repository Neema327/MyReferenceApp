//
//  DVPresentmentDetailDataSource.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 09/08/19.
//  Data Source class for Presentment Detail screen

import Foundation
import UIKit
protocol DVPresentmentDetailDataSourceDelegate: class {
    func displayAddOrReplaceDocument(with presentmentDocDetails: [String: Any])
    func displayDocumentDetailView(with vcid: String, isOfficial: Bool, docName: String)
    func startMakePresentation()
}
class DVPresentmentDetailDataSource: NSObject {
    var presentmentDetailViewModel: DVPresentmentDetailViewModel?
    var tableView: UITableView?
    weak var delegate: DVPresentmentDetailDataSourceDelegate?
    var alertState: AlertState = .unRead
    var addReplaceSelectedInexPath: IndexPath?
}
extension DVPresentmentDetailDataSource {
    /// Configure the Allow/Expired button depending on the Actionable notification state/all the mandatory docs are matched or not
    /// - Parameter presentmentDetailCell: presentmentDetailCell
    private func configureAllowButtonAndExpiryLabel(presentmentDetailCell: DVPresentmentDetailTableViewCell) {
        if alertState == .actionTaken {
            presentmentDetailCell.allowButton.isHidden = false
            presentmentDetailCell.allowButton.isEnabled = false
            presentmentDetailCell.allowButton.backgroundColor = UIColor.white
            presentmentDetailCell.allowButton.layer.borderColor = UIColor.colorFromHex(rgbValue: 0x78849E).cgColor
            presentmentDetailCell.allowButton.setTitle(Notifications.shared, for: .normal)
            presentmentDetailCell.allowButton.setTitleColor(UIColor.colorFromHex(rgbValue: 0x78849E), for: .normal)
        } else {
            if let exprFlg = presentmentDetailViewModel?.presentmentDetail?.expiryFlag {
                if exprFlg {
                    presentmentDetailCell.allowButton.isHidden = false
                    presentmentDetailCell.allowButton.backgroundColor = UIColor.white
                    presentmentDetailCell.allowButton.layer.borderColor = UIColor.colorFromHex(rgbValue: 0xEB6D72).cgColor
                    presentmentDetailCell.allowButton.setTitle(Notifications.expired, for: .normal)
                    presentmentDetailCell.allowButton.setTitleColor(UIColor.colorFromHex(rgbValue: 0xEB6D72), for: .normal)
                    presentmentDetailCell.allowButton.isEnabled = false
                } else {
                    presentmentDetailCell.delegate = self
                    presentmentDetailCell.allowButton.isHidden = false
                    if let allDocsMatched = presentmentDetailViewModel?.checkWhetherAllMandatoryDocsMatched() {
                        if allDocsMatched {
                            presentmentDetailCell.allowButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF5A623)
                            presentmentDetailCell.allowButton.isEnabled = true
                            presentmentDetailCell.allowButton.layer.borderColor = UIColor.clear.cgColor
                            presentmentDetailCell.allowButton.setTitleColor(UIColor.white, for: .normal)
                        } else {
                             presentmentDetailCell.allowButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xB0B7C4)
                            presentmentDetailCell.allowButton.layer.borderColor = UIColor.clear.cgColor
                            presentmentDetailCell.allowButton.isEnabled = false
                        }
                    }
                }
            }
        }
        if let presentmentDetail = presentmentDetailViewModel?.presentmentDetail {
            presentmentDetailCell.reasonOfReqTitleLabel.text = Notifications.reasonOfRequest
            presentmentDetailCell.reasonOfReqTextLabel.text =  presentmentDetail.purpose ?? ""
        }
    }
}
extension DVPresentmentDetailDataSource: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return presentmentDetailViewModel?.noOfRowsInSection(section: section) ?? 0
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        if let _ =  presentmentDetailViewModel?.presentmentDetail {
            return presentmentDetailViewModel?.noOfSections() ?? 0
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == DVConstants.PresentmentSection.detail.rawValue {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVPresentmentDetailTableViewCell.identifier,
                                                        for: indexPath) as? DVPresentmentDetailTableViewCell {
                cell.configurePresentmentDetailCell(with: presentmentDetailViewModel?.presentmentDetail?.partnerID,
                                                    requestTitle: presentmentDetailViewModel?.presentmentDetail?.title?.en,
                                                    partnerName: presentmentDetailViewModel?.presentmentDetail?.partnerName, createdOn: presentmentDetailViewModel?.presentmentDetail?.lastStatusUpdateDate, expiryFlag: presentmentDetailViewModel?.presentmentDetail?.expiryFlag)
                configureAllowButtonAndExpiryLabel(presentmentDetailCell: cell)
                
                cell.selectionStyle = .none
                return cell
            }
        } else if indexPath.section ==  DVConstants.PresentmentSection.personal.rawValue {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVPresentmentPersonalDetailTableViewCell.identifier,
                                                        for: indexPath) as? DVPresentmentPersonalDetailTableViewCell {
                cell.configurePersonalDetails(with: presentmentDetailViewModel?.presentmentDetail)
                cell.selectionStyle = .none
                return cell
            }
        } else if indexPath.section == DVConstants.PresentmentSection.mandatory.rawValue {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVNotificationMandatoryDocTableViewCell.identifier,
                                                        for: indexPath) as? DVNotificationMandatoryDocTableViewCell {
                cell.arrowImageView.isHidden = true
                if let mandatoryDocuments = presentmentDetailViewModel?.mandatoryDocs {
                    let mandatoryDoc = mandatoryDocuments[indexPath.row]
                    cell.configureDocCell(with: mandatoryDoc, exprFlag: presentmentDetailViewModel?.presentmentDetail?.expiryFlag)
                    if alertState == .actionTaken {
                        cell.addButton.isHidden = true
                        cell.arrowImageView.isHidden = true
                    }
                    cell.delegate = self
                }
                
                cell.selectionStyle = .none
                return cell
            }
        } else if indexPath.section == DVConstants.PresentmentSection.optional.rawValue {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVNotificationOptionalDocTableViewCell.identifier,
                                                        for: indexPath) as? DVNotificationOptionalDocTableViewCell {
                cell.arrowImageView.isHidden = true
                if let optionalDocuments = presentmentDetailViewModel?.optionalDocs {
                    let optionalDoc = optionalDocuments[indexPath.row]
                    cell.configureDocCell(with: optionalDoc, exprFlag: presentmentDetailViewModel?.presentmentDetail?.expiryFlag)
                    if alertState == .actionTaken {
                        cell.addButton.isHidden = true
                        cell.arrowImageView.isHidden = true
                    }
                    cell.delegate = self
                }
                cell.selectionStyle = .none
                return cell
            }
        } else  if indexPath.section == DVConstants.PresentmentSection.additionalInfo.rawValue {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVNotificationDetailTextTableViewCell.identifier,
                                                        for: indexPath) as? DVNotificationDetailTextTableViewCell {
                cell.stackViewBottomConstraint.constant = 0.0
                cell.stackViewTopConstraint.constant = 0.0
                if let presentmentDetail = presentmentDetailViewModel?.presentmentDetail {
                        cell.detailTitleLabel.isHidden = false
                        cell.detailTitleLabel.text = Notifications.requestID
                        cell.detailValueLabel.text =  presentmentDetail.requestID ?? ""
                }
                cell.selectionStyle = .none
                return cell
            }
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        var headerHeight = CGFloat.leastNormalMagnitude
        if (section == DVConstants.PresentmentSection.mandatory.rawValue) {
            let mandatoryDocsCount =   presentmentDetailViewModel?.mandatoryDocs?.count ?? 0
            headerHeight = (mandatoryDocsCount > 0) ? 60 : CGFloat.leastNormalMagnitude
        } else if (section == DVConstants.PresentmentSection.optional.rawValue) {
            let optionalDocsCount =   presentmentDetailViewModel?.optionalDocs?.count ?? 0
            headerHeight = (optionalDocsCount > 0) ? 60 : CGFloat.leastNormalMagnitude
        } else if (section == DVConstants.PresentmentSection.personal.rawValue) {
            var personalDetailsAvailable = false
            if let personalSectionAvailable = presentmentDetailViewModel?.checkWhetherPersonalDetailsAvailable() {
               personalDetailsAvailable = personalSectionAvailable
            }
            headerHeight = (personalDetailsAvailable == true) ? 60 : CGFloat.leastNormalMagnitude
        }
        else if (section == DVConstants.PresentmentSection.additionalInfo.rawValue)  {
            headerHeight = 60
        }
        return headerHeight
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return  CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let defaultSectionHeaderView = UIView(frame: .zero)
        var docsCount = 0
        var personalDetailsAvailable = false
        if (section == DVConstants.PresentmentSection.mandatory.rawValue) {
            docsCount = presentmentDetailViewModel?.mandatoryDocs?.count ?? 0
        } else if section == DVConstants.PresentmentSection.optional.rawValue {
            docsCount = presentmentDetailViewModel?.optionalDocs?.count ?? 0
        }
        if let personalSectionAvailable = presentmentDetailViewModel?.checkWhetherPersonalDetailsAvailable() {
            personalDetailsAvailable = personalSectionAvailable
        }
        if (((section == DVConstants.PresentmentSection.mandatory.rawValue || section == DVConstants.PresentmentSection.optional.rawValue) && docsCount > 0) ||  (section == DVConstants.PresentmentSection.personal.rawValue && personalDetailsAvailable == true) ) {
            if let dvBundle = DVCommon.getDVBundle() {
                guard  let sectionHeaderView = dvBundle.loadNibNamed("DVSectionHeaderView", owner: self, options: nil)?[0] as? DVSectionHeaderView  else {
                    return defaultSectionHeaderView
                }
                if (section == DVConstants.PresentmentSection.mandatory.rawValue || section == DVConstants.PresentmentSection.optional.rawValue) {
                    sectionHeaderView.headerLabel.text = (section == DVConstants.PresentmentSection.mandatory.rawValue) ? Notifications.mandatoryDocs : Notifications.optionalDocs
                } else if section == DVConstants.PresentmentSection.personal.rawValue {
                    sectionHeaderView.headerLabel.text = Notifications.personalDetails
                }
                if DVConstants.uaepassArabicLocalization {
                    sectionHeaderView.headerLabel.font =  UIFont(name: ArabicFont.bold.rawValue, size: 18)
                }
                return sectionHeaderView
            }
        } else if section == DVConstants.PresentmentSection.additionalInfo.rawValue {
            if let dvBundle = DVCommon.getDVBundle() {
                guard  let sectionHeaderView = dvBundle.loadNibNamed("DVPresentmentSectionHeaderView", owner: self, options: nil)?[0] as? DVPresentmentSectionHeaderView  else {
                    return defaultSectionHeaderView
                }
                if DVConstants.uaepassArabicLocalization {
                    sectionHeaderView.headerLabel.font =  UIFont(name: ArabicFont.bold.rawValue, size: 18)
                }
                sectionHeaderView.headerLabel.text = Notifications.additionalInfo
                sectionHeaderView.headerButton.addTarget(self, action: #selector(sectionHeaderButtonTapped(sender:)), for: UIControl.Event.touchUpInside)
                sectionHeaderView.headerButton.tag = section
                sectionHeaderView.toggleRowDetails(toggleState: presentmentDetailViewModel?.presentmentDetail?.isAdditionalInfoSectionExpanded ?? false)
                return sectionHeaderView
            }
        }
        return defaultSectionHeaderView
    }
    
}
// MARK: - UITableViewDataSource Methods
extension DVPresentmentDetailDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}
// MARK: - DVPresentmentDocTableViewCellDelegate Methods
extension DVPresentmentDetailDataSource: DVPresentmentDocTableViewCellDelegate {
    /// Displaying the matched document detail view on tap of the document name of Mandatory/Optional docs
    /// - Parameter cell: selected UITableViewCell
    func showDocDetailAction(cell: UITableViewCell) {
        if let optionalDocCell = cell as? DVNotificationOptionalDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
            if let currentIndexPath = currentTableView.indexPath(for: optionalDocCell) {
                if let selectedDocDetails = presentmentDetailViewModel?.getTheSelectedDocDetails(selectedIndexPath: currentIndexPath) {
                    if let vcid = selectedDocDetails.0 {
                        self.delegate?.displayDocumentDetailView(with: vcid, isOfficial: selectedDocDetails.1, docName: selectedDocDetails.2)
                    }
                }
            }
        } else if let mandatoryDocCell = cell as? DVNotificationMandatoryDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
            if let currentIndexPath = currentTableView.indexPath(for: mandatoryDocCell) {
                if let selectedDocDetails = presentmentDetailViewModel?.getTheSelectedDocDetails(selectedIndexPath: currentIndexPath) {
                    if let vcid = selectedDocDetails.0 {
                        self.delegate?.displayDocumentDetailView(with: vcid, isOfficial: selectedDocDetails.1, docName: selectedDocDetails.2)
                    }
                }
            }
        }
    }
    /// Add/Replace document selection navigation
    /// - Parameters:
    ///   - sender: selected button
    ///   - cell:   selected  cell
    func addButtonAction(sender: UIButton, cell: UITableViewCell) {
        if let optionalDocCell = cell as? DVNotificationOptionalDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
            if let currentIndexPath = currentTableView.indexPath(for: optionalDocCell) {
                if let docs = presentmentDetailViewModel?.optionalDocs {
                    let currentDoc = docs[currentIndexPath.row]
                    guard  let alertMessageId = presentmentDetailViewModel?.presentmentDetail?.id, let documentId = currentDoc.requestedDocumentID else {
                        return
                    }
                    let requestDetailsDict = [DVConstants.requestIdKey: String(alertMessageId), DVConstants.documentIdKey: String(documentId), DVConstants.selfSignAcceptKey: currentDoc.selfSignedAccepted ?? false] as [String: Any]
                    self.addReplaceSelectedInexPath = currentIndexPath
                    self.delegate?.displayAddOrReplaceDocument(with: requestDetailsDict)
                }
            }
        } else  if let mandatoryDocCell = cell as? DVNotificationMandatoryDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
            if let currentIndexPath = currentTableView.indexPath(for: mandatoryDocCell) {
                if let docs = presentmentDetailViewModel?.mandatoryDocs {
                    let currentDoc = docs[currentIndexPath.row]
                    guard  let alertMessageId = presentmentDetailViewModel?.presentmentDetail?.id, let documentId = currentDoc.requestedDocumentID else {
                        return
                    }
                    let requestDetailsDict = [DVConstants.requestIdKey: String(alertMessageId), DVConstants.documentIdKey: String(documentId), DVConstants.selfSignAcceptKey: currentDoc.selfSignedAccepted ?? false] as [String: Any]
                    self.addReplaceSelectedInexPath = currentIndexPath
                    self.delegate?.displayAddOrReplaceDocument(with: requestDetailsDict)
                }
            }
        }
    }
}
// MARK: - DVPresentmentDetailTableViewCellDelegate Methods
extension DVPresentmentDetailDataSource: DVPresentmentDetailTableViewCellDelegate {
    /// Allow button action to share the presentation request
    /// - Parameter index: selected button tag
    func performAllowButtonAction(index: Int) {
        self.delegate?.startMakePresentation()
    }
}

// MARK: - Action Methods
extension DVPresentmentDetailDataSource {
    /// Header button tap action to reload the section to expand/collapse the particular section
    /// - Parameter sender: clicked button
    @objc func sectionHeaderButtonTapped(sender: UIButton) {
        if let isSectionExpanded = presentmentDetailViewModel?.presentmentDetail?.isAdditionalInfoSectionExpanded {
            presentmentDetailViewModel?.presentmentDetail?.isAdditionalInfoSectionExpanded = !isSectionExpanded
        }
        let indexSet: IndexSet = [sender.tag]
        self.tableView?.reloadSections(indexSet, with: .automatic)
    }
}
