//
//  DVPresentmentPersonalDetailTableViewCell.swift
//  DigitalVaultFramework
//
//  Created by Neema Naidu on 08/08/19.
//  TablView cell class for the Personal Details section of Presentment Detail screen
//

import UIKit

class DVPresentmentPersonalDetailTableViewCell: UITableViewCell {
    @IBOutlet weak var emailIconView: UIImageView!
    @IBOutlet weak var phoneIconView: UIImageView!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        phoneNumberLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        emailLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        if DVConstants.uaepassArabicLocalization {
            phoneNumberLabel.font =  UIFont(name: ArabicFont.regular.rawValue, size: 18)
            emailLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 18)
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }

    static var identifier: String {
        return String(describing: self)
    }
    
    /// Configure the Personal Details section
    /// - Parameter presenmentDetails: presenmentDetails object
    func configurePersonalDetails(with presenmentDetails: DVPresentmentDetail?) {
        if let verifiedAttributes = presenmentDetails?.verifiedAttributes {
            if let emailText = verifiedAttributes.emailID {
                if emailText.isEmpty {
                    emailLabel.text = DVConstants.Strings.emptyString
                    emailIconView.image = nil
                } else {
                    emailLabel.text = emailText
                    emailIconView.image = DVCommon.getImage(named: "email_ico")
                }
            } else {
                emailLabel.text = DVConstants.Strings.emptyString
                emailIconView.image = nil
            }
            if let phoneText = verifiedAttributes.mobileNumber {
                if phoneText.isEmpty {
                    phoneNumberLabel.text = DVConstants.Strings.emptyString
                    phoneIconView.image = nil
                } else {
                    phoneNumberLabel.text = phoneText
                    phoneIconView.image = DVCommon.getImage(named: "mobile_ico")
                }
            } else {
                phoneNumberLabel.text = DVConstants.Strings.emptyString
                phoneIconView.image = nil
            }
        } else {
            emailLabel.text = DVConstants.Strings.emptyString
            emailIconView.image = nil
            phoneNumberLabel.text = DVConstants.Strings.emptyString
            phoneIconView.image = nil
        }
    }
}
