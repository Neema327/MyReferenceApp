//
//  DVPresentmentDetailViewModel.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 12/08/19.
//  View Model class for Presentmnet Details Screen

import Foundation
import PromiseKit
struct DVPresentmentAddModel: Codable {
    var vcId: String
}

class DVPresentmentDetailViewModel {
    var presentmentDetail: DVPresentmentDetail?
    var makePresentmentDetail: DVMakePresentmentDetails?
    let dataConverterHelper = DataConverterHelper() as DataConverter
    var mandatoryDocs: [RequestedDocument]?
    var optionalDocs: [RequestedDocument]?
    var alertMessageId: String?
    var isNotificationFlow = false
}

extension DVPresentmentDetailViewModel {
    func fetchPresentmentDetailsData(completionHandler: @escaping SuccessClosure,
                               failureHandler: @escaping FailureClosure) {
        self.getPresentmentDetails(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    func updateNotificationState(completionHandler: @escaping SuccessClosure,
                                 failureHandler: @escaping FailureClosure) {
        self.updateNotState(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func makePresentment(completionHandler: @escaping SuccessClosure,
                         failureHandler: @escaping FailureClosure) {
        self.makePresenmentService(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func sharePresentment(statusMessage: String, completionHandler: @escaping SuccessClosure,
                         failureHandler: @escaping FailureClosure) {

        guard let documents = self.makePresentmentDetail?.documents, let documentId = documents[0].id else {
            failureHandler(false, dvDataError)
            return
        }

        self.sharePresenmentService(statusMessage: statusMessage, documentId: documentId, completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func checkStatus(url: String, completionHandler: @escaping SuccessClosure,
                     failureHandler: @escaping FailureClosure) {
        
        if let urlComponents = URLComponents(string: url),let queryItems = urlComponents.queryItems, let processId = queryItems[0].value {
            
            presentmentStatusCheck(processId: processId).done({ (urlStatus) in
                
                if let status = urlStatus as? Bool {
                    NSLog("presentmentStatusCheck: \(status)")
                    completionHandler(status, "")
                } else {
                    let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
                    failureHandler(false, error)
                }
                
            }) .catch { (error) in
                failureHandler(false, error)
            }
        }
    }
    private func getPresentmentDetails(completionHandler: @escaping SuccessClosure,
                                          failureHandler: @escaping FailureClosure) {
            self.invokeServiceForPresentmentDetails()
                .done({ (presentmentData) in
                    guard let presentmentDetails = presentmentData as? DVPresentmentDetail else {
                        failureHandler(false, dvDataError)
                        return
                    }
                    self.presentmentDetail = presentmentDetails
                    self.getMandatoryAndOptionalDocsList()
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }

    private func invokeServiceForPresentmentDetails() -> Promise<Any> {
        return Promise {  seal in
            guard let alertMsgId = alertMessageId else {
                let error = NSError(domain: dvErrorDomain, code: 0, userInfo: [NSLocalizedDescriptionKey: "message"])
                seal.reject(error)
                return
            }
            let serviceURL: String =  baseURL + apiVersion + (DVCommon.isPresentmentAppToAppFlow || isNotificationFlow ?   EndPoint.appToAppPresentmentDetails.rawValue : EndPoint.presentmentDetails.rawValue) + "\(alertMsgId)"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVPresentmentDetail?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                (jsonResponse, respError) in
                //Decode server response
                DVCommon.decodeResponse(type: DVPresentmentDetail.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (presentmentDetails) in
                        seal.fulfill(presentmentDetails)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    private func updateNotState(completionHandler: @escaping SuccessClosure,
                                failureHandler: @escaping FailureClosure) {
            self.invokeServiceForUpdateNotificationState()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }
    private func makePresenmentService(completionHandler: @escaping SuccessClosure,
                                       failureHandler: @escaping FailureClosure) {
        self.invokeServiceForMakePresentment()
            .done({ (makePresentmentData) in

                guard let presentmentDetails = makePresentmentData as? DVMakePresentmentDetails,
                    let _ = presentmentDetails.documents?[0].id,
                    let _ = presentmentDetails.tasks?.pending?[0].url else {
                    failureHandler(false, dvDataError)
                    return
                }
                self.makePresentmentDetail = presentmentDetails
                completionHandler(true, "")
            })
            .catch { error in
                failureHandler(false, error) //need to change
        }
    }
    
    private func sharePresenmentService(statusMessage: String, documentId: String, completionHandler: @escaping SuccessClosure,
                                        failureHandler: @escaping FailureClosure) {
        self.invokeServiceForSharePresentment(statusMessage: statusMessage, documentId: documentId)
            .done({ (sharePresentmentData) in
                guard let sharePresentmentDetails = sharePresentmentData as? DVSharePresentmentDetails, let shareStatus = sharePresentmentDetails.status else {
                    failureHandler(false, dvDataError)
                    return
                }
                if shareStatus == "SHARED" {
                    completionHandler(true, "")
                } else {
                    failureHandler(false, dvDataError)
                }
            })
            .catch { error in
                failureHandler(false, error) //need to change
            }
    }

    private func invokeServiceForUpdateNotificationState() -> Promise<Any> {
        return Promise {  seal in
            guard let alertMsgId = alertMessageId else {
                return
            }
            let serviceURL: String =  baseURL + apiVersion + EndPoint.updateNotificationState.rawValue + alertMsgId + "?state=READ"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            headerParams[authorization] = DVCommon.bearerToken

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                ( jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVPresentmentDetail.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    func invokeServiceForMakePresentment() -> Promise<Any> {
        return Promise {  seal in
            guard let reqId = presentmentDetail?.id else {
                return
            }
            let serviceURL: String =  baseURL + apiVersion + EndPoint.makePresentment.rawValue + "\(reqId)"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            headerParams[authorization] = DVCommon.bearerToken
            headerParams[content] = ContentType.json.rawValue

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.POST) {
                (jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVMakePresentmentDetails.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    func invokeServiceForSharePresentment(statusMessage: String, documentId: String) -> Promise<Any> {
        return Promise {  seal in
            let serviceURL: String =  baseURL + apiVersion + EndPoint.sharePresentment.rawValue + "\(documentId)" + "&status=\(statusMessage)"

            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken
            headerParams[content] = ContentType.json.rawValue

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.POST) {
                (jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSharePresentmentDetails.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    
    func presentmentStatusCheck(processId: String) -> Promise<Any> {
        return Promise { seal in
            
            self.invokeServiceForStatusCheck(processId: processId).done({ (urlStatus) in
                if let urlStatus = urlStatus as? DVPresentmentUrlStatusCheck {
                    seal.fulfill(urlStatus.signingRequired as Any)
                } else {
                    let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
                    seal.reject(error)
                }
            }) .catch { error in
                seal.reject(error)
            }
        }
    }
    
    func invokeServiceForStatusCheck(processId: String) -> Promise<Any> {
        return Promise {  seal in
            
            let serviceURL: String = baseURL + apiVersion + EndPoint.processIdStatusCheck.rawValue + "\(processId)"
            
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            
            headerParams[authorization] = DVCommon.bearerToken
            headerParams[content] = ContentType.json.rawValue
            
            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                
                DVCommon.decodeResponse(type: DVPresentmentUrlStatusCheck.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (urlStatus) in
                        seal.fulfill(urlStatus)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }

}
extension DVPresentmentDetailViewModel {
    func getMandatoryAndOptionalDocsList() {
        guard let requiredDocsArray = self.presentmentDetail?.requestedDocuments else {
            return
        }
        var mandatoryDocsList = [RequestedDocument]()
        var optionalDocsList = [RequestedDocument]()
        for (index, var doc) in requiredDocsArray.enumerated() {
            doc.originalIndex = index
            if let required = doc.requestedDocumentRequired {
                if required {
                    mandatoryDocsList.append(doc)
                } else {
                    optionalDocsList.append(doc)
                }
            }
        }
        mandatoryDocs = mandatoryDocsList
        optionalDocs = optionalDocsList
    }

    func noOfRowsInSection(section: Int) -> Int {
        var noOfRows = 0
        if section == DVConstants.PresentmentSection.detail.rawValue ||  section == DVConstants.PresentmentSection.personal.rawValue {
            noOfRows = 1
        } else if section == DVConstants.PresentmentSection.mandatory.rawValue {
            noOfRows = mandatoryDocs?.count ?? 0
        } else if section == DVConstants.PresentmentSection.optional.rawValue {
            noOfRows = optionalDocs?.count ?? 0
        } else if section == DVConstants.PresentmentSection.additionalInfo.rawValue {
            noOfRows = 0
            if let isSectionExpanded = presentmentDetail?.isAdditionalInfoSectionExpanded {
                if isSectionExpanded {
                    noOfRows = 1
                }
            }
        }
        return noOfRows
    }
    func noOfSections() -> Int {
        return 5
    }
    func checkWhetherAllMandatoryDocsMatched() -> Bool {
        var allMandatoryDocsMatched = false
        guard let mandatoryDocuments = mandatoryDocs else {
            return false
        }
        if mandatoryDocuments.count == 0 {
            return true
        }
        for doc in mandatoryDocuments {
            if let assignedCredential = doc.assignedCredential {
                if let vcid = assignedCredential.vcID {
                    if !vcid.isEmpty {
                        allMandatoryDocsMatched = true
                    } else {
                        allMandatoryDocsMatched = false
                        break
                    }
                } else {
                    allMandatoryDocsMatched = false
                    break
                }
            } else {
                allMandatoryDocsMatched = false
                break
            }
        }
        return allMandatoryDocsMatched
    }
    func checkWhetherPersonalDetailsAvailable() -> Bool {
       var pesonalDetailAvailable = false
       guard let personalDetails = presentmentDetail?.verifiedAttributes else {
           return false
       }
       if let emailText = personalDetails.emailID {
        if !emailText.isEmpty {
            pesonalDetailAvailable = true
        }
       }
       if let mobileNumText = personalDetails.mobileNumber {
         if !mobileNumText.isEmpty {
             pesonalDetailAvailable = true
         }
        }
        return pesonalDetailAvailable
    }
    func getTheSelectedDocDetails(selectedIndexPath: IndexPath) -> (String?, Bool, String) {
        var selectedDocVcid: String?
        var isOfficial = false
        var selectedDoc: RequestedDocument?
        if selectedIndexPath.section == 2 { //mandatory doc
            if let selDoc = mandatoryDocs?[selectedIndexPath.row] {
                selectedDoc = selDoc
            }
        } else if selectedIndexPath.section == 3 { //optional doc
            if let selDoc = optionalDocs?[selectedIndexPath.row] {
                 selectedDoc = selDoc
            }
        }
        if let assignedCredential = selectedDoc?.assignedCredential {
            if let vcId = assignedCredential.vcID {
                if !vcId.isEmpty {
                    if let vaultCredType = assignedCredential.credentialAssuranceLevel {
                        selectedDocVcid = vcId
                        isOfficial = (vaultCredType == "ISSUED" || vaultCredType == "VERIFIED") ? true : false
                    }
            }
        }
    }
        return (selectedDocVcid, isOfficial, selectedDoc?.documentName ?? "")
    }
    func  getTheAlertState(stateAlert: String?) -> AlertState {
        var alertState: AlertState = .unRead
        guard let alertStatus = stateAlert else {
            return .unRead
        }
        if alertStatus == DVConstants.stateRead {
            alertState = .read
        } else if alertStatus == DVConstants.stateUnRead {
            alertState = .unRead
        } else if alertStatus == DVConstants.stateActionTaken {
            alertState = .actionTaken
        }
        return alertState
    }

    func getPresentmentShareUrl() -> String? {
        guard let pendingUrl = makePresentmentDetail?.tasks?.pending?[0].url else {
            return nil
        }
        return pendingUrl
    }
    func prepareSuccessMessage() -> String? {
        var successMsg: String?
        guard let presentmentDetail = presentmentDetail else {
            return successMsg
        }
        successMsg = Notifications.shareSuccessMessage  + " \(presentmentDetail.partnerName ?? "")"
        return successMsg
    }

    func getLoaderMessage() -> String {
        var successMsg: String = ""
        guard let presentmentDetail = presentmentDetail else {
            return successMsg
        }
        successMsg = LoaderMessages.shareFlow  + " \(presentmentDetail.partnerName ?? "")"
        return successMsg
    }

}
