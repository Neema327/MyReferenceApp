//
//  DVSectionHeaderView.swift
//  DigitalVaultFramework
//
//  Created by Neema on 7/18/19.
//  Section Header View class for Presentment Detail screen

import UIKit

class DVSectionHeaderView: UIView {
    @IBOutlet var headerLabel: UILabel!
}
