//
//  DVPresentmentSectionHeaderView.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 09/08/19.
//  Section Header View class for Presentment Detail screen

import UIKit

class DVPresentmentSectionHeaderView: UIView {
    @IBOutlet var headerLabel: UILabel!
    @IBOutlet weak var headerButton: UIButton!
    @IBOutlet weak var disclosureImageView: UIImageView!
    func toggleRowDetails(toggleState: Bool) {
        if toggleState {
            UIView.animate(withDuration: 2) { () -> Void in
                self.disclosureImageView.image = DVCommon.getImage(named: "AdditionalInfo_expand.png")//UIImage(named :"Disclosure-expand")
                let angle =  CGFloat(Double.pi * 2)
                let tranformValue = CGAffineTransform.identity.rotated(by: angle)
                self.disclosureImageView.transform = tranformValue
            }
        } else {
            UIView.animate(withDuration: 2) { () -> Void in
                self.disclosureImageView.image = DVCommon.getImage(named: "AdditionalInfo_collapse.png")//UIImage(named :"Disclosure-Indicator-collapse")
                let angle =  CGFloat(Double.pi * 2)
                let tranformValue = CGAffineTransform.identity.rotated(by: angle)
                self.disclosureImageView.transform = tranformValue
            }
        }
    }
}
