//
//  DVMakePresentmentDetails.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 03/09/19.
//

import Foundation

// MARK: - DVMakePresentmentDetails
struct DVMakePresentmentDetails: Codable {
    let tasks: Tasks?
    let documents: [Document]?
}

// MARK: DVMakePresentmentDetails convenience initializers and mutators

extension DVMakePresentmentDetails {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVMakePresentmentDetails.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        tasks: Tasks?? = nil,
        documents: [Document]?? = nil
        ) -> DVMakePresentmentDetails {
        return DVMakePresentmentDetails(
            tasks: tasks ?? self.tasks,
            documents: documents ?? self.documents
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Document
struct Document: Codable {
    let id: String?
}

// MARK: Document convenience initializers and mutators

extension Document {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(Document.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: String?? = nil
        ) -> Document {
        return Document(
            id: id ?? self.id
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Tasks
struct Tasks: Codable {
    let pending: [Pending]?
}

// MARK: Tasks convenience initializers and mutators

extension Tasks {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(Tasks.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        pending: [Pending]?? = nil
        ) -> Tasks {
        return Tasks(
            pending: pending ?? self.pending
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Pending
struct Pending: Codable {
    let url: String?
}

// MARK: Pending convenience initializers and mutators

extension Pending {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(Pending.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        url: String?? = nil
        ) -> Pending {
        return Pending(
            url: url ?? self.url
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
