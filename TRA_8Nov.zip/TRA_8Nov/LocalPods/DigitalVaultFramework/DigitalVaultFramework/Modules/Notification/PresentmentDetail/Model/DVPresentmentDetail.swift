//
//  DVPresentmentDetail.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 28/08/19.

import Foundation

struct VerifiedAttributes: Codable {
    let emailID, mobileNumber: String?
    enum CodingKeys: String, CodingKey {
        case emailID = "email"
        case mobileNumber = "mobile"
    }
}

// MARK: - DVPresentmentDetail
struct DVPresentmentDetail: Codable {
    // MARK: - VerifiedAttributes
    let id: Int?
    let requestedDocuments: [RequestedDocument]?
    let purpose, type, dvPresentmentDetailProtocol: String?
    let partnerAuth: PartnerAuth?
    let verifiedAttributes: VerifiedAttributes?
    let partnerID, recipient, expiryDate, partnerName: String?
    let proofOfPresentationRequestID: String?
    let title: PresentmentTitle?
    let createdOn: String?
    let lastStatusUpdateDate: String?
    let expiryFlag: Bool?
    let state, requestID: String?
    var isAdditionalInfoSectionExpanded = false
    enum CodingKeys: String, CodingKey {
        case id, requestedDocuments, purpose, type
        case dvPresentmentDetailProtocol = "protocol"
        case partnerAuth, verifiedAttributes
        case partnerID = "partnerId"
        case recipient, expiryDate, partnerName
        case proofOfPresentationRequestID = "proofOfPresentationRequestId"
        case title, createdOn, expiryFlag, state, lastStatusUpdateDate
        case requestID = "requestId"
    }
}

// MARK: DVPresentmentDetail convenience initializers and mutators

extension DVPresentmentDetail {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVPresentmentDetail.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: Int?? = nil,
        requestedDocuments: [RequestedDocument]?? = nil,
        purpose: String?? = nil,
        type: String?? = nil,
        dvPresentmentDetailProtocol: String?? = nil,
        partnerAuth: PartnerAuth?? = nil,
        verifiedAttributes: VerifiedAttributes?? = nil,
        partnerID: String?? = nil,
        recipient: String?? = nil,
        expiryDate: String?? = nil,
        partnerName: String?? = nil,
        proofOfPresentationRequestID: String?? = nil,
        title: PresentmentTitle?? = nil,
        createdOn: String?? = nil,
        lastStatusUpdateDate: String?? = nil,
        expiryFlag: Bool?? = nil,
        state: String?? = nil,
        requestID: String?? = nil
        ) -> DVPresentmentDetail {
        return DVPresentmentDetail(
            id: id ?? self.id,
            requestedDocuments: requestedDocuments ?? self.requestedDocuments,
            purpose: purpose ?? self.purpose,
            type: type ?? self.type,
            dvPresentmentDetailProtocol: dvPresentmentDetailProtocol ?? self.dvPresentmentDetailProtocol,
            partnerAuth: partnerAuth ?? self.partnerAuth,
            verifiedAttributes: verifiedAttributes ?? self.verifiedAttributes,
            partnerID: partnerID ?? self.partnerID,
            recipient: recipient ?? self.recipient,
            expiryDate: expiryDate ?? self.expiryDate,
            partnerName: partnerName ?? self.partnerName,
            proofOfPresentationRequestID: proofOfPresentationRequestID ?? self.proofOfPresentationRequestID,
            title: title ?? self.title,
            createdOn: createdOn ?? self.createdOn,
            lastStatusUpdateDate: lastStatusUpdateDate ?? self.lastStatusUpdateDate,
            expiryFlag: expiryFlag ?? self.expiryFlag,
            state: state ?? self.state,
            requestID: requestID ?? self.requestID,
            isAdditionalInfoSectionExpanded: self.isAdditionalInfoSectionExpanded
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
// MARK: - PresentmentTitle
struct PresentmentTitle: Codable {
    let en, ar: String?
}

// MARK: PresentmentTitle convenience initializers and mutators

extension PresentmentTitle {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PresentmentTitle.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        en: String?? = nil,
        ar: String?? = nil
        ) -> Title {
        return Title(
            en: en ?? self.en,
            ar: ar ?? self.ar
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - PartnerAuth
struct PartnerAuth: Codable {
}

// MARK: PartnerAuth convenience initializers and mutators

extension PartnerAuth {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PartnerAuth.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        ) -> PartnerAuth {
        return PartnerAuth(
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: VerifiedAttributes convenience initializers and mutators

extension VerifiedAttributes {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(VerifiedAttributes.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        emailID: String?? = nil,
        mobileNumber: String?? = nil
        ) -> VerifiedAttributes {
        return VerifiedAttributes(
            emailID: emailID ?? self.emailID,
            mobileNumber: mobileNumber ?? self.mobileNumber
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - RequestedDocument
struct RequestedDocument: Codable {
    let selectedLocaleName: String?
    let requestedDocumentRequired, selfSignedAccepted: Bool?
    let assignedCredential: AssignedCredential?
    let documentName: String?
    let requestedDocumentID: Int?
    var originalIndex: Int?
    enum CodingKeys: String, CodingKey {
        case selectedLocaleName
        case requestedDocumentRequired = "required"
        case selfSignedAccepted, assignedCredential, documentName
        case requestedDocumentID = "requestedDocumentId"
    }
}

// MARK: RequestedDocument convenience initializers and mutators

extension RequestedDocument {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(RequestedDocument.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        selectedLocaleName: String?? = nil,
        requestedDocumentRequired: Bool?? = nil,
        selfSignedAccepted: Bool?? = nil,
        assignedCredential: AssignedCredential?? = nil,
        documentName: String?? = nil,
        requestedDocumentID: Int?? = nil
        ) -> RequestedDocument {
        return RequestedDocument(
            selectedLocaleName: selectedLocaleName ?? self.selectedLocaleName,
            requestedDocumentRequired: requestedDocumentRequired ?? self.requestedDocumentRequired,
            selfSignedAccepted: selfSignedAccepted ?? self.selfSignedAccepted,
            assignedCredential: assignedCredential ?? self.assignedCredential,
            documentName: documentName ?? self.documentName,
            requestedDocumentID: requestedDocumentID ?? self.requestedDocumentID,
            originalIndex: originalIndex ?? self.originalIndex
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - AssignedCredential
struct AssignedCredential: Codable {
    let context: [String]?
    let vcID: String?
    let credentialExpiryDate: String?
    let credentialAssuranceLevel: String?
    let credentialDocumentType: CredentialDocumentType?
    let proofOfIssuanceID: String?

    enum CodingKeys: String, CodingKey {
        case context = "@context"
        case vcID = "vcId"
        case credentialExpiryDate, credentialAssuranceLevel, credentialDocumentType
        case proofOfIssuanceID = "ProofOfIssuanceId"
    }
}

// MARK: AssignedCredential convenience initializers and mutators

extension AssignedCredential {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(AssignedCredential.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        context: [String]?? = nil,
        vcID: String?? = nil,
        credentialExpiryDate: String?? = nil,
        credentialAssuranceLevel: String?? = nil,
        credentialDocumentType: CredentialDocumentType?? = nil,
        proofOfIssuanceID: String?? = nil
        ) -> AssignedCredential {
        return AssignedCredential(
            context: context ?? self.context,
            vcID: vcID ?? self.vcID,
            credentialExpiryDate: credentialExpiryDate ?? self.credentialExpiryDate,
            credentialAssuranceLevel: credentialAssuranceLevel ?? self.credentialAssuranceLevel,
            credentialDocumentType: credentialDocumentType ?? self.credentialDocumentType,
            proofOfIssuanceID: proofOfIssuanceID ?? self.proofOfIssuanceID
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - CredentialDocumentType
struct CredentialDocumentType: Codable {
    let selectedLocaleName: String?
}

// MARK: CredentialDocumentType convenience initializers and mutators

extension CredentialDocumentType {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(CredentialDocumentType.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        selectedLocaleName: String?? = nil
        ) -> CredentialDocumentType {
        return CredentialDocumentType(
            selectedLocaleName: selectedLocaleName ?? self.selectedLocaleName
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
