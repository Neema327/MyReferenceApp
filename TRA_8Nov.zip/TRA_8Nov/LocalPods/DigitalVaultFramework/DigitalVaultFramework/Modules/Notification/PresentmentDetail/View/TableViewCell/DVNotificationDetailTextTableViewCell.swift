//
//  DVNotificationDetailTextTableViewCell.swift
//  DigitalVaultFramework
//
//  Created by Lija on 25/06/19.
//  TablView cell class for Notification/Presentment Details screen
//

import UIKit

class DVNotificationDetailTextTableViewCell: UITableViewCell {

    @IBOutlet weak var detailTitleLabel: UILabel!
    @IBOutlet weak var detailValueLabel: UILabel!
    @IBOutlet weak var stackViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var stackViewTopConstraint: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()
        detailTitleLabel.textColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        if DVConstants.uaepassArabicLocalization {
            detailTitleLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 16.0)
            detailValueLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)
        }
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }

    static var identifier: String {
        return String(describing: self)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    /// method to configure notification detail values
    ///
    /// - Parameters:
    ///   - notificationDetail: DVNotificationDetail object
    ///   - indexPath: selected IndexPath
    func configureNotificationDetailValues(notificationDetail: DVNotificationDetail, indexPath: IndexPath) {
        stackViewTopConstraint.constant = 30.0
        stackViewBottomConstraint.constant = 0.0
        if indexPath.row == 1 {
                detailTitleLabel.text = Notifications.requestID
                detailValueLabel.text = notificationDetail.requestID ?? ""
        } else if indexPath.row == 2 {
                detailTitleLabel.text = Notifications.reason
                if DVConstants.uaepassArabicLocalization {
                   detailValueLabel.text =  notificationDetail.reason?.ar ?? ""
                } else {
                    detailValueLabel.text =  notificationDetail.reason?.en ?? ""
                }
        } else if indexPath.row == 3 {
                detailTitleLabel.text = ""
                detailValueLabel.text = ""
        }
    }
}
