//
//  DVNotificationDetailViewController.swift
//  Alamofire
//
//  Created by Neema Naidu on 13/08/19.
//  View class for displaying non actionable notification detail view

import UIKit

class DVNotificationDetailViewController: DVBaseViewController {
    @IBOutlet var notificationDetailTableView: UITableView!
    @IBOutlet var subTitleLabel: UILabel!
    var notificationDetailViewModel = DVNotificationDetailViewModel()
    var notificationListViewModel = DVNotificationListViewModel()
    var  alertMessageId: String?
    var  dateStr: String?
    var  state: String?

    lazy private var notificationDetailDataSource: DVNotificationDetailDataSource = {
        let officialDataSrc = DVNotificationDetailDataSource()
        return officialDataSrc
    }()
    lazy private var activityIndicatorView: DVProgressIndicatorView = {
        let progressIndicatorView = DVProgressIndicatorView()
        return progressIndicatorView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        applyNavBarStyle()
        subTitleLabel.text = Notifications.viewDetails
        notificationDetailViewModel.alertMessageId = alertMessageId
        activityIndicatorView.addActivityIndicatorToTheView(view: self.view)
        notificationDetailTableView.setViewsLayer(layer: notificationDetailTableView.layer, shouldLayerBorderClearColor: true)
       (state == DVConstants.stateUnRead) ? updateNotificationState() : loadNotificationDetailDocsData()
        configureLocalizationFont()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}
// MARK: - Private Methods
extension DVNotificationDetailViewController {
    /// method for adding localization fonts and styles
    func configureLocalizationFont() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            subTitleLabel.font = UIFont(name:ArabicFont.twoMedium.rawValue, size: 35.0)
        }
    }
    /// method for configuring UI elements
    func configureNotificationDetailView() {
        UITableView.registerCellWithIdentifier(cellIdentifier: DVNotificationDetailTextTableViewCell.identifier, tblVw: self.notificationDetailTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: DVNotificationListTableViewCell.identifier, tblVw: self.notificationDetailTableView)
        self.notificationDetailDataSource.notificationDetailViewModel = self.notificationDetailViewModel
        notificationDetailTableView.estimatedRowHeight = 220
        self.notificationDetailDataSource.tableView = self.notificationDetailTableView
        self.notificationDetailTableView.delegate = self.notificationDetailDataSource
        self.notificationDetailTableView.dataSource = self.notificationDetailDataSource
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        notificationDetailTableView.setUpRoundedCornerView(view: notificationDetailTableView)
    }
    /// apply navigation bar font and style
    private func applyNavBarStyle () {
        let topHeaderBGImg = DVCommon.getImage(named: "top-header-bg.png")
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(topHeaderBGImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        self.navigationController?.navigationBar.isTranslucent = false
    }
}
// MARK: - Service Methods
extension DVNotificationDetailViewController {
    /// method to trigger service call for unread notification count
    private func loadNotificationUnreadCount() {
        DVEventHandler.sharedInstance.getNotificationCount()
    }
    /// method to trigger service call for notification detail data
    func loadNotificationDetailDocsData() {
        displayActivityIndicatorView()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.notificationDetailViewModel.fetchNotificationDetailData(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.configureNotificationDetailView()
                    self?.notificationDetailTableView.reloadData()
                    self?.loadNotificationUnreadCount()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.notificationDetailTableView.reloadData()
                    self?.loadNotificationUnreadCount()
                    DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                }
            })
        }
    }
    /// method to trigger service call for updating notification state
    func updateNotificationState() {
        displayActivityIndicatorView()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.notificationDetailViewModel.updateNotificationState(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVConstants.notificationState = .nonactionableRead
                    self?.hideActivityIndicatorView()
                    self?.loadNotificationDetailDocsData()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                }
            })
        }
    }
    
}
// MARK: - Loader Methods
extension DVNotificationDetailViewController {
    /// method to hide show ActivityIndicatorView
    func displayActivityIndicatorView() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
    }
    func hideActivityIndicatorView() {
        DVCommon.hideActivityIndicatorView()
    }
}

