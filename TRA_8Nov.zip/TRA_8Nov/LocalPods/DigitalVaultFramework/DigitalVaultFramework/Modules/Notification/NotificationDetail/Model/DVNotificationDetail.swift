// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try Welcome(json)

//  Model Class for Notification detail module

import Foundation

// MARK: - Welcome
struct DVNotificationDetail: Codable {
    let id: Int?
    let state, alertMessageType, alertMessageSubType, type: String?
    let welcomeProtocol: String?
    let partnerAutho, sector: PartnerAutho?
    let partnerContactInf: PartnerContactInf?
    let partnerID: String?
    let citizenProfile: CitizenProfile?
    let partnerName: String?
    let title, message, reason: Message?
    let requestID, expiryDate: String?
    let expiryFlag: Bool?
    let createdOn: String?
    let lastStatusUpdateDate: String?

    enum CodingKeys: String, CodingKey {
        case id, state, alertMessageType, alertMessageSubType, type
        case welcomeProtocol = "protocol"
        case sector
        case partnerID = "partnerId"
        case partnerAutho = "partnerAuth"
        case partnerContactInf = "partnerContactInfo"
        case citizenProfile, partnerName, title, message, reason
        case requestID = "requestId"
        case expiryDate, expiryFlag, createdOn, lastStatusUpdateDate
    }
}

// MARK: Welcome convenience initializers and mutators

extension DVNotificationDetail {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVNotificationDetail.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: Int?? = nil,
        state: String?? = nil,
        alertMessageType: String?? = nil,
        alertMessageSubType: String?? = nil,
        type: String?? = nil,
        welcomeProtocol: String?? = nil,
        partnerAutho: PartnerAutho?? = nil,
        sector: PartnerAutho?? = nil,
        partnerContactInf: PartnerContactInf?? = nil,
        partnerID: String?? = nil,
        citizenProfile: CitizenProfile?? = nil,
        partnerName: String?? = nil,
        title: Message?? = nil,
        message: Message?? = nil,
        reason: Message?? = nil,
        requestID: String?? = nil,
        expiryDate: String?? = nil,
        expiryFlag: Bool?? = nil,
        createdOn: String?? = nil,
        lastStatusUpdateDate: String?? = nil
        ) -> DVNotificationDetail {
        return DVNotificationDetail(
            id: id ?? self.id,
            state: state ?? self.state,
            alertMessageType: alertMessageType ?? self.alertMessageType,
            alertMessageSubType: alertMessageSubType ?? self.alertMessageSubType,
            type: type ?? self.type,
            welcomeProtocol: welcomeProtocol ?? self.welcomeProtocol,
            partnerAutho: partnerAutho ?? self.partnerAutho,
            sector: sector ?? self.sector,
            partnerContactInf: partnerContactInf ?? self.partnerContactInf,
            partnerID: partnerID ?? self.partnerID,
            citizenProfile: citizenProfile ?? self.citizenProfile,
            partnerName: partnerName ?? self.partnerName,
            title: title ?? self.title,
            message: message ?? self.message,
            reason: reason ?? self.reason,
            requestID: requestID ?? self.requestID,
            expiryDate: expiryDate ?? self.expiryDate,
            expiryFlag: expiryFlag ?? self.expiryFlag,
            createdOn: createdOn ?? self.createdOn,
            lastStatusUpdateDate: lastStatusUpdateDate ?? self.lastStatusUpdateDate
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - CitizenProfile
struct CitizenProfile: Codable {
    let emiratesID: String?

    enum CodingKeys: String, CodingKey {
        case emiratesID = "emiratesId"
    }
}

// MARK: CitizenProfile convenience initializers and mutators

extension CitizenProfile {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(CitizenProfile.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        emiratesID: String?? = nil
        ) -> CitizenProfile {
        return CitizenProfile(
            emiratesID: emiratesID ?? self.emiratesID
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Message
struct Message: Codable {
    let ar, en: String?
}

// MARK: Message convenience initializers and mutators

extension Message {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(Message.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        ar: String?? = nil,
        en: String?? = nil
        ) -> Message {
        return Message(
            ar: ar ?? self.ar,
            en: en ?? self.en
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - PartnerAutho
struct PartnerAutho: Codable {
}

// MARK: PartnerAutho convenience initializers and mutators

extension PartnerAutho {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PartnerAutho.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        ) -> PartnerAutho {
        return PartnerAutho(
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - PartnerContactInf
struct PartnerContactInf: Codable {
    let emailID, phoneDomestic, phoneInternational: String?

    enum CodingKeys: String, CodingKey {
        case emailID = "emailId"
        case phoneDomestic, phoneInternational
    }
}

// MARK: PartnerContactInf convenience initializers and mutators

extension PartnerContactInf {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PartnerContactInf.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        emailID: String?? = nil,
        phoneDomestic: String?? = nil,
        phoneInternational: String?? = nil
        ) -> PartnerContactInf {
        return PartnerContactInf(
            emailID: emailID ?? self.emailID,
            phoneDomestic: phoneDomestic ?? self.phoneDomestic,
            phoneInternational: phoneInternational ?? self.phoneInternational
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Helper functions for creating encoders and decoders

//func newJSONDecoder() -> JSONDecoder {
//    let decoder = JSONDecoder()
//    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
//        decoder.dateDecodingStrategy = .iso8601
//    }
//    return decoder
//}
//
//func newJSONEncoder() -> JSONEncoder {
//    let encoder = JSONEncoder()
//    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
//        encoder.dateEncodingStrategy = .iso8601
//    }
//    return encoder
//}

// MARK: - Encode/decode helpers

//class JSONNull: Codable, Hashable {
//
//    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
//        return true
//    }
//
//    public var hashValue: Int {
//        return 0
//    }
//
//    public init() {}
//
//    public required init(from decoder: Decoder) throws {
//        let container = try decoder.singleValueContainer()
//        if !container.decodeNil() {
//            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
//        }
//    }
//
//    public func encode(to encoder: Encoder) throws {
//        var container = encoder.singleValueContainer()
//        try container.encodeNil()
//    }
//}
