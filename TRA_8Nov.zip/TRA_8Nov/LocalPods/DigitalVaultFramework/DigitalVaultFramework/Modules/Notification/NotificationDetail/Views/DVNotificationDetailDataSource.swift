//
//  DVNotificationDetailDataSource.swift
//  Alamofire
//
//  Created by Neema Naidu on 13/08/19.
//  Class for handling DVNotificationDetailViewController table view delegate and data source

import UIKit

class DVNotificationDetailDataSource: NSObject {
    var tableView: UITableView?
    var notificationDetailViewModel =  DVNotificationDetailViewModel()
    override init() {
        super.init()
    }
}
// MARK: - TableView Methods
extension DVNotificationDetailDataSource: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notificationDetailViewModel.numberOfRows()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return notificationDetailViewModel.noOfSections()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVNotificationListTableViewCell.identifier,
                                                        for: indexPath) as? DVNotificationListTableViewCell {
                cell.selectionStyle = .none
                if let notDetail = notificationDetailViewModel.notificationDetail {
                    cell.configureNotificationDetailValues(notificationDetail: notDetail)
                }
                return cell
            }
        } else {
            if let cell = tableView.dequeueReusableCell(withIdentifier: DVNotificationDetailTextTableViewCell.identifier,
                                                        for: indexPath) as? DVNotificationDetailTextTableViewCell {
                if let notDetail = notificationDetailViewModel.notificationDetail {
                    cell.configureNotificationDetailValues(notificationDetail: notDetail, indexPath: indexPath)
                }
                cell.selectionStyle = .none
                return cell
            }
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return   UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return  0.01
    }
}
