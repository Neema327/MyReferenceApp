//
//  DVNotificationDetailViewModel.swift
//  Alamofire
//
//  Created by Neema Naidu on 13/08/19.
//  View Model Class for Notification detail module

import UIKit
import PromiseKit

class DVNotificationDetailViewModel: NSObject {
    var notificationDetail: DVNotificationDetail?
    let dataConverterHelper = DataConverterHelper() as DataConverter
    var  alertMessageId: String?
}
extension DVNotificationDetailViewModel {
    func fetchNotificationDetailData(completionHandler: @escaping SuccessClosure,
                                   failureHandler: @escaping FailureClosure) {
        self.getNotificationDetail(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func updateNotificationState(completionHandler: @escaping SuccessClosure,
                            failureHandler: @escaping FailureClosure) {
        self.updateNotState(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }

    func getNotificationDetail(completionHandler: @escaping SuccessClosure,
                             failureHandler: @escaping FailureClosure) {
            self.invokeServiceForNotificationDetail()
                .done({ (officialDocsList) in
                    guard let newOfficialDocs = officialDocsList as? DVNotificationDetail else {
                        failureHandler(false, dvDataError)
                        return
                    }
                    self.notificationDetail = newOfficialDocs
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }

    func invokeServiceForNotificationDetail() -> Promise<Any> {
        return Promise {  seal in

            guard let alertMsgId = alertMessageId else {
                return
            }
            let serviceURL: String =  baseURL + apiVersion + EndPoint.updateNotificationState.rawValue + "\(alertMsgId)"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.json.rawValue
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as IssuerList?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                DVCommon.decodeResponse(type: DVNotificationDetail.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (notificationDetails) in
                        seal.fulfill(notificationDetails)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    private func updateNotState(completionHandler: @escaping SuccessClosure,
                                         failureHandler: @escaping FailureClosure) {
            self.invokeServiceForUpdateNotificationState()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }
    private func invokeServiceForUpdateNotificationState() -> Promise<Any> {
        return Promise {  seal in
            guard let alertMsgId = alertMessageId else {
                return
            }

            let serviceURL: String =  baseURL + apiVersion + EndPoint.updateNotificationState.rawValue + alertMsgId + "?state=READ"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                ( jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
}
extension DVNotificationDetailViewModel {
    /// method for gettinhg number of rows
    ///
    /// - Returns: Int number of rows
    func numberOfRows() -> Int {
        return 4
    }
    /// method for gettinhg number of sections
    ///
    /// - Returns: Int number of sections
    func noOfSections() -> Int {
        return 1
    }
}
