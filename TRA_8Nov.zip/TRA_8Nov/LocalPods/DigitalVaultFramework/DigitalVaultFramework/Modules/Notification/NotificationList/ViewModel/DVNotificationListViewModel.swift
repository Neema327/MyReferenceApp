//
//  DVNotificationListViewModel.swift
//  Alamofire
//
//  Created by Neema Naidu on 12/08/19.
//  View Model Class for Notification list module

import UIKit
import Foundation
import PromiseKit

class DVNotificationListViewModel: NSObject {
    var notificationList: NotificaionList?
    let dataConverterHelper = DataConverterHelper() as DataConverter
    var currentPageNo = 0
    var maxPageNo = 1

}
extension DVNotificationListViewModel {
    /// method to trigger service call for fectching notification list
    ///
    /// - Parameters:
    ///   - completionHandler: success closure handler
    ///   - failureHandler: failure closure handler
    func fetchNotificationListData(completionHandler: @escaping SuccessClosure,
                              failureHandler: @escaping FailureClosure) {
        self.getNotificationList(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })

    }
    func getNotificationList(completionHandler: @escaping SuccessClosure,
                        failureHandler: @escaping FailureClosure) {
            self.invokeServiceForNotificationList()
                .done({ (notificationsList) in
                    self.maxPageNo = self.maxPageNo + 1
                    guard let newNotificationsList = notificationsList as? NotificaionList else {
                        failureHandler(false, dvDataError)
                        return
                    }
                    if self.currentPageNo != 0 {
                        if var currentNotificationDocsArray = self.notificationList {
                            for doc in newNotificationsList {
                                currentNotificationDocsArray.append(doc)
                            }
                            self.notificationList = currentNotificationDocsArray
                        }
                    } else {
                        self.notificationList = newNotificationsList
                    }

                    if newNotificationsList.count == 0 {
                         self.maxPageNo = self.currentPageNo
                    }
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error)
            }
    }
    func invokeServiceForNotificationList() -> Promise<Any> {
        return Promise {  seal in

            let serviceURL: String =  baseURL + apiVersion + EndPoint.notificationList.rawValue + "\(currentPageNo)"

            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.json.rawValue
            headerParams[authorization] =  DVCommon.bearerToken
            dvService.fetchData(nil as NotificaionList?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                //Decode server response
                DVCommon.decodeResponse(type: NotificaionList.self, respData: jsonResponse, errorData: respError ,decodeOpt: DecodeOption.model)
                    .done({ (notificationList) in
                        seal.fulfill(notificationList)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    /// method to trigger service call for notification unread count
    ///
    /// - Returns: Any object
    func getUnreadNotificationCount()->Promise<Any> {
        return Promise {  seal in
        let serviceQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        serviceQueue.async {
            self.invokeServiceForUnreadCount()
                .done({ (unReadCount) in
                    if let unReadNotifcations = unReadCount as? DVNotificationUnReadCount {
                        seal.fulfill(unReadNotifcations.count as Any)
                    } else {
                        let error = NSError(domain: dvErrorDomain, code: 0, userInfo: [dvServerErrorKey: "dvServerErrorMessage"])
                        seal.reject(error)
                    }
                })
                .catch { error in
                    seal.reject(error)
            }
          }
       }
    }
    private func invokeServiceForUnreadCount() -> Promise<Any> {
        return Promise {  seal in
            let  serviceURL: String =  baseURL + apiVersion + EndPoint.notificationUnreadCount.rawValue

            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.json.rawValue
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVOfficialDoc?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                
                DVCommon.decodeResponse(type: DVNotificationUnReadCount.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (unReadNotifcations) in
                        seal.fulfill(unReadNotifcations)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
}
extension DVNotificationListViewModel {
    /// method for resetting pagination count
    func resetPaginationDetails() {
        maxPageNo = 1
        currentPageNo = 0
        notificationList = nil
    }
    /// method to get number of rows
    ///
    /// - Returns: Int number of rows
    func numberOfRows() -> Int {
        return notificationList?.count ?? 0
    }
    /// method to get number of sections
    ///
    /// - Returns: Int number of sections
    func noOfSections() -> Int {
        return 1
    }
}
