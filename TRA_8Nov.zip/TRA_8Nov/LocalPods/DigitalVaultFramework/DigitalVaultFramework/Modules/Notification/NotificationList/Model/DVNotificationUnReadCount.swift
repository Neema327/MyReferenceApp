//
//  DVNotificationUnReadCount.swift
//  DigitalVaultFramework
//
//  Created by MSP on 03/09/19.
//

import Foundation

// MARK: - DVNotificationUnReadCount
struct DVNotificationUnReadCount: Codable {
    let count: Int?
}

// MARK: DVNotificationUnReadCount convenience initializers and mutators

extension DVNotificationUnReadCount {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVNotificationUnReadCount.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        count: Int?? = nil
        ) -> DVNotificationUnReadCount {
        return DVNotificationUnReadCount(
            count: count ?? self.count
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
