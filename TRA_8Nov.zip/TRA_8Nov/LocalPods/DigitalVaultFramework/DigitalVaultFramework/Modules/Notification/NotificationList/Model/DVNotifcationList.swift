// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try Welcome(json)

//  Model Class for Notification list module

import Foundation

// MARK: - WelcomeElement
struct NotificaionListElement: Codable {
    let id: Int?
    let state, alertMessageType, type, welcomeProtocol: String?
    let partnerAuthKey: PartnerAuthKey?
    let partnerContactInfo: PartnerContactInfo?
    let partnerID, partnerName: String?
    let title: Title?
    let expiryDate: String?
    let expiryFlag: Bool?
    let createdOn: String?
    let lastStatusUpdateDate: String?
    enum CodingKeys: String, CodingKey {
        case id, state, alertMessageType, type
        case welcomeProtocol = "protocol"
        case partnerContactInfo
        case partnerAuthKey = "partnerAuth"
        case partnerID = "partnerId"
        case partnerName, title, expiryDate, expiryFlag, createdOn, lastStatusUpdateDate
    }
}

// MARK: WelcomeElement convenience initializers and mutators

extension NotificaionListElement {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(NotificaionListElement.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: Int?? = nil,
        state: String?? = nil,
        alertMessageType: String?? = nil,
        type: String?? = nil,
        welcomeProtocol: String?? = nil,
        partnerAuthKey: PartnerAuthKey?? = nil,
        partnerContactInfo: PartnerContactInfo?? = nil,
        partnerID: String?? = nil,
        partnerName: String?? = nil,
        title: Title?? = nil,
        expiryDate: String?? = nil,
        expiryFlag: Bool?? = nil,
        createdOn: String?? = nil,
        lastStatusUpdateDate: String?? = nil
        ) -> NotificaionListElement {
        return NotificaionListElement(
            id: id ?? self.id,
            state: state ?? self.state,
            alertMessageType: alertMessageType ?? self.alertMessageType,
            type: type ?? self.type,
            welcomeProtocol: welcomeProtocol ?? self.welcomeProtocol,
            partnerAuthKey: partnerAuthKey ?? self.partnerAuthKey,
            partnerContactInfo: partnerContactInfo ?? self.partnerContactInfo,
            partnerID: partnerID ?? self.partnerID,
            partnerName: partnerName ?? self.partnerName,
            title: title ?? self.title,
            expiryDate: expiryDate ?? self.expiryDate,
            expiryFlag: expiryFlag ?? self.expiryFlag,
            createdOn: createdOn ?? self.createdOn,
            lastStatusUpdateDate: lastStatusUpdateDate ?? self.lastStatusUpdateDate
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - PartnerAuthKey
struct PartnerAuthKey: Codable {
}

// MARK: PartnerAuthKey convenience initializers and mutators

extension PartnerAuthKey {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PartnerAuthKey.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        ) -> PartnerAuthKey {
        return PartnerAuthKey(
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - PartnerContactInfo
struct PartnerContactInfo: Codable {
    let emailID, phoneDomestic, phoneInternational: String?

    enum CodingKeys: String, CodingKey {
        case emailID = "emailId"
        case phoneDomestic, phoneInternational
    }
}

// MARK: PartnerContactInfo convenience initializers and mutators

extension PartnerContactInfo {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(PartnerContactInfo.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        emailID: String?? = nil,
        phoneDomestic: String?? = nil,
        phoneInternational: String?? = nil
        ) -> PartnerContactInfo {
        return PartnerContactInfo(
            emailID: emailID ?? self.emailID,
            phoneDomestic: phoneDomestic ?? self.phoneDomestic,
            phoneInternational: phoneInternational ?? self.phoneInternational
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Title
struct Title: Codable {
    let en, ar: String?
}

// MARK: Title convenience initializers and mutators

extension Title {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(Title.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        en: String?? = nil,
        ar: String?? = nil
        ) -> Title {
        return Title(
            en: en ?? self.en,
            ar: ar ?? self.ar
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

typealias NotificaionList = [NotificaionListElement]

extension Array where Element == NotificaionList.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(NotificaionList.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
