//
//  DVNotificationListDataSource.swift
//  Alamofire
//
//  Created by Neema Naidu on 12/08/19.
//  Class for handling DVNotificationsListViewController table view delegate and data source

import UIKit
protocol DVNotificationListDataSourceDelegate: class {
    func displayNotificationListDetailView(indexPath: IndexPath)
    func displayPresentmentDetailView(index: Int)
    func checkWhetherFetchFromServerIsRequired(indexPath: IndexPath)
}

class DVNotificationListDataSource: NSObject {

    var tableView: UITableView?
    weak var delegate: DVNotificationListDataSourceDelegate?
    var notificationListViewModel =  DVNotificationListViewModel()
    var lastContentOffset: CGFloat = 0
    override init() {
        super.init()
    }
}
// MARK: - UITableViewDataSource Methods
extension DVNotificationListDataSource: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notificationListViewModel.numberOfRows()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return notificationListViewModel.noOfSections()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "DVNotificationListTableViewCell",
                                                    for: indexPath) as? DVNotificationListTableViewCell {
            cell.selectionStyle = .none
            cell.delegate = self
            cell.isStatusViewHidden(isHidden: false)
            cell.allowBtn.tag = indexPath.row
            if let notElement = notificationListViewModel.notificationList?[indexPath.row] {
                cell.configureNotificationList(notificationElement: notElement)
                cell.showHideAllowButton(notificationElement: notElement)
            }
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
// MARK: - UITableViewDelegate Methods
extension DVNotificationListDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.delegate?.checkWhetherFetchFromServerIsRequired(indexPath: indexPath)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            self.delegate?.displayNotificationListDetailView(indexPath: indexPath)
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let tableViewCell = cell as? DVNotificationListTableViewCell {
            tableViewCell.iconImgVw?.kf.cancelDownloadTask()
        }
    }
    // this delegate is called when the scrollView (i.e your UITableView) will start scrolling
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.lastContentOffset = scrollView.contentOffset.y
    }
    
    // while scrolling this delegate is being called so you may now check which direction your scrollView is being scrolled to
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (self.lastContentOffset < scrollView.contentOffset.y) {
            DVConstants.notificationListMode = .pagination
        } else if (self.lastContentOffset > scrollView.contentOffset.y) {
            DVConstants.notificationListMode = .none
        } else {
            // didn't move
            DVConstants.notificationListMode = .none
        }
    }
}
extension DVNotificationListDataSource: DVNotificationListTableViewCellDelegate {
    /// perform allow button action
    ///
    /// - Parameter index: Int selected
    func performAllowButtonAction(index: Int) {
        self.delegate?.displayPresentmentDetailView(index: index)
    }
}
