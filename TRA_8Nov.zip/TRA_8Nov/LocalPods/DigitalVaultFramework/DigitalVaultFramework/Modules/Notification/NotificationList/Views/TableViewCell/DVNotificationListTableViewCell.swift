//
//  NotificationListTableViewCell.swift
//  Alamofire
//
//  Created by Neema Naidu on 08/08/19.
//

import UIKit
import Kingfisher

protocol DVNotificationListTableViewCellDelegate: class {
    func performAllowButtonAction(index: Int)
}
class DVNotificationListTableViewCell: UITableViewCell {
    @IBOutlet var allowBtn: UIButton!
    @IBOutlet var iconImgVw: UIImageView!
    @IBOutlet var statusImgView: UIImageView!
    @IBOutlet var arrowImgView: UIImageView!
    @IBOutlet var partnerName: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var iconView: UIView!
    @IBOutlet var seperatorView: UIView!

    @IBOutlet weak var stackViewLeadingConstriant: NSLayoutConstraint!
    @IBOutlet weak var imageViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var stackViewBottomConstriant: NSLayoutConstraint!
    @IBOutlet weak var imageViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var imageViewWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var notificationStackView: UIStackView!

    weak var delegate: DVNotificationListTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        allowBtn.setTitle(Notifications.allow, for: .normal)
        allowBtn.setViewsLayer(layer: allowBtn.layer, shouldLayerBorderClearColor: true)
        allowBtn.layer.borderWidth = 0.5
        allowBtn.layer.cornerRadius = 12.0
        allowBtn.layer.borderColor = UIColor.clear.cgColor
        statusImgView.layer.cornerRadius = statusImgView.frame.size.width / 2
        statusImgView.clipsToBounds = true
        if DVConstants.uaepassArabicLocalization {
            allowBtn.titleLabel?.font = UIFont(name: ArabicFont.regular.rawValue, size: 17.0)
            partnerName.font = UIFont(name: ArabicFont.regular.rawValue, size: 14.0)
            dateLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 14.0)
            arrowImgView.image = DVCommon.getImage(named: "Disclosure-Indicator-flipped-ico.png")
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    
    static var identifier: String {
        return String(describing: self)
    }
    /// Method for handling hiding and showing allow button
    ///
    /// - Parameter notificationElement: NotificaionListElement object
    func showHideAllowButton(notificationElement: NotificaionListElement) {
        let alertMessageType = notificationElement.alertMessageType ?? ""
        let state = notificationElement.state ?? ""
        if alertMessageType == "readOnly" {
            if DVConstants.uaepassArabicLocalization {
                (state == DVConstants.stateRead) ? (titleLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)) : (titleLabel.font = UIFont(name: ArabicFont.bold.rawValue, size: 18.0))
            } else {
                (state == DVConstants.stateRead) ? (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)) : (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .semibold))
            }
            statusImgView.backgroundColor = UIColor.lightGray
            allowBtn.isHidden = true
            allowBtn.isEnabled = false
        } else if alertMessageType == "presentationRequest" {
            if notificationElement.expiryFlag == true {
                statusImgView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xEB6D72)
                allowBtn.isHidden = false
                allowBtn.isEnabled = true
                if state == DVConstants.stateActionTaken {
                    allowBtn.backgroundColor = UIColor.white
                    allowBtn.layer.borderColor = UIColor.colorFromHex(rgbValue: 0x78849E).cgColor
                    allowBtn.setTitle(Notifications.shared, for: .normal)
                    allowBtn.setTitleColor(UIColor.colorFromHex(rgbValue: 0x78849E), for: .normal)
                    statusImgView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x00833E)
                    titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)
                } else {
                    allowBtn.backgroundColor = UIColor.white
                    allowBtn.layer.borderColor = UIColor.colorFromHex(rgbValue: 0xEB6D72).cgColor
                    allowBtn.setTitle(Notifications.expired, for: .normal)
                    allowBtn.setTitleColor(UIColor.colorFromHex(rgbValue: 0xEB6D72), for: .normal)
                    if DVConstants.uaepassArabicLocalization {
                        (state == DVConstants.stateRead) ? (titleLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)) : (titleLabel.font = UIFont(name: ArabicFont.bold.rawValue, size: 18.0))
                    } else {
                    (state == DVConstants.stateRead) ? (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)) : (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .semibold))
                    }
                }
            } else {
                allowBtn.isHidden = false
                allowBtn.isEnabled = true
                if state == DVConstants.stateUnRead || state == DVConstants.stateRead {
                    allowBtn.setTitle(Notifications.allow, for: .normal)
                    allowBtn.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF5A623)
                    statusImgView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF5A623)
                    allowBtn.layer.borderColor = UIColor.clear.cgColor
                    allowBtn.setTitleColor(UIColor.white, for: .normal)
                    if DVConstants.uaepassArabicLocalization {
                        (state == DVConstants.stateRead) ? (titleLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)) : (titleLabel.font = UIFont(name: ArabicFont.bold.rawValue, size: 18.0))
                    } else {
                (state == DVConstants.stateRead) ? (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)) : (titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .semibold))
                    }
                } else if state == DVConstants.stateActionTaken {
                    allowBtn.backgroundColor = UIColor.white
                    allowBtn.layer.borderColor = UIColor.colorFromHex(rgbValue: 0x78849E).cgColor
                    allowBtn.setTitle(Notifications.shared, for: .normal)
                    allowBtn.setTitleColor(UIColor.colorFromHex(rgbValue: 0x78849E), for: .normal)
                    statusImgView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x00833E)
                    titleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)
                }
            }
        }
    }
    /// method to hide show status view
    ///
    /// - Parameter isHidden: Bool to hide show
    func isStatusViewHidden(isHidden: Bool) {
        if isHidden {
            stackViewLeadingConstriant.constant = 30.0
        } else {
            stackViewLeadingConstriant.constant = 30.0 + statusImgView.frame.width + 15.0
        }
        statusImgView.isHidden = isHidden
        arrowImgView.isHidden = isHidden
    }
    /// method to hide show view detail
    func showHideForViewDetail() {
        stackViewLeadingConstriant.constant = 30.0
        allowBtn.isHidden = true
        arrowImgView.isHidden = true
    }
    /// method to configure notification detail table values
    ///
    /// - Parameter notificationDetail: DVNotificationDetail object
    func configureNotificationDetailValues(notificationDetail: DVNotificationDetail) {
        showHideForViewDetail()
        seperatorView.isHidden = true
        imageViewBottomConstraint.constant = 0.0
        stackViewBottomConstriant.constant = 5.0
        self.iconView.isHidden = true
        notificationStackView.distribution = .fill
        notificationStackView.spacing = 9.0
        titleLabel.isHidden = false
        partnerName.text = notificationDetail.partnerName ?? ""
        if DVConstants.uaepassArabicLocalization {
            titleLabel.text =  notificationDetail.title?.ar ?? ""
        } else {
            titleLabel.text =  notificationDetail.title?.en ?? ""
        }
        titleLabel.numberOfLines = 0
        partnerName.numberOfLines = 0
        if let createdDateString = Date.getFormattedDate(date: notificationDetail.lastStatusUpdateDate ?? "") {
           dateLabel.text = createdDateString
        }
    }
    /// method to configure notification list table values
    ///
    /// - Parameter notificationElement: NotificaionListElement object
    func configureNotificationList(notificationElement: NotificaionListElement) {
        seperatorView.isHidden = false
        self.iconView.isHidden = false
        notificationStackView.distribution = .fillProportionally
        notificationStackView.spacing = 5.0
        titleLabel.isHidden = false
        partnerName.text = notificationElement.partnerName ?? ""
        if DVConstants.uaepassArabicLocalization {
            titleLabel.text =  notificationElement.title?.ar ?? ""
        } else {
            titleLabel.text =  notificationElement.title?.en ?? ""
        }
        titleLabel.numberOfLines = 1
        dateLabel.text = Date.getFormattedDate(date: notificationElement.lastStatusUpdateDate ?? "")
        let partnerId = notificationElement.partnerID
        if let issuerId = partnerId {
            let  iconURL  =  baseURL + apiVersion + EndPoint.issuersListLogo.rawValue + "\(issuerId)" + "/icon"
            addIconImage(partnerIdUrlString: iconURL)
        } else {
            self.iconImgVw.contentMode = .scaleAspectFill
            self.iconImgVw.image = DVConstants.placeholderLargeImage
            self.imageViewWidthConstraint.constant = 105.0
        }
    }
    /// method to add icon image
    ///
    /// - Parameter partnerIdUrlString: String url
    func addIconImage(partnerIdUrlString: String) {
        self.iconImgVw.contentMode = .scaleToFill
        var newWidth = CGFloat()
        self.iconImgVw.kf.indicatorType = .activity
            let  iconURL  =  partnerIdUrlString
            if let url = URL(string: iconURL) {
                self.iconImgVw.kf.setImage(
                with: url ,
                placeholder: DVConstants.placeholderLargeImage,
                options: [.waitForCache, .loadDiskFileSynchronously, .transition(.none)],
                progressBlock: nil) { result in
                    switch result {
                    case .success(let value):
                        self.iconImgVw.contentMode = .scaleAspectFit
                        let ratio = value.image.size.width / value.image.size.height
                        newWidth = self.iconImgVw.frame.height * ratio
                        self.imageViewWidthConstraint.constant = newWidth
                    case .failure(let error):
                        if !error.isTaskCancelled && !error.isNotCurrentTask {
                            self.iconImgVw.contentMode = .scaleAspectFill
                            self.iconImgVw.image = DVConstants.placeholderLargeImage
                            self.imageViewWidthConstraint.constant = 105.0
                        }
                    }
                }
            }
    }
    /// allow button action
    ///
    /// - Parameter sender: UIButton sender
    @IBAction func allowButtonAction(sender: UIButton) {
        self.delegate?.performAllowButtonAction(index: sender.tag)
    }
}
