//
//  DVNotificationsListViewController.swift
//  DigitalVaultFramework
//
//  Created by Gembali Saiaswanth on 8/4/19.
//  View class for displaying list if notification view

import UIKit
import SwiftEventBus
import Kingfisher

class DVNotificationsListViewController: DVBaseViewController {
    @IBOutlet var notificationTableView: UITableView!
    private let notificationListCellIdentifier = DVNotificationListTableViewCell.identifier
    var notificationListViewModel = DVNotificationListViewModel()
    var isNavigatedToDetailScreen = false
    var isFromPushNotificationFlow = false // To differentiate whether user came to this screen after getting push notification
    var isFirstPageLoading = false
    fileprivate var isNotificationListScreen = false // To identify whether are we in notification list screen
    let lock = NSLock()
    
    @IBOutlet var subTitleLabel: UILabel!
    @IBOutlet weak var notificationListHeaderView: UIImageView!

    lazy private var notificationListDataSource: DVNotificationListDataSource = {
        let officialDataSrc = DVNotificationListDataSource()
        return officialDataSrc
    }()
    lazy private var activityIndicatorView: DVProgressIndicatorView = {
        let progressIndicatorView = DVProgressIndicatorView()
        return progressIndicatorView
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        KingfisherManager.clearCache()
        DVConstants.notificationState = .none
        DVConstants.notificationListMode = .none
        configureNotificationList()
        configureLocalizationFont()
        launchNotificationDetails()
        refreshNotificationList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        isNotificationListScreen = true
        isNavigatedToDetailScreen = false
        self.navigationItem.hidesBackButton = DVConstants.enableBackButton
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
        self.navigationController?.navigationBar.isHidden = DVConstants.enableBackButton
        isFirstPageLoading = true
        notificationListViewModel.resetPaginationDetails()
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        loadNotificationListDocsData()
    }

    override func viewWillDisappear(_ animated: Bool) {
        isNotificationListScreen = false
        self.navigationController?.navigationBar.isHidden = false
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}

// MARK: - Private Methods
extension DVNotificationsListViewController {
    /// method for adding localization fonts and styles
    func configureLocalizationFont() {
        self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
        if DVConstants.uaepassArabicLocalization {
            subTitleLabel.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 35.0)
        }
    }
    /// Configuring notification list table view values
    func configureNotificationList() {
        let topHeaderBGImg = DVCommon.getImage(named: "header_bg.png")
        notificationListHeaderView.image = topHeaderBGImg
        activityIndicatorView.addActivityIndicatorToTheView(view: self.view)
        subTitleLabel.text = Notifications.notificationsTitle
        UITableView.registerCellWithIdentifier(cellIdentifier: notificationListCellIdentifier, tblVw: self.notificationTableView)
        self.notificationListDataSource.notificationListViewModel = self.notificationListViewModel
        self.notificationListDataSource.tableView = self.notificationTableView
        self.notificationListDataSource.delegate = self
        self.notificationTableView.delegate = self.notificationListDataSource
        self.notificationTableView.dataSource = self.notificationListDataSource
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        notificationTableView.setUpRoundedCornerView(view: notificationTableView)
        self.notificationTableView.tableFooterView = UIView()
        self.notificationListDataSource.tableView?.separatorColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
        applyNavBarStyle()
    }
    /// Apply navigation bar font and style
    private func applyNavBarStyle () {
        let topHeaderBGImg = DVCommon.getImage(named: "top-header-bg.png")//UIImage(contentsOfFile:DVCommon.digitalVaultResourceBundlePath + "top-header-bg.png")
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(topHeaderBGImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        self.navigationController?.navigationBar.isTranslucent = false
    }
    /// Scroll to top in table view
    private func scrollToTopIfNeeded() {
        if isFirstPageLoading {
            isFirstPageLoading = false
            if notificationListViewModel.numberOfRows() > 0 {
                let indexPath = IndexPath(row: 0, section: 0)
                self.view.layoutIfNeeded()
                self.notificationTableView?.scrollToRow(at: indexPath, at: .top, animated: true)
            }
        }
    }
    /// Method to trigger service call for noptification unread count
    private func loadNotificationUnreadCount() {
        DVEventHandler.sharedInstance.getNotificationCount()
    }
    private func launchNotificationDetails() {
        DVEventHandler.sharedInstance.deRegisterEventBusEvent(for: self)
        SwiftEventBus.onMainThread(self, name: "DV_DVPushNotification") { [weak self] result in
            if let result = result,
                let dvNotificaitonDictionary = result.userInfo,
                let notificationID = dvNotificaitonDictionary["notificationID"] as? String {
                if self?.isNavigatedToDetailScreen ?? false, let controller = self {
                    self?.navigationController?.popToViewController(controller, animated: false)
                }
                let presentmentDetailsViewController = DVPresentmentDetailViewController(nibName: "DVPresentmentDetailViewController", bundle: DVCommon.getDVBundle())
                presentmentDetailsViewController.alertMessageId = String(notificationID)
                DVCommon.isPresentmentAppToAppFlow = false
                presentmentDetailsViewController.isNotificationFlow = true
                self?.isNavigatedToDetailScreen = true
                self?.navigationController?.pushViewController(presentmentDetailsViewController, animated: true)
            }
        }
        
    }
    
    private func refreshNotificationList() {
        SwiftEventBus.onMainThread(self, name: "DV_UpdateNotificationList") { [weak self] result in
            if self?.isNotificationListScreen ?? false {
                self?.isFromPushNotificationFlow = true
                self?.loadNotificationListDocsData()
            }
        }
    }
}
// MARK: - DVNotificationListDataSourceDelegate Methods
extension DVNotificationsListViewController: DVNotificationListDataSourceDelegate {
    /// method to display notification detail
    ///
    /// - Parameter indexPath: selected IndexPath
    func displayNotificationListDetailView(indexPath: IndexPath) {

        if let notList = notificationListViewModel.notificationList {
            let notification = notList[indexPath.row]
            guard  let alertMessageId = notification.id  else {
                return
            }
            if notification.alertMessageType == "presentationRequest" {
                let presentmentDetailsViewController = DVPresentmentDetailViewController(nibName: "DVPresentmentDetailViewController", bundle: DVCommon.getDVBundle())
                presentmentDetailsViewController.alertMessageId = String(alertMessageId)
                presentmentDetailsViewController.alertStatus = notification.state ?? ""
                DVCommon.isPresentmentAppToAppFlow = false
                presentmentDetailsViewController.isNotificationFlow = false
                isNavigatedToDetailScreen = true
                self.navigationController?.pushViewController(presentmentDetailsViewController, animated: true)

            } else {
                let signInViewController = DVNotificationDetailViewController(nibName: "DVNotificationDetailViewController", bundle: DVCommon.getDVBundle())
                signInViewController.alertMessageId = String(alertMessageId)
                signInViewController.state = notification.state ?? ""
                signInViewController.dateStr = notification.lastStatusUpdateDate ?? ""
                isNavigatedToDetailScreen = true
                self.navigationController?.pushViewController(signInViewController, animated: true)
            }
        }
    }
    /// method to display presentment detail
    ///
    /// - Parameter index: selected index Int
    func displayPresentmentDetailView(index: Int) {
        let presentmentDetailsViewController = DVPresentmentDetailViewController(nibName: "DVPresentmentDetailViewController", bundle: DVCommon.getDVBundle())
        if let notList = notificationListViewModel.notificationList {
            let notification = notList[index]
            guard  let alertMessageId = notification.id  else {
                return
            }
            presentmentDetailsViewController.alertMessageId = String(alertMessageId)
            presentmentDetailsViewController.alertStatus = notification.state ?? ""
            DVCommon.isPresentmentAppToAppFlow = false
            presentmentDetailsViewController.isNotificationFlow = false
            isNavigatedToDetailScreen = true
            self.navigationController?.pushViewController(presentmentDetailsViewController, animated: true)
        }
    }
    /// method to check Whether Fetch From Server Is Required
    ///
    /// - Parameter indexPath: IndexPath selected
    func checkWhetherFetchFromServerIsRequired(indexPath: IndexPath) {
        guard let notificationList = notificationListViewModel.notificationList else {
            return
        }
        if DVConstants.notificationListMode == .pagination {
            DVConstants.notificationListMode = .none
            if indexPath.row == notificationList.count - 1 {
                if notificationListViewModel.currentPageNo < notificationListViewModel.maxPageNo {
                    notificationListViewModel.currentPageNo = notificationListViewModel.currentPageNo + 1
                    loadNotificationListDocsData()
                }
            }
        }
    }
}
// MARK: - Service Methods
extension DVNotificationsListViewController {
    /// method to trigger service call for notification list data
    func loadNotificationListDocsData() {
        lock.lock()
        if isFromPushNotificationFlow {
            isFirstPageLoading = true
            notificationListViewModel.resetPaginationDetails()
            isFromPushNotificationFlow = false
        }
        displayActivityIndicatorView()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.notificationListViewModel.fetchNotificationListData(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.notificationTableView.reloadData()
                    self?.scrollToTopIfNeeded()
                    self?.loadNotificationUnreadCount()
                    self?.lock.unlock()
                }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.notificationTableView.reloadData()
                    self?.loadNotificationUnreadCount()
                    DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    self?.lock.unlock()
                }
            })
        }
    }
}
// MARK: - Loader Methods
extension DVNotificationsListViewController {
    /// method to hide and show ActivityIndicatorView
    func displayActivityIndicatorView() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
    }
    func hideActivityIndicatorView() {
        DVCommon.hideActivityIndicatorView()
    }
}
