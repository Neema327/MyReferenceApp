//
//  DVIssuersListViewController.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 12/07/19.
//  View class for Adding/Requesting documents view

import Foundation
import UIKit
import Kingfisher

class DVIssuersListViewController: DVBaseViewController {
    @IBOutlet weak var sortTypeLabel: UILabel!
    @IBOutlet weak var noDocsTileLblHeight: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sortView: UIView!
    @IBOutlet weak var sortImageView: UIImageView!
    @IBOutlet weak var sortButton: UIButton!
    //@IBOutlet weak var searchBar:DVIssuerListearchBar!  //
    @IBOutlet weak var searchBar: DVSearchBar!
    
    @IBOutlet weak var noDocumentView: UIView!
    @IBOutlet weak var noDocumentTitleLbl: UILabel!
    @IBOutlet weak var noDocumentSubTitleLbl: UILabel!
    @IBOutlet weak var sortButtonLabel: UILabel!
    var sortVw = DVSortView()

    let confirmViewModel = DVConfirmViewModel()
    var isFromHome: Bool!
    var sortType: SortOrder = .none
    var retainSort: Bool = true
    let issuersListViewModel = DVIssuersListViewModel()
    private let dvIssuersListTableViewCellIdentifier = DVIssuersListTableViewCell.identifier

    lazy private var activityIndicatorView: DVProgressIndicatorView = {
        let progressIndicatorView = DVProgressIndicatorView()
        return progressIndicatorView
    }()

    lazy private var issuersDataSource: DVIssuersListDataSource = {
        let officialDataSrc = DVIssuersListDataSource()
        return officialDataSrc
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        KingfisherManager.clearCache()
        configureListView()
        configureLocalizationFonts()
        searchBar.throttlingInterval = 0.1
        searchBar.setPlaceholder(textColor: .white)
        //Handle search by applying throttle
        searchBar.onSearch = { searchText in
            if searchText.isEmpty {
                self.issuersListViewModel.searchText = ""
                self.issuersListViewModel.searchActive = false
                DispatchQueue.main.async {
                    self.searchBar.resignFirstResponder()
                    self.sortType = .asc
                    self.retainSort=true
                    self.loadIssuersListDocsDataForSearch(with: "")
                }
            } else {
                self.issuersListViewModel.searchActive = true
                let searchText = self.searchBar.text ?? ""
                
                if searchText.count > 2 {
                    self.issuersListViewModel.searchText = searchText
                    self.sortType = .asc
                    self.retainSort=true
                    self.loadIssuersListDocsDataForSearch(with: searchText)
                }
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
        self.navigationItem.title = IssuersList.requestTitle
         self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18.0, weight: .regular)]
        if(sortType.rawValue == SortOrder.none.rawValue) {
            sortType = .asc
        }
        retainSort=true
        self.issuersListViewModel.issuersCredentials = nil
        loadIssuersListDocsData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}

// MARK: - Sort Methods
extension DVIssuersListViewController {
    @IBAction func displaySortOptions(_ sender: Any) {
        
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        displaySortDetailView(categoryStr: Documents.nameSort)
    }
    func setSortIcon() {
        if(sortType.rawValue == SortOrder.asc.rawValue) {
           sortButton.setImage(DVCommon.getImage(named: "ascending_sort_icon.png"), for: .normal)
        } else if(sortType.rawValue == SortOrder.desc.rawValue) {
            sortButton.setImage(DVCommon.getImage(named: "sort_icon.png"), for: .normal)
        }
    }
    func performSortAction(sortOrder: SortOrders) {
        self.issuersListViewModel.sortActive = true
        self.issuersListViewModel.sortOrder = sortOrder
        loadIssuersListDocsData()
    }
}
// MARK: - Sort Methods
extension DVIssuersListViewController: DVSortViewDelegate {
    func displaySortDetailView(categoryStr: String) {
        if categoryStr == Documents.nameSort {
            self.performSortAction(sortOrder: .name)
        }
    }
    func cancelAction() {
    }
}
// MARK: - Private Methods
extension DVIssuersListViewController {
    /// method for configuring UI elements
    func configureListView() {
        noDocumentTitleLbl.text = Documents.noDocsMsg
        noDocumentSubTitleLbl.text = Documents.addDocsMsg
        let sortImage = UIImage(contentsOfFile: DVCommon.digitalVaultResourceBundlePath + "ascending_sort_icon.png")
        sortButton.setImage(sortImage, for: .normal)
        sortButtonLabel.text = IssuersList.sortTitle
        self.searchBar.placeholder = IssuersList.searchTitle
        UITableView.registerCellWithIdentifier(cellIdentifier: dvIssuersListTableViewCellIdentifier, tblVw: tableView)
        self.tableView.separatorStyle = .none
        self.tableView.contentInset = UIEdgeInsets(top: -2, left: 0, bottom: 0, right: 0)
        self.issuersDataSource.issuersListViewModel = self.issuersListViewModel
        self.issuersDataSource.tableView = self.tableView
        self.issuersDataSource.delegate = self
        self.tableView.delegate = self.issuersDataSource
        self.tableView.dataSource = self.issuersDataSource
        applyNavBarStyle()
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        searchBar.searchBarWithColor(color: .white)
        activityIndicatorView.addActivityIndicatorToTheView(view: self.view)
        noDocumentView.setUpRoundedCornerView(view: noDocumentView)
        tableView.setUpRoundedCornerView(view: tableView)
    }
    /// method for adding localization fonts and styles
    func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            sortButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 12.0)
            self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 18.0) ?? UIFont.systemFont(ofSize: 18.0, weight: .regular)]
        }
    }
    /// Method for applying navigation bar style and fonts
    private func applyNavBarStyle () {
        let topHeaderBGImg = DVCommon.getImage(named: "top-header-bg.png")//UIImage(contentsOfFile:DVCommon.digitalVaultResourceBundlePath + "top-header-bg.png")
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(topHeaderBGImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        self.navigationController?.navigationBar.isTranslucent = false
    }
    /// Method for hiding and showing No docs View
    func displayOrHideNoDocsAvailableView() {
        let tableRefreshType =  self.issuersListViewModel.displayNoDocsAvailableView()
        if tableRefreshType == .noDocsAvailable {
            self.noDocumentView.isHidden = false
        } else {
               self.noDocumentView.isHidden = true
        }
        let noDocsAvlDetails = self.issuersListViewModel.noDocsAvlDetails()
        self.noDocumentTitleLbl.text = noDocsAvlDetails.title
        self.noDocumentSubTitleLbl.text = noDocsAvlDetails.text
       if tableRefreshType == .noDocsAvailable {
            if issuersListViewModel.searchActive {
                noDocumentTitleLbl.isHidden = true
                noDocsTileLblHeight.constant = 0.0
                noDocumentSubTitleLbl.font = UIFont.boldSystemFont(ofSize: 20)
            } else {
                noDocumentTitleLbl.isHidden = false
                noDocsTileLblHeight.constant = 20.0
                noDocumentSubTitleLbl.font = UIFont.systemFont(ofSize: 17)
            }
            self.sortButton.isEnabled = false
            self.sortButton.alpha = 0.5
            self.sortButtonLabel.alpha = 0.5
        } else {
            self.sortButton.isEnabled = true
            self.sortButton.alpha = 1.0
            self.sortButtonLabel.alpha = 1.0
        }
        self.hideShowSortButton()
    }
    /// Method for handling hide show of sort button
    func hideShowSortButton() {
        self.sortButton.isEnabled = self.issuersListViewModel.showHideSortButton()
        self.sortButton.alpha = self.issuersListViewModel.showHideSortButton() ? 1.0 : 0.5
        self.sortButtonLabel.alpha = self.issuersListViewModel.showHideSortButton() ? 1.0 : 0.5
    }
    /// Scroll to top in table view
    private func reloadDataAndScrollToTopIfNeededAnd() {
        var needToScrollToTop = false
        if let numOfSections = self.issuersListViewModel.issuersCredentials?.count {
            if numOfSections > 0 {
                needToScrollToTop = true
            }
        }
        self.issuersListViewModel.resetAllFlagValues()
        self.tableView.reloadData()
        if needToScrollToTop {
            let sectionRect = tableView.rect(forSection: 0)
            tableView.scrollRectToVisible(sectionRect, animated: true)
        }
       
    }
}
// MARK: - Loader Methods
extension DVIssuersListViewController {
    /// Methods for hiding and showing ActivityIndicatorView
    func displayActivityIndicatorView() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
    }
    func hideActivityIndicatorView() {
        DVCommon.hideActivityIndicatorView()
    }
}
// MARK: - DVIssuersListDataSourceDelegate Methods
extension DVIssuersListViewController: DVIssuersListDataSourceDelegate {
    /// Method for showing detail of issuer list tap
    /// - Parameter indexPath: selected indexpath
    func displayIssuersDetailView(indexPath: IndexPath) {
        let issuer = issuersListViewModel.issuersCredentials?[indexPath.section].credentialTypes?[indexPath.row]
        let partnerId = issuersListViewModel.issuersCredentials?[indexPath.section].partnerID ?? ""
        if let issuerDetails = issuer {
            let credentialId = issuerDetails.credentialID ?? ""
            let requestId = issuerDetails.requestID ?? ""
            let requestedOn = issuerDetails.requestedOn ?? ""
            let credentialTypeId = issuerDetails.credentialTypeID ?? 0
            let credentialType = issuerDetails.credentialType ?? ""

            if requestId.isEmpty && credentialId.isEmpty && requestedOn.isEmpty {
                let signInViewController = DVConfirmViewController(nibName: "DVConfirmViewController", bundle: DVCommon.getDVBundle())
                signInViewController.isFromHome = isFromHome
                signInViewController.partnerId = partnerId
                signInViewController.credentialTypeId = credentialTypeId
                signInViewController.subTitleStr = credentialType
                self.navigationController?.pushViewController(signInViewController, animated: true)
            }
        }
    }
}
// MARK: - Service Methods
extension DVIssuersListViewController {
    /// method to trigger service call for Issuer list
    func loadIssuersListDocsData() {
        if(false == retainSort) {
            if(sortType.rawValue != SortOrder.asc.rawValue) {
                sortType = .asc
            } else if(sortType.rawValue == SortOrder.asc.rawValue) {
                sortType = .desc
            }
            setSortIcon()
        }
        if !issuersListViewModel.searchActive {
            displayActivityIndicatorView()
        }
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.issuersListViewModel.fetchIssuersListData(sortType: self.sortType, completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.retainSort=false
                    self?.hideActivityIndicatorView()
                    //self?.tableView.reloadData()
                    self?.reloadDataAndScrollToTopIfNeededAnd()
                    DVEventHandler.sharedInstance.getNotificationCount()
                    self?.displayOrHideNoDocsAvailableView()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        self?.retainSort=false
                        self?.hideActivityIndicatorView()
                        self?.tableView.reloadData()
                        self?.displayOrHideNoDocsAvailableView()
                        DVEventHandler.sharedInstance.getNotificationCount()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                }
            })
        }
    }
    /// method to trigger service call for Issuer list Search
    func loadIssuersListDocsDataForSearch(with searchText: String) {
        if(false == retainSort) {
            if(sortType.rawValue != SortOrder.asc.rawValue) {
                sortType = .asc
            } else if(sortType.rawValue == SortOrder.asc.rawValue) {
                sortType = .desc
            }
            setSortIcon()
        }
        let issuerSearchViewModel = DVIssuersListViewModel()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            issuerSearchViewModel.searchText = searchText
            issuerSearchViewModel.searchActive = true
            issuerSearchViewModel.fetchIssuersListData(sortType: self.sortType, completionHandler: { [weak self] (_, _) in
                self?.issuersListViewModel.issuersCredentials = issuerSearchViewModel.issuersCredentials
                
                DispatchQueue.main.async {
                    let lock = NSLock()
                    lock.lock()
                    self?.retainSort=false
                    self?.hideActivityIndicatorView()
//                    self?.tableView.reloadData()
                    self?.reloadDataAndScrollToTopIfNeededAnd()
                    self?.displayOrHideNoDocsAvailableView()
                    lock.unlock()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        self?.retainSort=false
                        self?.hideActivityIndicatorView()
                        self?.tableView.reloadData()
                        self?.displayOrHideNoDocsAvailableView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
}
// MARK: - UISearchBar Methods
public class DVSearchBar: UISearchBar, UISearchBarDelegate {
    public var throttler: Throttler? = nil
    public var throttlingInterval: Double? = 0 {
        didSet {
            guard let interval = throttlingInterval else {
                self.throttler = nil
                return
            }
            self.throttler = Throttler(seconds: interval)
        }
    }
    public var onCancel: (() -> (Void))? = nil
    
    public var onSearch: ((String) -> (Void))? = nil
    
    public override func awakeFromNib() {
        super.awakeFromNib()
        self.delegate = self
    }
    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.onCancel?()
    }
    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    public func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard let throttler = self.throttler else {
            self.onSearch?(searchText)
            return
        }
        throttler.throttle {
            DispatchQueue.main.async {
                self.onSearch?(self.text ?? "")
            }
        }
    }
    public func searchBarWithColor(color: UIColor) {
        let searchImg = DVCommon.getImage(named: "search-bg.png")//UIImage(named: "search-bg")
        let crossImg = DVCommon.getImage(named: "close.png")//UIImage(named: "close")
        self.setBackgroundImage(searchImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .any, barMetrics: UIBarMetrics.default)
        let textFieldInsideSearchBar = self.value(forKey: "searchField") as? UITextField
        textFieldInsideSearchBar?.backgroundColor = UIColor.clear
        if DVConstants.uaepassArabicLocalization {
           textFieldInsideSearchBar?.font = UIFont(name: ArabicFont.regular.rawValue, size: 18.0)
            self.semanticContentAttribute = .forceRightToLeft
        }
        let glassIconView = textFieldInsideSearchBar?.leftView as? UIImageView
        glassIconView?.image = glassIconView?.image?.withRenderingMode(.alwaysTemplate)
        let crossIconView = textFieldInsideSearchBar?.value(forKey: "_clearButton") as? UIButton
        crossIconView?.setImage(crossImg, for: .normal)
        crossIconView?.setImage(crossImg, for: .highlighted)
        textFieldInsideSearchBar?.textColor = color
   
        let textFieldInsideSearchBarLabel = textFieldInsideSearchBar?.value(forKey: "placeholderLabel") as? UILabel
        glassIconView?.tintColor = color
        crossIconView?.tintColor = color
        textFieldInsideSearchBarLabel?.textColor = color
       }
}

extension DVSearchBar {
    func getTextField() -> UITextField? { return value(forKey: "searchField") as? UITextField }
    func set(textColor: UIColor) { if let textField = getTextField() { textField.textColor = textColor } }
    func setPlaceholder(textColor: UIColor) { getTextField()?.setPlaceholder(textColor: textColor) }
}
// MARK: - UITextField Extension Methods
private extension UITextField {
    private class Label: UILabel {
        private var _textColor = UIColor.lightGray
        override var textColor: UIColor! {
            set { super.textColor = _textColor }
            get { return _textColor }
        }

        init(label: UILabel, textColor: UIColor = .lightGray) {
            _textColor = textColor
            super.init(frame: label.frame)
            self.text = label.text
            self.font = label.font
        }
        required init?(coder: NSCoder) { super.init(coder: coder) }
    }
    var placeholderLabel: UILabel? { return value(forKey: "placeholderLabel") as? UILabel }
    func setPlaceholder(textColor: UIColor) {
        guard let placeholderLabel = placeholderLabel else { return }
        let label = Label(label: placeholderLabel, textColor: textColor)
        setValue(label, forKey: "placeholderLabel")
    }
}
