//
//  DVIssuerListModel.swift
//  DigitalVaultAppSample
//
//  Created by Neema Naidu on 30/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//

//  Model Class for Issuer list module

import Foundation

// MARK: - WelcomeElement
struct IssuerListModel: Codable {
    let partnerName, partnerID, partnerAddress: String?
    let credentialTypes: [CredentialType]?

    enum CodingKeys: String, CodingKey {
        case partnerName
        case partnerID = "partnerId"
        case partnerAddress, credentialTypes
    }
}

// MARK: WelcomeElement convenience initializers and mutators

extension IssuerListModel {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(IssuerListModel.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        partnerName: String?? = nil,
        partnerID: String?? = nil,
        partnerAddress: String?? = nil,
        credentialTypes: [CredentialType]?? = nil
        ) -> IssuerListModel {
        return IssuerListModel(
            partnerName: partnerName ?? self.partnerName,
            partnerID: partnerID ?? self.partnerID,
            partnerAddress: partnerAddress ?? self.partnerAddress,
            credentialTypes: credentialTypes ?? self.credentialTypes
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - CredentialType
struct CredentialType: Codable {
    let credentialType: String?
    let credentialTypeID: Int?
    let requestID, requestedOn, credentialID: String?
    let isCredentialRequested, isCredentialAvailable: String?

    enum CodingKeys: String, CodingKey {
        case credentialType
        case credentialTypeID = "credentialTypeId"
        case requestID = "requestId"
        case requestedOn
        case credentialID = "credentialId"
        case isCredentialRequested
        case isCredentialAvailable
    }
}

// MARK: CredentialType convenience initializers and mutators

extension CredentialType {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(CredentialType.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        credentialType: String?? = nil,
        credentialTypeID: Int?? = nil,
        requestID: String?? = nil,
        requestedOn: String?? = nil,
        credentialID: String?? = nil
        ) -> CredentialType {
        return CredentialType(
            credentialType: credentialType ?? self.credentialType,
            credentialTypeID: credentialTypeID ?? self.credentialTypeID,
            requestID: requestID ?? self.requestID,
            requestedOn: requestedOn ?? self.requestedOn,
            credentialID: credentialID ?? self.credentialID,
            isCredentialRequested: isCredentialRequested ?? self.isCredentialRequested,
            isCredentialAvailable: isCredentialAvailable ?? self.isCredentialAvailable
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

typealias IssuerList = [IssuerListModel]

extension Array where Element == IssuerList.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(IssuerList.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

// MARK: - Helper functions for creating encoders and decoders

func newJSONDecoder() -> JSONDecoder {
    let decoder = JSONDecoder()
    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
        decoder.dateDecodingStrategy = .iso8601
    }
    return decoder
}

func newJSONEncoder() -> JSONEncoder {
    let encoder = JSONEncoder()
    if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
        encoder.dateEncodingStrategy = .iso8601
    }
    return encoder
}
