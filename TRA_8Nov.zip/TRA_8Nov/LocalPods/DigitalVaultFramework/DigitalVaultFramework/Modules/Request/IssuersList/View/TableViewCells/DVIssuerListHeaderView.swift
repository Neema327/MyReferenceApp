//
//  VBHeader.swift
//  VBExpand_Tableview
//
//  Created by Vimal on 8/16/17.
//  Copyright © 2017 Crypton. All rights reserved.
//  Header Table view call class for Issuer list

import UIKit

class DVIssuerListHeaderView: UIView {
    @IBOutlet var headerLabel: UILabel!
    @IBOutlet var viewHeader: UIView!
    @IBOutlet var topSeperatorView: UIView!
    @IBOutlet var bottomSeperatorView: UIView!
    @IBOutlet var btnExpand: UIButton!
    @IBOutlet var imgArrow: UIImageView!
    @IBOutlet var iconImgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if DVConstants.uaepassArabicLocalization {
            headerLabel.font =  UIFont(name: ArabicFont.regular.rawValue, size: 18.0)
        }
    }
    /// Method for handling toggle of Issuer list section
    ///
    /// - Parameter toggleString: String for toggle variable
    func toggleRowDetails(toggleString: String) {
        if toggleString == "0" {
            bottomSeperatorView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
            topSeperatorView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
            UIView.animate(withDuration: 2) { () -> Void in
                self.imgArrow.image = DVCommon.getImage(named: "Disclosure-expand.png")
                let angle =  CGFloat(Double.pi * 2)
                let transformedVal = CGAffineTransform.identity.rotated(by: angle)
                self.imgArrow.transform = transformedVal
            }
        } else {
            bottomSeperatorView.backgroundColor = UIColor.clear
            topSeperatorView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
            UIView.animate(withDuration: 2) { () -> Void in
                self.imgArrow.image = DVCommon.getImage(named: "Disclosure-Indicator-collapse.png")
                let angle =  CGFloat(Double.pi * 2)
                let transformedVal = CGAffineTransform.identity.rotated(by: angle)
                self.imgArrow.transform = transformedVal
            }
        }
    }
    /// Method for configuaring all the Issuer list values
    ///
    /// - Parameter issuer: IssuerListModel object
    func configureIssuerListHeaderValues(issuer: IssuerListModel) {
        headerLabel.textColor =  UIColor.colorFromHex(rgbValue: 0x454F63)
        iconImgView.kf.cancelDownloadTask()
        iconImgView.kf.indicatorType = .activity
        if let docId = issuer.partnerID {
            let  iconURL  =  baseURL + apiVersion + EndPoint.issuersListLogo.rawValue + "\(docId)" + "/icon"
            if let url = URL(string: iconURL) {
                iconImgView.kf.setImage(
                    with: url,
                    placeholder: DVConstants.placeholderSmallImage,
                    options:
                    [.waitForCache, .loadDiskFileSynchronously, .transition(.none)],
                progressBlock: nil) {
                    result in
                    switch result {
                    case .success: break
                    case .failure(let error): break
                    }
                }
            }
        }
    }
}
