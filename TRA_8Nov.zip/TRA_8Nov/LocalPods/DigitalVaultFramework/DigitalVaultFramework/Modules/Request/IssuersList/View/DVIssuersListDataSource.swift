//
//  DVIssuersListDataSource.swift
//  Alamofire
//
//  Created by Neema Naidu on 12/08/19.
//  Class for handling DVIssuersListViewController table view delegate and data source

import UIKit
protocol DVIssuersListDataSourceDelegate: class {
    func displayIssuersDetailView(indexPath: IndexPath)
}
class DVIssuersListDataSource: NSObject {

    var tableView: UITableView?
    weak var delegate: DVIssuersListDataSourceDelegate?
    var issuersListViewModel =  DVIssuersListViewModel()
    override init() {
        super.init()
    }

}
// MARK: - UITableViewDataSource Methods
extension DVIssuersListDataSource: UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 82
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        if let str: String = issuersListViewModel.arrStatus[section] as? String {
            if str == "0" {
                return 0
            }
        }
        return issuersListViewModel.numberOfRows(section: section)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.issuersListViewModel.numberOfSections()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "DVIssuersListTableViewCell",
                                                    for: indexPath) as? DVIssuersListTableViewCell {
            cell.selectionStyle = .none
            let credentialType = issuersListViewModel.issuersCredentials?[indexPath.section].credentialTypes?[indexPath.row]
            if let cred = credentialType {
                cell.configureIssuerListValues(credentialType: cred)
            }
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        let defaultSectionHeaderView = UIView(frame: .zero)
        if let dvBundle = DVCommon.getDVBundle() {
            if let headerView = dvBundle.loadNibNamed("DVIssuerListHeaderView", owner: self, options: nil)?[0] as? DVIssuerListHeaderView {
                headerView.headerLabel.text = self.issuersListViewModel.getIssuerName(section: section)
                headerView.btnExpand.addTarget(self, action: #selector(headerCellButtonTapped(sender:)), for: UIControl.Event.touchUpInside)
                headerView.btnExpand.tag = section
                if let issuerDet = issuersListViewModel.issuersCredentials?[section] {
                    headerView.configureIssuerListHeaderValues(issuer: issuerDet)
                }
                if let str: String = issuersListViewModel.arrStatus[section] as? String {
                    headerView.toggleRowDetails(toggleString: str)
                }
                return headerView
            }
           
        }
        return defaultSectionHeaderView
    }
}
// MARK: - UITableViewDelegate Methods
extension DVIssuersListDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.displayIssuersDetailView(indexPath: indexPath)
    }
}
// MARK: - Action Methods
extension DVIssuersListDataSource {
    /// Method for handling Header cell button tap functionality
    ///
    /// - Parameter sender: UIButton sender for sender tag
    @objc func headerCellButtonTapped(sender: UIButton) {
        if let str: String = issuersListViewModel.arrStatus[sender.tag] as? String {
            if str == "0" {
                issuersListViewModel.arrStatus[sender.tag] = "1"
            } else {
                issuersListViewModel.arrStatus[sender.tag] = "0"
            }
            let indexSet: IndexSet = [sender.tag]
            self.tableView?.reloadSections(indexSet, with: .automatic)
        }
    }
}
