//
//  DVIssuersListViewModel.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 15/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//  View Model Class for Issuer list module

import Foundation
import UIKit
import PromiseKit

class DVIssuersListViewModel: NSObject {
    var issuersCredentials: IssuerList?
    let dataConverterHelper = DataConverterHelper() as DataConverter
    var sortOrder: SortOrders = .name
    var arrStatus: NSMutableArray = []
    var searchActive: Bool = false
    var searchText = ""
    var sortActive: Bool = false

    /// Method to hide show NoDocs View
    ///
    /// - Returns: Bool to display NoDocs View
//    func displayNoDocsAvailableView() -> Bool {
//        var needToDisplay = false
//        if issuersCredentials != nil {
//            needToDisplay =  (numberOfSections() == 0) ? true : false
//        }
//        return needToDisplay
//    }
    func displayNoDocsAvailableView() -> TableRefreshType {
        var tableRefreshType: TableRefreshType = .dataError
        if let issuersCount = issuersCredentials?.count {
            tableRefreshType =  (issuersCount == 0) ? .noDocsAvailable  : .docsAvailable
        }
        return tableRefreshType
    }
    /// Method to configure noDocs View object values
    ///
    /// - Returns: String title and text for noDocs View
    func noDocsAvlDetails() -> (title: String, text: String) {
        var titleMessage = ""
        var textMessage = ""
        if searchActive {
            titleMessage = ""
            textMessage = IssuersList.validkeySearchMesssage + " <\(searchText)>"
        } else {
            titleMessage = Documents.noDocsMsg
            textMessage = Documents.addDocsMsg
        }
        return (titleMessage, textMessage)
    }
    /// Method to hide show Sort button
    ///
    /// - Returns: Bool to display Sort button
    func showHideSortButton() -> Bool {
        var needToDisplay = false
        if issuersCredentials != nil {
            needToDisplay =  (numberOfSections() > 1) ? true : false
        }
        return needToDisplay
    }
    /// Method to Reset all flags for expand collapse sections
    func resetAllFlagValues() {
        self.arrStatus.removeAllObjects()
        if let issuerCred = self.issuersCredentials {
            for _ in 0...issuerCred.count // pass your array count
            {
                self.arrStatus.add("0")
            }
        }
    }
}

extension DVIssuersListViewModel {
    /// method to trigger Issuer list service
    ///
    /// - Parameters:
    ///   - sortType: SortOrder enum to get the sorting order
    ///   - completionHandler: success closure handler
    ///   - failureHandler: failure closure handler
    func fetchIssuersListData(sortType: SortOrder, completionHandler: @escaping SuccessClosure,
                               failureHandler: @escaping FailureClosure) {
        self.getIssuersList(sortType: sortType, completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }

    func getIssuersList(sortType: SortOrder, completionHandler: @escaping SuccessClosure,
                                  failureHandler: @escaping FailureClosure) {
        self.invokeServiceForIssuersList(sortedBy: sortType)
                .done({ (officialDocsList) in
                    guard let newOfficialDocs = officialDocsList as? IssuerList else {
                        failureHandler(false, dvDataError)
                        return
                    }
                    self.issuersCredentials = newOfficialDocs
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }

    func invokeServiceForIssuersList(sortedBy: SortOrder) -> Promise<Any> {
        return Promise {  seal in
            sortActive = true
            var serviceURL: String =  baseURL + apiVersion + EndPoint.issuersListDefault.rawValue
            serviceURL =    serviceURL + "&filter=\(searchText)" + "&order=" + sortedBy.rawValue
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.json.rawValue
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as IssuerList?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                
                //Decode server response
                DVCommon.decodeResponse(type: IssuerList.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (officialDocsList) in
                        seal.fulfill(officialDocsList)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
}
extension DVIssuersListViewModel {
    /// Method for getting number of rows in Issuer list table view
    ///
    /// - Parameter section: selected section
    /// - Returns: Int number of rows
    func numberOfRows(section: Int) -> Int {
      return issuersCredentials?[section].credentialTypes?.count ?? 0
    }
    /// Method for getting number of sections in Issuer list table view
    ///
    /// - Returns: Int number of sections
    func numberOfSections() -> Int {
        return issuersCredentials?.count ?? 0
    }
    /// Method to get the Issuer name value
    ///
    /// - Parameter section: selected section
    /// - Returns: String Issuer name
    func getIssuerName(section: Int) -> String {
        if let issuer = issuersCredentials?[section] {
            return issuer.partnerName ?? ""
        }
        return ""
    }
}
