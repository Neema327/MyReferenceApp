//
//  DVIssuersListTableViewCell.swift
//  DigitalVaultAppSample
//
//  Created by Neema Naidu on 29/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//  Table view call class for Issuer list

import UIKit
import Foundation

class DVIssuersListTableViewCell: UITableViewCell {

    @IBOutlet var credentialTitle: UILabel!
    @IBOutlet var statusLbl: UILabel!
    @IBOutlet var credentialDateLbl: UILabel!
    @IBOutlet weak var statusView: UIView!
    @IBOutlet weak var statusImageView: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        if DVConstants.uaepassArabicLocalization {
            credentialTitle.font = UIFont(name: ArabicFont.regular.rawValue, size: 15.0)
            statusLbl.font = UIFont(name: ArabicFont.regular.rawValue, size: 14.0)
            credentialDateLbl.font = UIFont(name: ArabicFont.regular.rawValue, size: 14.0)
            credentialDateLbl.textAlignment = .left
        }
        credentialDateLbl.adjustsFontSizeToFitWidth = true
        credentialDateLbl.minimumScaleFactor = 0.2
        statusImageView.layer.cornerRadius = statusImageView.frame.size.width / 2
        statusImageView.clipsToBounds = true
        statusImageView.layer.borderWidth = 0.5
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    static var identifier: String {
        return String(describing: self)
    }
    /// Method for handling status of the issuer document
    ///
    /// - Parameter credentialType: CredentialType object
    func getStatusOfCrdential(credentialType: CredentialType) {
        let isCredentialRequested = credentialType.isCredentialRequested ?? ""
        let isCredentialAvailable = credentialType.isCredentialAvailable ?? ""
        
        if isCredentialRequested == "YES" && isCredentialAvailable == "YES" {
            statusImageView.layer.borderColor = UIColor.clear.cgColor
            credentialTitle.textColor =  UIColor.colorFromHex(rgbValue: 0x00A36A)
            statusLbl.text = IssuersList.added
            statusImageView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
            statusView.isHidden = false
        } else if isCredentialRequested == "YES" && isCredentialAvailable == "NO" {
            statusImageView.layer.borderColor = UIColor.clear.cgColor
            credentialTitle.textColor =  UIColor.colorFromHex(rgbValue: 0xE19E01)
            statusImageView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xE19E01)
            statusLbl.text = IssuersList.inProgress
            statusView.isHidden = false
        } else if isCredentialRequested == "NO" && isCredentialAvailable == "NO" {
            statusImageView.layer.borderColor = UIColor.lightGray.cgColor
            credentialTitle.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
            statusImageView.backgroundColor = UIColor.white
            statusView.isHidden = true
        }
    }
    /// Method for configuring Issuer list values
    ///
    /// - Parameter credentialType: CredentialType object
    func configureIssuerListValues(credentialType: CredentialType) {
        credentialTitle.text =  credentialType.credentialType ?? ""
        if let dateStr =  Date.getFormattedDate(date: credentialType.requestedOn ?? "") {
            credentialDateLbl.text = dateStr
        }
        getStatusOfCrdential(credentialType: credentialType)
    }
}
