//
//  DVConfirmTableViewController.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 19/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//  View class for Request confirmtaion of documents

import Foundation
import UIKit

class DVConfirmViewController: DVBaseViewController {

    @IBOutlet var subTitleLabel: UILabel!
    @IBOutlet var agreeLbl: UILabel!
    @IBOutlet var agreeTermsView: UIView!
    @IBOutlet var titleView: UIView!
    @IBOutlet var confirmTableView: UITableView!
    @IBOutlet var confirmButton: UIButton!
    @IBOutlet weak var agreeSwitch: UISwitch!
    @IBOutlet var containerView: UIView!

    let confirmViewModel = DVConfirmViewModel()
    var pickerSelected: String!
    var isFromHome: Bool!
    var credentialTypeId: Int!
    var partnerId: String!
    var subTitleStr: String!

    lazy private var activityIndicatorView: DVProgressIndicatorView = {
        let progressIndicatorView = DVProgressIndicatorView()
        return progressIndicatorView
    }()
    lazy private var confirmDataSource: DVConfirmDataSource = {
        let officialDataSrc = DVConfirmDataSource()
        return officialDataSrc
    }()
    private let dvTextTableViewCellIdentifier = "DVTextTableViewCell"
    private let dvToggleTableViewCellIdentifier = "DVToggleTableViewCell"

    override func viewDidLoad() {
        super.viewDidLoad()
        configureConfirmFormPage()
        loadConfirmData()
        configureLocalizationFonts()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}

// MARK: - Private Methods
extension DVConfirmViewController {
    /// method for configuraing UI elements
    func configureConfirmFormPage() {
        confirmButton.setViewsLayer(layer: confirmButton.layer, shouldLayerBorderClearColor: false)
        confirmButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xB0B7C4)
        confirmTableView.layer.shadowColor = UIColor.lightGray.cgColor
        confirmTableView.layer.shadowOpacity = 2
        confirmTableView.layer.shadowOffset = CGSize.zero
        confirmTableView.layer.shadowRadius = 4
        UITableView.registerCellWithIdentifier(cellIdentifier: dvTextTableViewCellIdentifier, tblVw: self.confirmTableView)
        UITableView.registerCellWithIdentifier(cellIdentifier: dvToggleTableViewCellIdentifier, tblVw: self.confirmTableView)
        self.confirmDataSource.confirmViewModel = self.confirmViewModel
        self.confirmDataSource.tableView = self.confirmTableView
        self.confirmDataSource.subTitleStr = subTitleStr
        self.confirmDataSource.delegate = self
        self.confirmTableView.delegate = self.confirmDataSource
        self.confirmTableView.dataSource = self.confirmDataSource
        confirmViewModel.partnerId = partnerId
        confirmViewModel.credentialTypeId = credentialTypeId
        confirmButton.setTitle(Confirm.confirmButtonTitle, for: .normal)
        agreeLbl.text = Confirm.agreeDocumentText
        subTitleLabel.text = IssuersList.requestTitle
        subTitleLabel.minimumScaleFactor = 0.5
        subTitleLabel.adjustsFontSizeToFitWidth = true
        agreeLbl.minimumScaleFactor = 0.5
        agreeLbl.adjustsFontSizeToFitWidth = true
        self.confirmTableView.contentInset = UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)
        agreeSwitch.isOn = false
        confirmButton.isEnabled = false
        containerView.setViewsLayer(layer: containerView.layer, shouldLayerBorderClearColor: true)
        confirmTableView.setViewsLayer(layer: confirmTableView.layer, shouldLayerBorderClearColor: true)
        activityIndicatorView.addActivityIndicatorToTheView(view: self.view)
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
    }
    /// method for adding localization fonts and styles
    func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            subTitleLabel.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 35.0)
            confirmButton.titleLabel?.font = UIFont(name: ArabicFont.regular.rawValue, size: 20.0)
            agreeLbl.font = UIFont(name: ArabicFont.regular.rawValue, size: 15.0)
        }
    }
    /// Method to handle navigation in success scenario
    func navigateToSuccessScreen() {
        let requestCredentialViewController = DVNotifiedViewController(nibName: "DVNotifiedViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
        requestCredentialViewController.isFromHome = isFromHome
        requestCredentialViewController.subTitlesStr = IssuersList.requestTitle
        requestCredentialViewController.titleLabel = Confirm.title
        let notifiedImage = DVCommon.getImage(named: "success-doc-ico")
        requestCredentialViewController.loadView()
        requestCredentialViewController.updateNotifiedUI(title: Confirm.title, subTitle: IssuersList.requestTitle, alertTitle: Success.message, image: notifiedImage)
        self.navigationController?.pushViewController(requestCredentialViewController, animated: true)
    }
}
// MARK: - Service Methods
extension DVConfirmViewController {
    /// method to trigger service call for loading confirm list
    func loadConfirmData() {
        displayActivityIndicatorView()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.confirmViewModel.getConfirm(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.agreeTermsView.isHidden = false
                    self?.confirmTableView.isHidden = false
                    self?.confirmTableView.reloadData()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        self?.hideActivityIndicatorView()
                        self?.agreeTermsView.isHidden = true
                        self?.confirmTableView.isHidden = true
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    /// method to trigger service call for posting confirm data
    func postConfirmForm() {
        displayActivityIndicatorView()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.confirmViewModel.postConfirmForm(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    self?.hideActivityIndicatorView()
                    self?.navigateToSuccessScreen()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        self?.hideActivityIndicatorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
}
// MARK: - Loader Methods
extension DVConfirmViewController {
    /// Method to hide and show ActivityIndicatorView
    func displayActivityIndicatorView() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
    }
    func hideActivityIndicatorView() {
        DVCommon.hideActivityIndicatorView()
    }
}

// MARK: - IBAction Methods
extension DVConfirmViewController {
    /// Method for handling switch value
    ///
    /// - Parameter sender: UISwitch object
    @IBAction func switchValueDidChange(sender: UISwitch!) {
        if (sender.isOn == true) {
            confirmButton.isEnabled = true
            confirmButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)

        } else {
            confirmButton.isEnabled = false
            confirmButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xB0B7C4)
        }
    }
    @IBAction func confirmBtnAction(sender: UIButton) {
        confirmViewModel.constructFormDictionary()
        postConfirmForm()
    }
}

extension DVConfirmViewController: DVConfirmDataSourceDelegate {
    func displayConfirmDetailView(indexPath: IndexPath) {

    }
}
