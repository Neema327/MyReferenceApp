//
//  VBHeader.swift
//  VBExpand_Tableview
//
//  Created by Vimal on 8/16/17.
//  Copyright © 2017 Crypton. All rights reserved.
//

import UIKit

class DVConfirmHeaderView: UIView {
    @IBOutlet var headerLabel: UILabel!
    @IBOutlet var headerdesc: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        if DVConstants.uaepassArabicLocalization {
            headerLabel.font = UIFont(name: ArabicFont.bold.rawValue, size: 18.0)
            headerdesc.font = UIFont(name: ArabicFont.regular.rawValue, size: 16.0)
        }
        headerdesc.text = Confirm.confirmdescTitle
    }
}
