//
//  DVConfirmDataSource.swift
//  Alamofire
//
//  Created by Neema Naidu on 12/08/19.
//  Class for handling DVConfirmViewController table view delegate and data source

import Foundation
import UIKit

protocol DVConfirmDataSourceDelegate: class {
    func displayConfirmDetailView(indexPath: IndexPath)
}

class DVConfirmDataSource: NSObject {
    var tableView: UITableView?
    var subTitleStr: String?
    weak var delegate: DVConfirmDataSourceDelegate?
    var confirmViewModel = DVConfirmViewModel()
    override init() {
        super.init()
    }
}
// MARK: - UITableViewDataSource Methods
extension DVConfirmDataSource: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        guard let parameters = confirmViewModel.confirmDic["parameters"] as? [[String: Any]] else {
            return 0
        }
        return parameters.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
         return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let parameters = confirmViewModel.confirmDic["parameters"] as? [[String: Any]] {
            let  confirmFormDic = parameters[indexPath.row]
            if let parameterType = confirmFormDic["type"] as? String {
                if parameterType == "TEXT" || parameterType == "DROPDOWN" || parameterType == "DATE" {
                    if let cell = tableView.dequeueReusableCell(withIdentifier: "DVTextTableViewCell", for: indexPath) as? DVTextTableViewCell {
                    cell.selectionStyle = .none
                    if let parameterLbl = confirmFormDic["label"] as? String {
                        cell.valTextField.placeholder = parameterLbl
                        if let mandatoryField = confirmFormDic["mandatory"] as? Bool {
                            cell.checkMandatoryField(parameterLbl: parameterLbl, mandatoryField: mandatoryField)
                        }
                        cell.delegate = self
                    }
                    var pickerNationalityOptions = [String]()
                    if let userInput = confirmFormDic["userInput"] as? String {
                        cell.valTextField.text = userInput
                    } else {
                        if let parameterText = confirmFormDic["value"] as? String {
                            cell.valTextField.text = parameterText
                            if parameterType == "DROPDOWN" {
                                pickerNationalityOptions.append(parameterText)
                            }
                            cell.valTextField.text = parameterText
                        } else {
                            cell.valTextField.text = ""
                        }
                    }
                    cell.createCustomPickerView(options: pickerNationalityOptions, inputType: parameterType)
                    return cell
                   }
                } else if parameterType == "Boolean Toggle" {
                    if let cell = tableView.dequeueReusableCell(withIdentifier: "DVToggleTableViewCell", for: indexPath) as? DVToggleTableViewCell {
                    cell.selectionStyle = .none
                    cell.configureToggleCell(parameterArray: confirmFormDic)
                    cell.delegate = self
                    return cell
                   }
                }
            }
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let defaultSectionHeaderView = UIView(frame: .zero)
        if let dvBundle = DVCommon.getDVBundle() {
            if let sectionHeaderView = dvBundle.loadNibNamed("DVConfirmHeaderView", owner: self, options: nil)?[0] as? DVConfirmHeaderView {
                sectionHeaderView.headerLabel.text = confirmViewModel.confirmDic["label"] as? String
                sectionHeaderView.headerLabel.numberOfLines = 2
                sectionHeaderView.headerLabel.text = subTitleStr // confirmViewModel.confirmDic["label"] as? String
                return sectionHeaderView
            }
        }
        return defaultSectionHeaderView
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
        return 73
    }
}
// MARK: - DVTableViewCellDelegate Methods
extension DVConfirmDataSource: DVTableViewCellDelegate {
    /// Method for handling textFieldDidEndEditing
    ///
    /// - Parameters:
    ///   - cell: Current selected UITableViewCell
    ///   - textField: current UITextField
    func textFieldDidEndEditing(cell: UITableViewCell, textField: UITextField) {
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView?.scrollToRow(at: indexPath, at: .top, animated: true)
        if let singleOptionCell = cell as? DVTextTableViewCell {
            let currentIndexPath = self.tableView?.indexPath(for: singleOptionCell)
            if var indexPathSelected = currentIndexPath {
                if var parameters = confirmViewModel.confirmDic["parameters"] as? [[String: Any]] {
                    var  confirmFormDic = parameters[indexPathSelected.row]

                    if let textInput = textField.text {
                        confirmFormDic.updateValue(textInput, forKey: "userInput")
                    }
                    parameters[indexPathSelected.row] = confirmFormDic
                    if var params = confirmViewModel.confirmDic["parameters"] as? [[String: Any]] {
                        params[indexPathSelected.row]  = confirmFormDic
                        confirmViewModel.confirmDic["parameters"] = parameters
                    }
                }
            }
        }
    }
}
// MARK: - DVToggleCellDelegate Methods
extension DVConfirmDataSource: DVToggleCellDelegate {
    /// Method for opations action
    ///
    /// - Parameter sender: UIButton sender 
    func optionsActios(sender: UIButton) {
        if (sender.isSelected == true) {
            sender.isSelected = false
        } else {
            sender.isSelected = true
        }
    }
}
