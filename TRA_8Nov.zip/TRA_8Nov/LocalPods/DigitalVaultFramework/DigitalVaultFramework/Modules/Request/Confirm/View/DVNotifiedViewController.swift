//
//  DVNotifiedViewController.swift
//  DigitalVaultAppSample
//
//  Created by Neema Naidu on 30/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//  View class for displaying success notification view

import UIKit

class DVNotifiedViewController: DVBaseViewController {

    @IBOutlet var backView: UIView!
    @IBOutlet var okButton: UIButton!
    @IBOutlet var successImg: UIImageView!
    @IBOutlet var alertLbl: UILabel!
    @IBOutlet var successLbl: UILabel!
    @IBOutlet var subTitleLbl: UILabel!
    @IBOutlet var notifiedImage: UIImageView!
    var isFromPresentmentFlow = false
    var isPresentmentAppToAppFlow = false
    var titleLabel: String = ""
    var subTitlesStr: String = ""
    var alertText = ""
    var isFromHome: Bool!
    var objectDataDict: [String: Any]?
    var apptoappSuccessUrl: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        okButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}
// MARK: - Private Methods
extension DVNotifiedViewController {
    ///  method to update UI elements with updated texts and images
    func updateNotifiedUI(title: String, subTitle: String, alertTitle: String, image: UIImage) {
        configureLocalizationFonts()
        self.navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.isHidden = true
        okButton.setTitle(Success.okButtonTitle, for: .normal)
        successLbl.text = Success.title
        subTitleLbl.minimumScaleFactor = 0.5
        subTitleLbl.adjustsFontSizeToFitWidth = true
        backView.setViewsLayer(layer: backView.layer, shouldLayerBorderClearColor: true)
        okButton.setViewsLayer(layer: okButton.layer, shouldLayerBorderClearColor: false)
        self.alertLbl.text = alertTitle
        self.subTitleLbl.text = subTitle
        notifiedImage.image = image
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        backView.layer.shadowColor = UIColor.lightGray.cgColor
        backView.layer.shadowOpacity = 2
        backView.layer.shadowOffset = CGSize.zero
        backView.layer.shadowRadius = 4
    }
}
// MARK: - IBAction Methods
extension DVNotifiedViewController {
    @IBAction func okBtnAction(sender: UIButton) {
        guard let navControllers = self.navigationController?.viewControllers else {
            return
        }
        
        if isPresentmentAppToAppFlow {
            if let successUrlString = apptoappSuccessUrl, let url = URL(string: successUrlString) {
                UIApplication.shared.open(url, options: [:]) { _ in
                    self.navigationController?.dismiss(animated: true, completion: nil)
                }
            }
        } else if isFromHome == true {
            for controller in navControllers as Array {
                if controller.isKind(of: DVIssuersListViewController.self) {
                    self.navigationController?.popToViewController(controller, animated: true)
                    break
                }
            }
        } else if isFromPresentmentFlow == true {
            for controller in navControllers as Array {
                if controller.isKind(of: DVNotificationsListViewController.self) {
                    self.navigationController?.popToViewController(controller, animated: true)
                    break
                }
            }
        } else {
            for controller in navControllers as Array {
                if controller.isKind(of: DVDocumentsViewController.self) {
                    self.navigationController?.popToViewController(controller, animated: true)
                    break
                }
            }
        }
    }
}
// MARK: - Private Methods
extension DVNotifiedViewController {
    /// method for adding localization fonts and styles
    func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            subTitleLbl.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 35.0)
            successLbl.font = UIFont(name: ArabicFont.bold.rawValue, size: 18.0)
            alertLbl.font = UIFont(name: ArabicFont.regular.rawValue, size: 17.0)
            okButton.titleLabel?.font = UIFont(name: ArabicFont.bold.rawValue, size: 20.0)
        }
    }

}

