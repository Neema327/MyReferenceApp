//
//  TextTableViewCell.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 19/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//

import UIKit

protocol DVTableViewCellDelegate: class {
    func textFieldDidEndEditing(cell: UITableViewCell, textField: UITextField)
}

class DVTextTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var valTextField: UITextField!
    @IBOutlet weak var valLabel: UILabel!
    var customPickerView: UIPickerView?
    weak var delegate: DVTableViewCellDelegate?
    var pickerOptions: [String]?
    var datePicker: UIDatePicker?
    var selectedInputType: String?

    override func awakeFromNib() {
        super.awakeFromNib()
        if DVConstants.uaepassArabicLocalization {
            valLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 14.0)
            valTextField.semanticContentAttribute = .forceRightToLeft
            if valTextField.textAlignment == .natural {
                valTextField.textAlignment = .right
            }
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
// MARK: - Private Methods
extension DVTextTableViewCell {
    /// Method to create picker
    ///
    /// - Parameters:
    ///   - options: String for option type
    ///   - inputType: String input type
    func createCustomPickerView(options: [String], inputType: String) {
        selectedInputType = inputType
        valTextField.reloadInputViews()
        if (inputType == "DROPDOWN") {
            if self.customPickerView == nil {
                self.customPickerView = UIPickerView()
                self.pickerOptions = options
                customPickerView?.delegate = self
                customPickerView?.dataSource = self
                customPickerView?.showsSelectionIndicator = true
                valTextField.inputView = customPickerView
            }
        } else if (inputType == "DATE") {
            if self.datePicker == nil {
                self.datePicker = UIDatePicker()
                datePicker?.datePickerMode = .date
                valTextField.inputView = datePicker
            }
        } else if (inputType == "TEXT") {
            valTextField.inputView = nil
        }
        createToolbar()
    }
    /// Method to check mandatory fields
    ///
    /// - Parameters:
    ///   - parameterLbl: String parameterLbl
    ///   - mandatoryField: Bool mandatoryField
    func checkMandatoryField(parameterLbl: String, mandatoryField: Bool) {
        valTextField.placeholder = parameterLbl
        valLabel.text = parameterLbl
    }
    /// Method to create tool bar
    func createToolbar() {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        toolBar.tintColor = .white
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonClicked))
        doneButton.tintColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .done, target: self, action: #selector(self.cancelDatePicker))
        cancelButton.tintColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        valTextField.inputAccessoryView = toolBar
        
    }
    /// done button action
    @objc func doneButtonClicked() {
        if selectedInputType == "DATE" {
            let formatter = DateFormatter()
            formatter.dateFormat = "dd/MM/yyyy"
            
            if let selectedDate = datePicker?.date {
                valTextField.text = formatter.string(from: selectedDate)
            }
        } else if selectedInputType == "DROPDOWN" {
            if let selectedRow =  customPickerView?.selectedRow(inComponent: 0) {
                valTextField.text = pickerOptions?[selectedRow]
            }
        }
        self.endEditing(true)
    }
    /// cancel button action
    @objc func cancelDatePicker() {
        self.endEditing(true)
    }
    /// Method to handle textFieldDidEndEditing
    ///
    /// - Parameter textField: UITextField object
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let delegate = delegate {
            delegate.textFieldDidEndEditing(cell: self, textField: textField)
        }
    }
}
// MARK: - Picker Methods
extension  DVTextTableViewCell: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if let pickerOption = pickerOptions {
            return pickerOption.count
        }
        return 0
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerOptions?[row]
    }
}
