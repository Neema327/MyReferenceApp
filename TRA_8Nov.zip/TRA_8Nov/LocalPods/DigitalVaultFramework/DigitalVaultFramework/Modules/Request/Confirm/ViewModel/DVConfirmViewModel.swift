//
//  ConfirmViewModel.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 17/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//  View Model Class for Confirm module

import Foundation
import UIKit
import PromiseKit

class DVConfirmViewModel: NSObject {
    var mainOptionsArray: [String]?
    let dataConverterHelper = DataConverterHelper() as DataConverter
    var confirmDic =  [String: Any]()
    var credentialTypeId: Int!
    var partnerId: String!
    var mainFormDic = [String: Any]()
    
    /// Method to construct post form dictionary
    func constructFormDictionary() {
        var requestDataDict =  [String: Any]()
        var issuerDict =  [String: Any]()
        var credentilaTypeDict =  [String: Any]()
        if let parameters = confirmDic["parameters"] as? [[String: Any]] {
            for param in parameters {
                if let field = param["field"] as? String {
                    if let value = param["value"] as? String {
                        if let userInput = param["userInput"] as? String {
                            if userInput.isEmpty {
                                requestDataDict[field] = value
                            } else {
                                requestDataDict[field] = userInput
                            }
                        } else {
                            requestDataDict[field] = value
                        }
                    }
                }
            }
            issuerDict["partnerId"] = partnerId
            credentilaTypeDict["id"] = credentialTypeId
            mainFormDic["issuer"] = issuerDict
            mainFormDic["credentialDocumentType"] = credentilaTypeDict
            mainFormDic["requestedData"] = requestDataDict
        }
    }
}

extension DVConfirmViewModel {
    /// Method to trigger service call for fetching confirm data
    ///
    /// - Parameters:
    ///   - completionHandler: success closure handler
    ///   - failureHandler: failure closure handler
    func fetchConfirmData(completionHandler: @escaping SuccessClosure,
                              failureHandler: @escaping FailureClosure) {
       self.getConfirm(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    /// Method to trigger service call for posting confirm data
    ///
    /// - Parameters:
    ///   - completionHandler: success closure handler
    ///   - failureHandler: failure closure handler
    func postConfirmForm(completionHandler: @escaping SuccessClosure,
                         failureHandler: @escaping FailureClosure) {
            self.invokeServiceForConfirmForm()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error)
            }

    }
    func getConfirm(completionHandler: @escaping SuccessClosure,
                        failureHandler: @escaping FailureClosure) {
            self.invokeServiceForConfirm()
                .done({ (data) in
                    if let jsonData = data as? Data, let jsonResult = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) {
                        //try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)

                        guard let jsonDict = jsonResult as? [String: Any] else {
                            failureHandler(false, dvDataError)
                            return
                        }
                        self.confirmDic = jsonDict
                        completionHandler(true, "")
                    }

                })
                .catch { error in
                    failureHandler(false, error)
            }
        }
    func invokeServiceForConfirmForm() -> Promise<Any> {

        return Promise {  seal in

            let serviceURL: String =  baseURL + apiVersion + EndPoint.credentialRequest.rawValue
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            var reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken
            headerParams[content] = ContentType.json.rawValue

            reqParameters = mainFormDic

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.POST) {
                (jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }

    func invokeServiceForConfirm() -> Promise<Any> {
        return Promise {  seal in
            let credentialId = self.credentialTypeId ?? 0
            let parameterId = self.partnerId ?? ""

            var serviceURL: String =  baseURL + apiVersion + EndPoint.issuersListLogo.rawValue
            serviceURL =    serviceURL + "\(parameterId)" + "/credentialTypes/" + "\(credentialId)" + "/queryparameters?"

            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.json.rawValue
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
}
