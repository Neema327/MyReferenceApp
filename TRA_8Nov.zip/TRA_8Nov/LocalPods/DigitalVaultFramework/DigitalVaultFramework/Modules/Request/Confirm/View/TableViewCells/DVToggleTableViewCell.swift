//
//  ToggleTableViewCell.swift
//  DigitalVaultAppSample
//
//  Created by CDB_Int1 on 19/07/19.
//  Copyright © 2019 Lija George. All rights reserved.
//

import UIKit
protocol DVToggleCellDelegate: class {
    func optionsActios(sender: UIButton)
}
@available(iOS 9.0, *)
class DVToggleTableViewCell: UITableViewCell {
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var maleLabel: UILabel!
    @IBOutlet weak var femaleLabel: UILabel!
    @IBOutlet weak var genderStackView: UIStackView!
    let confirmViewModel = DVConfirmViewModel()
    weak var delegate: DVToggleCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    /// Method to handle Toggle cell
    ///
    /// - Parameter parameterArray: [String: Any] parameter array
    func configureToggleCell(parameterArray: [String: Any]) {
        for subView in genderStackView.arrangedSubviews {
            subView.removeFromSuperview()
        }
        if let values = parameterArray["values"] as? [[String: Any]] {
            for value in values {
                if let name = value["name"] as? String {
                    let genderButton = UIButton()
                    genderButton.setTitleColor(UIColor.colorFromHex(rgbValue: 0x00A36A), for: .normal)
                    genderButton.setTitle(name, for: .normal)
                    genderButton.setImage(DVCommon.getImage(named: "radio-btn-ico"), for: .normal)
                    genderButton.setImage(DVCommon.getImage(named: "selected-radio-btn-ico"), for: .selected)
                    UIButton.centerTextAndImage(spacing: 20, button: genderButton)
                    genderButton.contentHorizontalAlignment = .left
                    genderButton.addTarget(self, action: #selector(toggleButtonAction(sender:)), for: UIControl.Event.touchUpInside)
                    genderStackView.addArrangedSubview(genderButton)
                }
            }
        }
    }
    /// method to handle toggle Button Action
    ///
    /// - Parameter sender: UIButton sender action
    @objc func toggleButtonAction(sender: UIButton) {
        if let delegate = delegate {
            delegate.optionsActios(sender: sender)
        }
    }
}
