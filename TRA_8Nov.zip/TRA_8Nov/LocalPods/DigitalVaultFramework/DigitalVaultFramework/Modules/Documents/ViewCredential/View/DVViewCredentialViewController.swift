//
//  DVViewCredentialViewController.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 17/07/19.

import UIKit
import WebKit
class DVViewCredentialViewController: UIViewController, WKUIDelegate {
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var docNameLabel: UILabel!
    let credentialViewModel = DVViewCredentialViewModel()
    var credentialId: String?
    var credentialName: String?
    var detailTitle = ""

    @IBOutlet weak var viewEvidenceButton: UIButton!
    lazy var progressIndicatorView: DVProgressIndicatorView = {
        let activityIndicator = DVProgressIndicatorView()
        return activityIndicator
    }()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        WKWebView.clean()
        docNameLabel.text = detailTitle
        docNameLabel.adjustsFontSizeToFitWidth = true
        docNameLabel.minimumScaleFactor = 0.2
        configureViews()
        configureLocalizationFonts()
        loadCredentialData()
    }
    override func viewWillAppear(_ animated: Bool) {
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}
// MARK: - Private Methods
extension DVViewCredentialViewController {
    func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
//            docNameLabel.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 35.0)
            viewEvidenceButton.titleLabel?.font = UIFont(name: ArabicFont.twoBold.rawValue, size: 20.0)

        }
    }
    func configureViews() {
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        progressIndicatorView.addActivityIndicatorToTheView(view: self.webView)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        containerView.setUpRoundedCornerView(view: containerView)
        viewEvidenceButton.setTitle(Documents.viewEvidence, for: .normal)
        viewEvidenceButton.isHidden = true
        viewEvidenceButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        viewEvidenceButton.setViewsLayer(layer: viewEvidenceButton.layer, shouldLayerBorderClearColor: true)
    }
    func loadCredentialData() {
        guard let credId = credentialId else {
            return
        }
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        loadCredentialDetailsHtml(with: credId)
        
    }
    func loadCredentialDetailsHtml(with credentialId: String) {
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.credentialViewModel.fetchViewDetailsData(credentialId: credentialId, completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    if let htmlString = self?.credentialViewModel.htmlString {
                        self?.viewEvidenceButton.isHidden = false
                        self?.webView.loadHTMLString(htmlString, baseURL: nil)
                    }
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        self?.viewEvidenceButton.isHidden = true
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
            
        }
    }
    @IBAction func viewEvidenceButtonClicked(_ sender: Any) {
        let evidenceViewController = DVViewEvidenceViewContoller(nibName: "DVViewEvidenceViewContoller", bundle: DVCommon.getDVBundle())
        evidenceViewController.detailTitle = detailTitle
        evidenceViewController.credentialId = credentialId
        evidenceViewController.isFromOfficial = true
        if let htmlString = self.credentialViewModel.htmlString {
            evidenceViewController.htmlString = htmlString
        }
        self.navigationController?.pushViewController(evidenceViewController, animated: true)
        
    }
}
// MARK: - WKNavigationDelegate Methods
extension DVViewCredentialViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DVCommon.hideActivityIndicatorView()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        DVCommon.hideActivityIndicatorView()
    }
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        //for making the content to fit with the device size
        let jscript = "var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);"
        webView.evaluateJavaScript(jscript)
    }
}
