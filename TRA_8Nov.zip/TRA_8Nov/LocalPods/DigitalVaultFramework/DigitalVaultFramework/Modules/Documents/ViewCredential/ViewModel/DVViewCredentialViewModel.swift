//
//  DVCredentialViewModel.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 19/07/19.
//

import Foundation
import PromiseKit

class DVViewCredentialViewModel {
    var  htmlString: String?
}
// MARK: - Methods
extension DVViewCredentialViewModel {
    func fetchViewDetailsData(credentialId: String, completionHandler: @escaping SuccessClosure,
                              failureHandler: @escaping FailureClosure) {
        self.getViewDetails(credentialId: credentialId, completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    func getViewDetails(credentialId: String, completionHandler: @escaping SuccessClosure,
                        failureHandler: @escaping FailureClosure) {
        self.getCredentialDetails(credentialId: credentialId)
            .done({ (detailHtml) in
                let htmlData = detailHtml as? Data
                let decodedHtmlString = htmlData?.utf8String
                guard let credHtmlString = decodedHtmlString else {
                    failureHandler(false, dvDataError)
                    return
                }
                self.htmlString = credHtmlString
                completionHandler(true, "")

            })
            .catch { error in
                failureHandler(false, error) //need to change
        }
    }
    //To view credential's details html
    func getCredentialDetails(credentialId: String) -> Promise<Any> {
        return Promise {  seal in
            let  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + credentialId
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            
            headerParams[content] = ContentType.html.rawValue
            
            headerParams[authorization] = DVCommon.bearerToken
            
            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.html)
                    .done({ (decodedHtml) in
                        seal.fulfill(decodedHtml)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
}
