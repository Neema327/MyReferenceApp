//
//  DVDocumentsViewController.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 10/07/19.
//  View class for handling Requested/Uploaded documents view

import UIKit
protocol DVDocumentsDelegate: class {
    func presentmentDocAddOrReplaceSucces(with success: Bool)
}
class DVDocumentsViewController: DVBaseViewController {
    @IBOutlet weak var segmentControl: DGSegmentedControl!
    @IBOutlet weak var noDocsTitleHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var sortButton: UIButton!
    @IBOutlet weak var removeButton: UIButton!
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var outerView: UIView!
    @IBOutlet weak var innerView: UIView!
    @IBOutlet weak var addView: UIView!
    @IBOutlet weak var noDocsAvailableView: UIView!
    @IBOutlet weak var noDocsTitleLabel: UILabel!
    @IBOutlet weak var noDocsTextLabel: UILabel!
    @IBOutlet weak var docSelectionAddButton: UIButton!
    @IBOutlet weak var docSelectionCancelButton: UIButton!
    @IBOutlet weak var outerViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var searchBar: DVDocumentSearchBar!
    @IBOutlet weak var sortButtonLabel: UILabel!
    @IBOutlet weak var addButtonLabel: UILabel!
    @IBOutlet weak var downloadButtonLabel: UILabel!
    @IBOutlet weak var removeButtonLabel: UILabel!
    @IBOutlet weak var removeButtonLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var downloadButtonLeadingConstraint: NSLayoutConstraint!

    var navTitleLabel = UILabel()
    var presentmentDocDetails: [String: Any]?
    weak var delegate: DVDocumentsDelegate?
    private let window = UIApplication.shared.keyWindow
    var transparentView = UIView()
    var errorVc = DVErrorViewController()
    var docsType: DocsModelType = .official
    var docsViewType: DocumentsViewType = .normalDocSelection
    var officialDocsViewModel = DVOfficialDocsViewModel()
    var selfSignViewModel = DVSelfSignViewModel()
    var isDocumentSelectionFlow = false
    var isSelectAllMode = false
    var isNavigatedToDetailScreen = false
    var isSearchTextChanged = false
    lazy private var officialDataSource: DVOfficialDocsDataSource = {
        let officialDataSrc = DVOfficialDocsDataSource()
        return officialDataSrc
    }()
    lazy private var unOfficialdataSource: DVUnofficialDataSource = {
        let unOfficialDataSrc = DVUnofficialDataSource()
        return unOfficialDataSrc
    }()
    lazy var selectUnSelectButton: UIBarButtonItem = {
        let selectUnselctButton = UIBarButtonItem(title: Documents.selectAll,
                                                  style: UIBarButtonItem.Style.plain,
                                                  target: self, action: #selector(selectUnSelectBtnAction))
        if DVConstants.uaepassArabicLocalization {
            selectUnselctButton.setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 15.0) ?? UIFont.systemFont(ofSize: 15.0, weight: .regular)], for: .normal)
            selectUnselctButton.setTitleTextAttributes([NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 15.0) ?? UIFont.systemFont(ofSize: 15.0, weight: .regular)], for: .disabled)
        } else {
            selectUnselctButton.setTitleTextAttributes([NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15.0, weight: .regular)], for: .normal)
            selectUnselctButton.setTitleTextAttributes([NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15.0, weight: .regular)], for: .disabled)
        }
        return selectUnselctButton
    }()
    lazy var cancelButton: UIBarButtonItem = {
        let selectUnselctButton = UIBarButtonItem(title: Documents.cancelButtonTitle,
                                                  style: UIBarButtonItem.Style.plain,
                                                  target: self, action: #selector(selectCancelBtnAction))
        return selectUnselctButton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let lblFrame = CGRect(x: 70, y: 0, width: 200, height: 40)
        navTitleLabel.frame = lblFrame
        navTitleLabel.textColor = UIColor.white
        navTitleLabel.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)
        navTitleLabel.backgroundColor = UIColor.clear
        navTitleLabel.adjustsFontSizeToFitWidth = true
        navTitleLabel.minimumScaleFactor = 0.2
        navTitleLabel.textAlignment = .center
        self.navigationItem.titleView = navTitleLabel
        initializeDocSelectionDetails()
        applyNavBarStyle()
        configureBaseListView()
        configureLocalizationFonts()
        configureViewAsPerNavigation()
        searchBar.throttlingInterval = 0.1
        searchBar.setPlaceholder(textColor: .white)
        //Handle search by applying throttle
        searchBar.onSearch = { searchText in
            self.officialDocsViewModel.searchActive = true
            self.selfSignViewModel.searchActive = true
            if !self.isDocumentSelectionFlow {
                self.selectCancelBtnAction(sender: nil)
            }
            if searchText.count == 0 {
                DispatchQueue.main.async {
                    self.searchBar.resignFirstResponder()
                    self.officialDocsViewModel.searchActive = false
                    self.selfSignViewModel.searchActive = false
                    self.isSearchTextChanged = true
                    self.resetPaginationDetailsAndLoadDataForSearch(with: DVConstants.Strings.emptyString )
                }
            } else if searchText.count > 2 {
                self.officialDocsViewModel.searchText = searchText
                self.selfSignViewModel.searchText = searchText
                self.isSearchTextChanged = true
                self.resetPaginationDetailsAndLoadDataForSearch(with: searchText )
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if isDocumentSelectionFlow {
            navTitleLabel.text = Documents.docsTile
        } else {
             if DVConstants.uaepassArabicLocalization {
                 navTitleLabel.attributedText = prepareScreenTitleArabic()
             } else {
                navTitleLabel.text = prepareScreenTitle()
             }
        }
        //not refreshing the list incase its navigated to detail screen
        if !isNavigatedToDetailScreen {
            resetSelectedSegmentIndex() //setting the selected segment index
            self.segmentValueChanged(self.segmentControl)
        } else {
            isNavigatedToDetailScreen = false
        }
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationItem.hidesBackButton =  DVConstants.enableBackButton //Sai: Comment this code if back button is required in this view
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}

// MARK: - IBAction Methods
extension DVDocumentsViewController {
    //selecting Requested/Uploaded, cancelling the previous selectall action in the
    //previously selected segment and loading the appropriate data as per the selected index
    @IBAction func segmentValueChanged(_ sender: AnyObject) {
        if isSelectAllMode {
            isSelectAllMode = false
        }
        self.selectCancelBtnAction(sender: cancelButton)
        if !isSelectAllMode {
            if let senderObj = sender as? DGSegmentedControl {
                self.removeButton.isHidden = true
                self.downloadButton.isHidden = true
                self.removeButtonLabel.isHidden = true
                self.downloadButtonLabel.isHidden = true
                if senderObj.selectedIndex == 0 && (docsViewType == .normalDocSelection || docsViewType == .onlyOfficialDocsSelection) {
                    docsType = .official
                    self.officialDocsViewModel.sortActive = false
                } else if senderObj.selectedIndex == 1 && (docsViewType == .arabicLangDocSelection) {
                    docsType = .official
                    self.officialDocsViewModel.sortActive = false
                } else {
                    docsType = .unOfficial
                    self.selfSignViewModel.sortActive = false
                }
                officialDocsViewModel.searchText = DVConstants.Strings.emptyString
                selfSignViewModel.searchText = DVConstants.Strings.emptyString
                officialDocsViewModel.searchActive = false
                selfSignViewModel.searchActive = false
                DVConstants.docsSearchMode = .none
                searchBar.text = DVConstants.Strings.emptyString
                if searchBar.isFirstResponder {
                    searchBar.resignFirstResponder()
                }
                resetPaginationDetailsAndLoadData()
            }
        }
    }
    //displaying the sort options on clicking the Sort icon
    @IBAction func displaySortOptions(_ sender: Any) {
        
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        
        if !self.isDocumentSelectionFlow {
            self.selectCancelBtnAction(sender: nil)
        }
        transparentView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x000000).withAlphaComponent(0.30)
        transparentView.frame = (window?.rootViewController?.view.bounds)!
        transparentView.tag = DVConstants.transperentViewTag
        window?.addSubview(transparentView)
        addGestureToSortView()
        
        if let dvBundle = DVCommon.getDVBundle() {
            guard let sortVw = dvBundle.loadNibNamed("DVSortView", owner: self, options: nil)?[0] as? DVSortView else {
                return
            }
            sortVw.delegate = self
            sortVw.categoryList = [Documents.nameSort, Documents.dateSort]
            if let windowVw = window?.rootViewController?.view {
                sortVw.configureSortView(windowFrame: windowVw)
            }
            sortVw.tag = DVConstants.sortViewTag
            window?.addSubview(sortVw)
        }
        self.searchBar.searchBarWithColor(color: .white)
    }
    //Add button action - Add Request flow in case of Requested and Sign flow in case of Uploaded
    @IBAction func addButtonAction(_ sender: Any) {
        
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        
        if docsType == .official {
            let issuerListViewController = DVIssuersListViewController(nibName: "DVIssuersListViewController", bundle: DVCommon.getDVBundle())
            issuerListViewController.isFromHome = false
            self.navigationController?.pushViewController(issuerListViewController, animated: true)
        } else {
            DVCommon.isSignFlowFromDocuments = true
            DVEventHandler.sharedInstance.launchSignScreen()
        }
    }
    //Displaying the confirmation message for documents removal
    @IBAction func removeButtonAction(_ sender: Any) {
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        
        var selectedCount = 0
        (docsType == .official) ? (selectedCount = self.officialDocsViewModel.getSelectedOfficialCredentialCount()) : (selectedCount = self.selfSignViewModel.getSelectedUnOfficialCredentialCount())
        
        errorVc = DVErrorViewController(nibName: "DVErrorViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
        errorVc.loadView()
        errorVc.updateUI(with: (selectedCount == 1) ? (Documents.singleDocsRemoveError) : (Documents.multipleDocsRemoveError), image: nil, retryNeeded: false, cancelNeeded: true, okHandler: { [weak self] in
            self?.selectDocsForRemoval()
            }, retryHandler: { [weak self] in
                self?.removeErrorView()
        })
        errorVc.view.frame = (window?.rootViewController?.view.bounds)!
        errorVc.view.tag = DVConstants.transperentViewTag
        window?.rootViewController?.addChild(errorVc)
        window?.addSubview(errorVc.view)
    }
    //downloading the doc if only one doc selected, else displaying warning message for multiple docs download
    @IBAction func downloadButtonAction(_ sender: Any) {
        
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        
        if selfSignViewModel.getSelectedUnOfficialCredentialCount() == 1 {
            downloadButton.isEnabled = false
            downloadEvidenceData(needToWrite: true)
        } else {
            errorVc = DVErrorViewController(nibName: "DVErrorViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
            
            errorVc.loadView()
            errorVc.updateUI(with: Documents.downloadErrorAlert, image: nil, retryNeeded: false, cancelNeeded: false, okHandler: { [weak self] in
                self?.removeErrorView()
                }, retryHandler: {
            })
            errorVc.view.frame = (window?.rootViewController?.view.bounds)!
            errorVc.view.tag = DVConstants.transperentViewTag
            window?.rootViewController?.addChild(errorVc)
            window?.addSubview(errorVc.view)
        }
    }
    //Document selection cancel action in presentment flow
    @IBAction func cancelBtnTapped(_ sender: Any) {
        self.delegate?.presentmentDocAddOrReplaceSucces(with: false)
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    //unselecting the selected docs and updating the ui accordingly on cancel button click
    @IBAction func selectCancelBtnAction(sender: UIBarButtonItem?) {
        isSelectAllMode = false
        selectOrUnselectDocumentObjects(select: false)
        updateUIForCancelAction()
        refreshTableView()
    }
    
    //selectall/unselect button action
    @IBAction func selectUnSelectBtnAction(sender: UIBarButtonItem) {
        
        if searchBar.isFirstResponder {
            searchBar.resignFirstResponder()
        }
        
        setLeftBarButton(with: sender.title == Documents.selectAll ? nil : nil, hidesBackButton: sender.title == Documents.selectAll ? true : DVConstants.uaepassIntegerationEnabled)
        //select or unselect the docs depending on the button title
        selectOrUnselectDocumentObjects(select: sender.title == Documents.selectAll ? true : false)
        changeToSelectedMode(with: sender.title == Documents.selectAll ? true : false)
        
        self.removeButton.isHidden = sender.title == Documents.selectAll ? false : true
        self.removeButtonLabel.isHidden = sender.title == Documents.selectAll ? false : true
        
        downloadButton.isHidden = (docsType == .official || selfSignViewModel.getSelectedUnOfficialCredentialCount() > 1) ? true : (sender.title == Documents.selectAll ? false : true)
        downloadButtonLabel.isHidden = (docsType == .official || selfSignViewModel.getSelectedUnOfficialCredentialCount() > 1) ? true : (sender.title == Documents.selectAll ? false : true)
        
        sender.title = (sender.title == Documents.selectAll ? Documents.unselectButtonTitle : Documents.selectAll)
        if sender.title == Documents.selectAll {
            enableOrDisableAddButton(isEnable: true)
        } else {
            enableOrDisableAddButton(isEnable: false)
        }
        refreshTableView()
    }
    //handling Document selection in Presentment flow
    @IBAction func docSelectionAddButtonction(_ sender: Any) {
        var anyDocSelected = false
        switch docsType {
        case .official:
            anyDocSelected = officialDocsViewModel.anyDocSelected()
        case .unOfficial:
            anyDocSelected = selfSignViewModel.anyDocSelected()
        }
        if !anyDocSelected {
            self.displayDocSelectionMessage()
        } else {
            submitAddOrReplaceDocumentForPresentment()
        }
    }
}
// MARK: - Private Methods
extension DVDocumentsViewController {
    /// Scroll to top in table view
    private func scrollToTopIfNeeded() {
        var needToScrollToTop = false
        switch docsType {
        case .official:
        if officialDocsViewModel.currentPageNo == 0 {
            if let numOfRows = self.officialDocsViewModel.officialDocs?.count {
                if numOfRows > 0 {
                    needToScrollToTop = true
                }
            }
        }
        case .unOfficial:
            if self.selfSignViewModel.currentPageNo == 0 {
                if let numOfRows = self.selfSignViewModel.unOfficialDocsList?.count {
                    if numOfRows > 0 {
                       needToScrollToTop = true
                    }
                }
            }
        }
        if needToScrollToTop {
            let indexPath = IndexPath(row: 0, section: 0)
            self.view.layoutIfNeeded()
            self.tableView?.scrollToRow(at: indexPath, at: .top, animated: true)
        }
    }
    //initializing the docsViewType depending on Documents flow or Document selection flow, also depending on Arabic or English 
    private func initializeDocSelectionDetails() {
        if isDocumentSelectionFlow {
            if let presentmentDetails = presentmentDocDetails {
                if let isSelfSignedAccepted = presentmentDetails[DVConstants.selfSignAcceptKey] as? Bool {
                    if isSelfSignedAccepted {
                        if DVConstants.uaepassArabicLocalization {
                            docsViewType = .arabicLangDocSelection
                        } else {
                            docsViewType = .normalDocSelection
                        }
                    } else {
                        docsViewType = .onlyOfficialDocsSelection
                    }
                }
            }
        } else {
            if DVConstants.uaepassArabicLocalization {
                docsViewType = .arabicLangDocSelection
            } else {
                docsViewType = .normalDocSelection
            }
        }
    }
    private func enableOrDisableAddButton(isEnable: Bool) {
        addButton.isEnabled = isEnable
        addButton.alpha = (isEnable == true) ? 1.0 : 0.5
        addButtonLabel.alpha = (isEnable == true) ? 1.0 : 0.5
    }
    private func addGestureToSortView() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        transparentView.addGestureRecognizer(tap)
    }
    private func removeErrorView() {
        window?.viewWithTag(DVConstants.transperentViewTag)?.removeFromSuperview()
        errorVc.removeFromParent()
    }
    //removing the selected Requested/Uploaded docs
    private func selectDocsForRemoval() {
        switch docsType {
        case .official:
            removeOfficialDocs()
        case .unOfficial:
            removeUnOfficialDocs()
        }
    }
    @objc func handleTap() {
        self.officialDocsViewModel.sortActive = false
        self.selfSignViewModel.sortActive = false
        self.window?.viewWithTag(DVConstants.transperentViewTag)?.removeFromSuperview()
        self.window?.viewWithTag(DVConstants.sortViewTag)?.removeFromSuperview()
    }
    //handling add/replace document in presentment flow
    private func submitAddOrReplaceDocumentForPresentment() {
        switch docsType {
        case .official:
            submitAddOrReplaceOfficialDocumentForPresentment()
        case .unOfficial:
            submitAddOrReplaceUnOfficialDocumentForPresentment()
        }
    }
    // add/replace Requested document in presentment flow
    private func submitAddOrReplaceOfficialDocumentForPresentment() {
        guard let presentmentDetails = self.presentmentDocDetails else {
            return
        }
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        officialDocsViewModel.presentmentDocDetails = presentmentDetails
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.officialDocsViewModel.submitAddOrReplaceOfficialDocForPresentment(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    self?.delegate?.presentmentDocAddOrReplaceSucces(with: true)
                    self?.navigationController?.dismiss(animated: true, completion: nil)
                }
                }, failureHandler: { (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    // add/replace Uploaded document in presentment flow
    private func submitAddOrReplaceUnOfficialDocumentForPresentment() {
        //self.navigationController?.popViewController(animated: true)
        guard let presentmentDetails = self.presentmentDocDetails else {
            return
        }
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        selfSignViewModel.presentmentDocDetails = presentmentDetails
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.selfSignViewModel.submitAddOrReplaceUnOfficialDocForPresentment(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    self?.delegate?.presentmentDocAddOrReplaceSucces(with: true)
                    self?.navigationController?.dismiss(animated: true, completion: nil)
                }
                }, failureHandler: { (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    private func displayDownloadAlert() {
        let alertVC = UIAlertController(title: "", message: Documents.downloadSuccessMessage, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(
            title: Success.okButtonTitle,
            style: .default, handler: { _ in
                self.selectCancelBtnAction(sender: self.cancelButton)
        }))
        self.present(alertVC, animated: true, completion: nil)
    }
    private func applyNavBarStyle () {
        let topHeaderBGImg = DVCommon.getImage(named: "top-header-bg.png")
        self.navigationController?.navigationBar.tintColor = .white
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(topHeaderBGImg.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        self.navigationController?.navigationBar.isTranslucent = false
    }
    //fetching the Requested docs data from server and refreshing the tableview
    private func loadOffcialDocsData() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        officialDocsViewModel.isSelectAllMode = isSelectAllMode
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.officialDocsViewModel.fetchOfficialDocsData(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    if let docSelMode = self?.isDocumentSelectionFlow {
                        if !docSelMode {
                            if DVConstants.uaepassArabicLocalization {
                                self?.navTitleLabel.attributedText = self?.prepareScreenTitleArabic()
                            } else {
                                self?.navTitleLabel.text = self?.prepareScreenTitle()
                            }
                        }
                    }
                    self?.refreshTableView()
                    self?.scrollToTopIfNeeded()
                    self?.displayOrHideNoDocsAvailableView()
                    DVEventHandler.sharedInstance.getNotificationCount()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        self?.refreshTableView()
                        self?.displayOrHideNoDocsAvailableView()
                        DVEventHandler.sharedInstance.getNotificationCount()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    //fetching the requested docs data from server and refreshing the tableview for auto search
    private func loadOffcialDocsSearchData(searchText: String) {
        officialDocsViewModel.isSelectAllMode = isSelectAllMode
        let docsSearchViewModel = DVOfficialDocsViewModel()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            docsSearchViewModel.currentPageNo =  0
            docsSearchViewModel.maxPageNo =  1
            docsSearchViewModel.searchText = searchText
            docsSearchViewModel.searchActive = true
            docsSearchViewModel.fetchOfficialDocsSearchData(completionHandler: { [weak self] (_, _) in
                self?.officialDocsViewModel.currentPageNo = docsSearchViewModel.currentPageNo
                self?.officialDocsViewModel.maxPageNo = docsSearchViewModel.maxPageNo
                self?.officialDocsViewModel.officialDocs = docsSearchViewModel.officialDocs
                DispatchQueue.main.async {
                    let lock = NSLock()
                    lock.lock()
                    self?.isSearchTextChanged  = false
                    DVCommon.hideActivityIndicatorView()
                    self?.refreshTableView()
                    self?.scrollToTopIfNeeded()
                    self?.displayOrHideNoDocsAvailableView()
                   lock.unlock()
                }
                }, failureHandler: {[weak self] (_, error) in
                    self?.officialDocsViewModel.currentPageNo = docsSearchViewModel.currentPageNo
                    self?.officialDocsViewModel.maxPageNo = docsSearchViewModel.maxPageNo
                    self?.officialDocsViewModel.officialDocs = docsSearchViewModel.officialDocs
                    DispatchQueue.main.async {
                        let lock = NSLock()
                        lock.lock()
                        self?.isSearchTextChanged  = false
                        DVCommon.hideActivityIndicatorView()
                        self?.refreshTableView()
                        self?.displayOrHideNoDocsAvailableView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                        lock.unlock()
                    }
            })
        }
    }
    //fetching the Uploaded docs data from server and refreshing the tableview/displaying alert
    private func loadUnofficialDocs() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        selfSignViewModel.isSelectAllMode = isSelectAllMode
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.selfSignViewModel.fetchUnOfficialDocsData(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    if let docSelMode = self?.isDocumentSelectionFlow {
                        if !docSelMode {
                            if DVConstants.uaepassArabicLocalization {
                                self?.navTitleLabel.attributedText = self?.prepareScreenTitleArabic()
                            } else {
                                self?.navTitleLabel.text = self?.prepareScreenTitle()
                            }
                        }
                    }
                    self?.refreshTableView()
                    self?.scrollToTopIfNeeded()
                    self?.displayOrHideNoDocsAvailableView()
                    DVEventHandler.sharedInstance.getNotificationCount()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        self?.refreshTableView()
                        self?.displayOrHideNoDocsAvailableView()
                        DVEventHandler.sharedInstance.getNotificationCount()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    //fetching the Uploaded docs data from server and refreshing the tableview for auto search
    private func loadUnOffcialDocsSearchData(searchText: String) {
        selfSignViewModel.isSelectAllMode = isSelectAllMode
        let docsSearchViewModel = DVSelfSignViewModel()
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            docsSearchViewModel.currentPageNo =  0
            docsSearchViewModel.maxPageNo =  1
            docsSearchViewModel.searchText = searchText
            docsSearchViewModel.searchActive = true
            docsSearchViewModel.fetchUnOfficialDocsData(completionHandler: { [weak self] (_, _) in
                self?.selfSignViewModel.currentPageNo = docsSearchViewModel.currentPageNo
                self?.selfSignViewModel.maxPageNo = docsSearchViewModel.maxPageNo
                self?.selfSignViewModel.unOfficialDocsList = docsSearchViewModel.unOfficialDocsList
                DispatchQueue.main.async {
                    let lock = NSLock()
                    lock.lock()
                    self?.isSearchTextChanged  = false
                    DVCommon.hideActivityIndicatorView()
                    self?.refreshTableView()
                    self?.scrollToTopIfNeeded()
                    self?.displayOrHideNoDocsAvailableView()
                    lock.unlock()
                }
                }, failureHandler: { [weak self] (_, error) in
                    self?.selfSignViewModel.currentPageNo = docsSearchViewModel.currentPageNo
                    self?.selfSignViewModel.maxPageNo = docsSearchViewModel.maxPageNo
                    self?.selfSignViewModel.unOfficialDocsList = docsSearchViewModel.unOfficialDocsList
                    DispatchQueue.main.async {
                        let lock = NSLock()
                        lock.lock()
                        self?.isSearchTextChanged  = false
                        DVCommon.hideActivityIndicatorView()
                        self?.refreshTableView()
                        self?.displayOrHideNoDocsAvailableView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                        lock.unlock()
                    }
            })
        }
    }
    //removing the Requsted docs data from server and navigating to success screen/displaying alert
    private func removeOfficialDocs() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.officialDocsViewModel.removeOfficialDocs(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    self?.navigateToSuccessScreen()
                    self?.removeErrorView()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        self?.removeErrorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    //removing the Uploaded docs data from server and navigating to success screen/displaying alert
    private func removeUnOfficialDocs() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.selfSignViewModel.removeUnOfficialDocs(completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    self?.removeErrorView()
                    self?.navigateToSuccessScreen()
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        self?.removeErrorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })
        }
    }
    //downloading the Uploaded document 
    private func downloadEvidenceData(needToWrite: Bool) {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.downloadMessage)
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.selfSignViewModel.fetchEvidenceData(needToWrite: needToWrite, completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    self?.storeToFiles()
                    self?.downloadButton.isEnabled = true
                }
                }, failureHandler: { [weak self] (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                        self?.downloadButton.isEnabled = true
                    }
            })
        }
    }
    private func storeToFiles() {
        guard let documentLocation = selfSignViewModel.documentLocation else { return }
        let fileUrl = URL(fileURLWithPath: documentLocation)
        let documentPicker = UIDocumentPickerViewController(url: fileUrl, in: .exportToService)
        documentPicker.delegate = self
        present(documentPicker, animated: true)
    }
    
    //navigating to success screen in case of docs removal success
    private func navigateToSuccessScreen() {
        let successNotificationViewController = DVNotifiedViewController(nibName: "DVNotifiedViewController", bundle: Bundle.createBundle("DigitalVaultFramework"))
        if let alerMessage = prepareTheMessageForRemovalSuccess(), let succesImageName = getSuccessImageImageName() {
            successNotificationViewController.alertText = alerMessage
            successNotificationViewController.loadView()
            let notifiedImage = DVCommon.getImage(named: succesImageName)
            successNotificationViewController.updateNotifiedUI(title: "", subTitle: Documents.removeDocsTitle, alertTitle: alerMessage, image: notifiedImage)
        }
        self.navigationController?.pushViewController(successNotificationViewController, animated: true)
    }
    //getting the document removal success image name
    private func getSuccessImageImageName() -> String? {
        var imageName: String?
        switch docsType {
        case .official:
            imageName =  officialDocsViewModel.prepareSuccessImageName()
        case .unOfficial:
            imageName =  selfSignViewModel.prepareSuccessImageName()
        }
        return imageName
    }
    //preparing the document removal success message
    private func prepareTheMessageForRemovalSuccess() -> String? {
        var alertTitle: String?
        switch docsType {
        case .official:
            alertTitle =  officialDocsViewModel.prepareTheAlertTitle()
        case .unOfficial:
            alertTitle =  selfSignViewModel.prepareTheAlertTitle()
        }
        return alertTitle
    }
    //setting the sort option as per the doc type selected, resetting
    //the pagination details accordinly and loading the data
    private func performSortAction(sortOrder: SortOrders) {
        switch docsType {
        case .official:
            self.officialDocsViewModel.sortActive = true
            self.officialDocsViewModel.sortOrder = sortOrder
        case .unOfficial:
            self.selfSignViewModel.sortActive = true
            self.selfSignViewModel.sortOrder = sortOrder
        }
        resetPaginationDetailsAndLoadData()
    }
    //Configuring all subviews and tableview
    private func configureBaseListView() {
        (isDocumentSelectionFlow == true) ? (outerViewBottomConstraint.constant = addView.frame.size.height - 5) : (outerViewBottomConstraint.constant = 0.0)
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        docSelectionAddButton.setViewsLayer(layer: docSelectionAddButton.layer, shouldLayerBorderClearColor: true)
        configureSegmentControl()
        
        UITableView.registerCellWithIdentifier(cellIdentifier: DVOfficialDocTableViewCell.identifier, tblVw: tableView)
        tableView.estimatedRowHeight = 120
        tableView.separatorColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
        tableView.tableFooterView = UIView()
        
        let rightBarButton = selectUnSelectButton
        self.navigationItem.rightBarButtonItem = rightBarButton
        
        removeButton.isHidden = true
        downloadButton.isHidden = true
        removeButtonLabel.isHidden = true
        downloadButtonLabel.isHidden = true
        
        removeButtonLabel.text = Documents.remove
        downloadButtonLabel.text = Documents.download
        addButtonLabel.text = Documents.add
        sortButtonLabel.text = Documents.sort

        outerView.setUpRoundedCornerView(view: outerView)
        innerView.setUpRoundedCornerView(view: innerView)
        
        searchBar.placeholder = Documents.search
        searchBar.searchBarWithColor(color: .white)
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18.0, weight: .regular)]
        
    }
    //if selectall/unselect clicked, setting the isSelectAllMode and
    //setting the title accordingly
    private func changeToSelectedMode(with selectedAllMode: Bool) {
        isSelectAllMode = selectedAllMode
        if DVConstants.uaepassArabicLocalization {
               self.navTitleLabel.attributedText = prepareScreenTitleArabic()
        } else {
            self.navTitleLabel.text = prepareScreenTitle()
        }
    }
    private func prepareScreenTitle() -> String {
        var selectedCount = 0
        var titleString = Documents.docsTile
        (docsType == .official) ? (selectedCount = self.officialDocsViewModel.getSelectedOfficialCredentialCount()) : (selectedCount = self.selfSignViewModel.getSelectedUnOfficialCredentialCount())
        if selectedCount > 0 {
            switch docsType {
            case .official:
                titleString = officialDocsViewModel.prepareNoOfDocsSelectedTitle() ?? ""
            case .unOfficial:
                titleString = selfSignViewModel.prepareNoOfDocsSelectedTitle() ?? ""
            }
        }
        return titleString
    }

    private func prepareScreenTitleArabic() -> NSAttributedString {
        var selectedCount = 0
        var titleString = NSAttributedString(string: Documents.docTile, attributes:[
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 18) ?? UIFont.systemFont(ofSize: 18.0, weight: .regular)])
        (docsType == .official) ? (selectedCount = self.officialDocsViewModel.getSelectedOfficialCredentialCount()) : (selectedCount = self.selfSignViewModel.getSelectedUnOfficialCredentialCount())
        if selectedCount > 0 {
            switch docsType {
            case .official:
                if let docTitleArabic = officialDocsViewModel.prepareNoOfDocsSelectedTitleArabic() {
                    titleString = docTitleArabic
                }
            case .unOfficial:
                 if let docTitleArabic = selfSignViewModel.prepareNoOfDocsSelectedTitleArabic() {
                    titleString = docTitleArabic
                 }
            }
        }
        return titleString
    }
    //selecting or unselecting the docs on selectall/unselect button click
    private func selectOrUnselectDocumentObjects(select: Bool) {
        switch docsType {
        case .official:
            officialDocsViewModel.selectOrUnselectAllDocs(select: select)
        case .unOfficial:
            selfSignViewModel.selectOrUnselectAllDocs(select: select)
        }
    }
    // MARK: - Segment control
    private func configureSegmentControl() {
        if docsViewType == .arabicLangDocSelection {
            segmentControl.items = [Documents.selfSignedSegmentTitle, Documents.officialSegmentTitle]
        } else if docsViewType == .onlyOfficialDocsSelection {
            segmentControl.items = [Documents.officialSegmentTitle]
        } else {
            segmentControl.items = [Documents.officialSegmentTitle, Documents.selfSignedSegmentTitle]
        }
        segmentControl.font = UIFont.systemFont(ofSize: 18.0, weight: .regular)
        segmentControl.borderSize = 1
        segmentControl.tabBorderColor = UIColor.colorFromHex(rgbValue: 0x455B63).withAlphaComponent(0.12)
        segmentControl.tabSeparationColor = UIColor.colorFromHex(rgbValue: 0x455B63).withAlphaComponent(0.12)
        segmentControl.thumbColor = UIColor.colorFromHex(rgbValue: 0xEB6D72)
        segmentControl.selectedLabelColor = UIColor.colorFromHex(rgbValue: 0xEB6D72)
        segmentControl.unselectedLabelColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        segmentControl.thumUnderLineSize = 2
    }
    private func configureLocalizationFonts() {
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
            segmentControl.font = UIFont(name: ArabicFont.regular.rawValue, size: 18)
            sortButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 12.0)
            removeButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 13.0)
            addButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 12.0)
            downloadButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 12.0)
            removeButtonLeadingConstraint.constant = 28.0
            downloadButtonLeadingConstraint.constant = 98.0
            
        }
    }
    //refreshing the tableview withthe updated data
    private func refreshTableView() {
        switch docsType {
        case .official:
            self.officialDataSource.officialDocsViewModel = self.officialDocsViewModel
            self.officialDataSource.isDocumentSelectionFlow = self.isDocumentSelectionFlow
            self.officialDataSource.tableView = self.tableView
            self.officialDataSource.delegate = self
            self.tableView.delegate = self.officialDataSource
            self.tableView.dataSource = self.officialDataSource
        case .unOfficial:
            self.unOfficialdataSource.selfSignViewModel =  self.selfSignViewModel
            self.unOfficialdataSource.isDocumentSelectionFlow = self.isDocumentSelectionFlow
            self.unOfficialdataSource.tableView = self.tableView
            self.unOfficialdataSource.delegate = self
            self.tableView.delegate = self.unOfficialdataSource
            self.tableView.dataSource = self.unOfficialdataSource
        }
        self.tableView.reloadData()
    }
    
    //resetting the pagination details and loading the data
    private func resetPaginationDetailsAndLoadData() {
        switch docsType {
        case .official:
            officialDocsViewModel.resetPaginationDetails()
            loadOffcialDocsData()
        case .unOfficial:
            selfSignViewModel.resetPaginationDetails()
            loadUnofficialDocs()
        }
    }
    //resetting the pagination details and loading the data
    private func resetPaginationDetailsAndLoadDataForSearch(with searchText: String) {
        switch docsType {
        case .official:
            officialDocsViewModel.resetPaginationDetails()
            loadOffcialDocsSearchData(searchText: searchText)
        case .unOfficial:
            selfSignViewModel.resetPaginationDetails()
            loadUnOffcialDocsSearchData(searchText: searchText)
        }
    }
    private func updateUIForCancelAction() {
        selectUnSelectButton.title = Documents.selectAll
        navTitleLabel.text = Documents.docsTile
        setLeftBarButton(with: nil, hidesBackButton: DVConstants.uaepassIntegerationEnabled)
        self.removeButton.isHidden = true
        self.downloadButton.isHidden = true
        self.removeButtonLabel.isHidden = true
        self.downloadButtonLabel.isHidden = true
        enableOrDisableAddButton(isEnable: true)
    }
    
    private func setLeftBarButton(with barButton: UIBarButtonItem?, hidesBackButton: Bool ) {
        self.navigationItem.setHidesBackButton(DVConstants.enableBackButton, animated: true)
        if let button = barButton {
            self.navigationItem.leftBarButtonItem = button
        } else {
            self.navigationItem.leftBarButtonItem = nil
        }
    }
    //setting the segment selected as per the doc type selection
    private func resetSelectedSegmentIndex() {
        switch docsType {
        case .official:
            segmentControl.selectedIndex = (docsViewType == .normalDocSelection || docsViewType == .onlyOfficialDocsSelection) ? 0: 1
        case .unOfficial:
            segmentControl.selectedIndex = (docsViewType == .normalDocSelection) ? 1 : 0
        }
    }
    private func configureViewAsPerNavigation() {
        if !isDocumentSelectionFlow {
            addView.isHidden = true
        } else {
            addView.isHidden = false
            docSelectionAddButton.setTitle(Documents.add, for: .normal)
            docSelectionCancelButton.setTitle(Documents.cancelButtonTitle, for: .normal)
            disableDocSelectionAddButton()
            removeButton.isHidden = true
            downloadButton.isHidden = true
            addButton.isHidden = true
            removeButtonLabel.isHidden = true
            downloadButtonLabel.isHidden = true
            addButtonLabel.isHidden = true
            
            self.navigationItem.rightBarButtonItem = nil
        }
    }
    private func disableDocSelectionAddButton() {
        docSelectionAddButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xB0B7C4)
        docSelectionAddButton.isEnabled = false
    }
    private func enableAllDocsCommonButtons(with enable: Bool) {
        if enable {
            var sortEnable = false
            //enabling the sort if oly if more than one doc present
            switch docsType {
            case .official:
                sortEnable = officialDocsViewModel.shouldEnableSortButton()
            case .unOfficial:
                sortEnable = selfSignViewModel.shouldEnableSortButton()
            }
            if sortEnable {
                sortButton.isEnabled = true
                sortButton.alpha = 1.0
                sortButtonLabel.alpha = 1.0
            } else {
                sortButton.isEnabled = false
                sortButton.alpha = 0.5
                sortButtonLabel.alpha = 0.5
            }
            selectUnSelectButton.isEnabled = true
        } else {
            sortButton.isEnabled = false
            self.sortButton.alpha = 0.5
            sortButtonLabel.alpha = 0.5
            selectUnSelectButton.isEnabled = false
        }
    }
    private func displayNoDocsAvailableView(with searchActive: Bool) {
        if searchActive {
            noDocsTitleLabel.isHidden = true
            noDocsTitleHeightConstraint.constant = 0.0
            noDocsTextLabel.font = UIFont.boldSystemFont(ofSize: 20)
        } else {
            noDocsTitleLabel.isHidden = false
            noDocsTitleHeightConstraint.constant = 20.0
            noDocsTextLabel.font = UIFont.systemFont(ofSize: 17)
        }
        
        if isDocumentSelectionFlow && !searchActive {
            noDocsTextLabel.isHidden = isDocumentSelectionFlow
        } else {
            noDocsTextLabel.isHidden = false
        }
        
        sortButton.isEnabled = false
        self.sortButton.alpha = 0.5
        sortButtonLabel.alpha = 0.5
        selectUnSelectButton.isEnabled = false
    }
    private func enableOrDisableDocSelectionAddButton(with tableRefreshType: TableRefreshType) {
        if isDocumentSelectionFlow {
            if tableRefreshType == .docsAvailable {
                docSelectionAddButton.isEnabled = true
                docSelectionAddButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
            } else {
                docSelectionAddButton.isEnabled = false
                docSelectionAddButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0xB0B7C4)
            }
        }
    }
    private func refreshDocsViews(with tableRefreshType: TableRefreshType) {
        if tableRefreshType == .noDocsAvailable {
            self.noDocsAvailableView.isHidden = false
        } else {
            self.noDocsAvailableView.isHidden = true
        }
        let noDocsAvlDetails = (docsType == .official) ? officialDocsViewModel.noDocsAvlDetails() : selfSignViewModel.noDocsAvlDetails()
        self.noDocsTitleLabel.text = noDocsAvlDetails.title
        self.noDocsTextLabel.text = noDocsAvlDetails.text
        
        if tableRefreshType == .noDocsAvailable {
            displayNoDocsAvailableView(with:  (docsType == .official) ? officialDocsViewModel.searchActive : selfSignViewModel.searchActive)
        } else {
            enableAllDocsCommonButtons(with: (tableRefreshType == .docsAvailable) ? true : false)
        }
        if isDocumentSelectionFlow {
            enableOrDisableDocSelectionAddButton(with: tableRefreshType)
        }
    }
    private func displayOrHideNoDocsAvailableView() {
        switch docsType {
        case .official:
            refreshDocsViews(with: officialDocsViewModel.displayNoDocsAvailableView())
        case .unOfficial:
            refreshDocsViews(with: selfSignViewModel.displayNoDocsAvailableView())
        }
    }
    private func displayDocSelectionMessage() {
        let alertVC = UIAlertController(title: "", message: Documents.documentSelectMessage, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(
            title: Success.okButtonTitle,
            style: .default, handler: { _ in
                self.searchBar.searchBarWithColor(color: .white)
        }))
        self.present(alertVC, animated: true, completion: nil)
    }
}
// MARK: - DVSortViewDelegate Methods
extension DVDocumentsViewController: DVSortViewDelegate {
    func displaySortDetailView(categoryStr: String) {
        
        if categoryStr == Documents.nameSort {
            self.performSortAction(sortOrder: .name)
        } else if categoryStr == Documents.dateSort {
            self.performSortAction(sortOrder: .date)
        }
        self.window?.viewWithTag(DVConstants.transperentViewTag)?.removeFromSuperview()
        self.window?.viewWithTag(DVConstants.sortViewTag)?.removeFromSuperview()
    }
    func cancelAction() {
        self.officialDocsViewModel.sortActive = false
        self.selfSignViewModel.sortActive = false
        self.window?.viewWithTag(DVConstants.transperentViewTag)?.removeFromSuperview()
        self.window?.viewWithTag(DVConstants.sortViewTag)?.removeFromSuperview()
    }
}
// MARK: - DVOfficialDocsDataSourceDelegate methods
extension DVDocumentsViewController: DVOfficialDocsDataSourceDelegate {
    func checkWhetherFetchFromServerIsRequired(indexPath: IndexPath) {
        guard let officialDocs = officialDocsViewModel.officialDocs else {
            return
        }
        
        if DVConstants.docsSearchMode == .pagination {
            if indexPath.row == officialDocs.count - 1 {
                if officialDocsViewModel.currentPageNo < officialDocsViewModel.maxPageNo {
                    officialDocsViewModel.currentPageNo = officialDocsViewModel.currentPageNo + 1
                    loadOffcialDocsData()
                }
            }
        }
    }
    
    func displayDocumentDetailView(indexPath: IndexPath) {
        guard let officialDocs = officialDocsViewModel.officialDocs else {
            return
        }
        let officialDoc = officialDocs[indexPath.row]
        let credentialViewController = DVViewCredentialViewController(nibName: "DVViewCredentialViewController", bundle: DVCommon.getDVBundle())
        credentialViewController.detailTitle = officialDoc.docName ?? ""
        credentialViewController.credentialId = officialDoc.id
        isNavigatedToDetailScreen = true
        self.navigationController?.pushViewController(credentialViewController, animated: true)
    }
    func displayOrHideRemoveButton(display: Bool, addButtonEnabled: Bool, isAllDocsSelected: Bool) {
        self.removeButton.isHidden = !display
        self.downloadButton.isHidden = true
        self.removeButtonLabel.isHidden = !display
        self.downloadButtonLabel.isHidden = true
        if display {
            enableOrDisableAddButton(isEnable: addButtonEnabled)
        } else {
            enableOrDisableAddButton(isEnable: true)
        }
        selectUnSelectButton.title = (isAllDocsSelected == true) ? Documents.unselectButtonTitle : Documents.selectAll
        isSelectAllMode = (isAllDocsSelected == true) ? true : false
        if display {
            if DVConstants.uaepassArabicLocalization {
                self.navTitleLabel.attributedText = prepareScreenTitleArabic()
            } else {
                self.navTitleLabel.text = prepareScreenTitle()
            }
        } else {
            navTitleLabel.text = Documents.docsTile
        }
    }
    func tableRefreshRequired() {
        DispatchQueue.main.async {
            self.refreshTableView()
        }
    }
}
// MARK: - DVUnOfficialDocsDataSourceDelegate methods
extension DVDocumentsViewController: DVUnOfficialDocsDataSourceDelegate {
    func checkWhetherFetchFromServerIsRequiredForUnOfficial(indexPath: IndexPath) {
        guard let unOfficialDocs = self.selfSignViewModel.unOfficialDocsList else {
            return
        }
        if DVConstants.docsSearchMode == .pagination {
            if indexPath.row == unOfficialDocs.count - 1 {
                if selfSignViewModel.currentPageNo < selfSignViewModel.maxPageNo {
                    selfSignViewModel.currentPageNo = selfSignViewModel.currentPageNo + 1
                    loadUnofficialDocs()
                }
            }
        }
    }
    func displayOrHideRemoveButtonForUnofficial(display: Bool, addButtonEnabled: Bool, isAllDocsSelected: Bool) {
        if selfSignViewModel.getSelectedUnOfficialCredentialCount() > 1 {
            self.downloadButton.isHidden = true
            self.downloadButtonLabel.isHidden = true
        } else {
            self.downloadButton.isHidden = !display
            self.downloadButtonLabel.isHidden = !display
        }
        self.removeButton.isHidden = !display
        self.removeButtonLabel.isHidden = !display
        
        if display {
            enableOrDisableAddButton(isEnable: addButtonEnabled)
        } else {
            enableOrDisableAddButton(isEnable: true)
        }
        selectUnSelectButton.title = (isAllDocsSelected == true) ? Documents.unselectButtonTitle : Documents.selectAll
        isSelectAllMode = (isAllDocsSelected == true) ? true : false
        if display {
            if DVConstants.uaepassArabicLocalization {
                self.navTitleLabel.attributedText = prepareScreenTitleArabic()
            } else {
                self.navTitleLabel.text = prepareScreenTitle()
            }
        } else {
            navTitleLabel.text = Documents.docsTile
        }
    }
    func displayDocumentDetailViewForUnOfficial(indexPath: IndexPath) {
        guard let unOfficialDocs = selfSignViewModel.unOfficialDocsList else {
            return
        }
        let unOfficialDoc = unOfficialDocs[indexPath.row]
        let detailedViewController = DVViewEvidenceViewContoller(nibName: "DVViewEvidenceViewContoller", bundle: DVCommon.getDVBundle())
        detailedViewController.detailTitle = unOfficialDoc.docName ?? ""
        detailedViewController.credentialId = unOfficialDoc.id
        detailedViewController.credentialName = unOfficialDoc.docName
        isNavigatedToDetailScreen = true
        detailedViewController.isFromOfficial = false
        detailedViewController.isFromNotificationFlow = isDocumentSelectionFlow
        self.navigationController?.pushViewController(detailedViewController, animated: true)
    }
    func tableRefreshRequiredForUnOfficial() {
        DispatchQueue.main.async {
            self.refreshTableView()
        }
    }
}

extension DVDocumentsViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        
    }
}

public class Throttler {
    private let queue: DispatchQueue = DispatchQueue.global(qos: .background)
    private var job: DispatchWorkItem = DispatchWorkItem(block: {})
    private var previousRun: Date = Date.distantPast
    private var maxInterval: Double
    
    init(seconds: Double) {
        self.maxInterval = seconds
    }
    
    func throttle(block: @escaping () -> ()) {
        job.cancel()
        job = DispatchWorkItem() { [weak self] in
            self?.previousRun = Date()
            block()
        }
        let delay = Double(Date.second(from: previousRun)) > maxInterval ? 0 : maxInterval
        queue.asyncAfter(deadline: .now() + Double(delay), execute: job)
    }
}

private extension Date {
    static func second(from referenceDate: Date) -> Int {
        return Int(Date().timeIntervalSince(referenceDate).rounded())
    }
}
public class DVDocumentSearchBar: DVSearchBar {
    
    public override func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        DVConstants.docsSearchMode = .none
        super.onCancel?()
    }
    
    public override func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        DVConstants.docsSearchMode = .searchButton
        searchBar.resignFirstResponder()
        super.searchBarSearchButtonClicked(searchBar)
    }
    
    public override func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        DVConstants.docsSearchMode = .searchBar
        super.searchBar(searchBar, textDidChange: searchText)
    }
}
