//
//  DVSelfSignedCredential.swift
//  DigitalVaultFramework
//

import Foundation

// MARK: - DVSelfSignedCredential
struct DVSelfSignedCredential: Codable {
    let id, docName, docMnemonic, uploadedAt, docTypeName: String?
    var isSelected = false
    enum CodingKeys: String, CodingKey {
        case id
        case docName
        case docMnemonic
        case uploadedAt
        case docTypeName
    }
}

// MARK: DVSelfSignedCredential convenience initializers and mutators

extension DVSelfSignedCredential {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVSelfSignedCredential.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: String?? = nil,
        docName: String?? = nil,
        docMnemonic: String?? = nil,
        uploadedAt: String?? = nil,
        docTypeName: String?? = nil
        ) -> DVSelfSignedCredential {
        return DVSelfSignedCredential(
            id: id ?? self.id,
            docName: docName ?? self.docName,
            docMnemonic: docMnemonic ?? self.docMnemonic,
            uploadedAt: uploadedAt ?? self.uploadedAt,
            docTypeName: docTypeName ?? self.docTypeName,
            isSelected: self.isSelected
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

typealias DVUnOfficialDocs = [DVSelfSignedCredential]

extension Array where Element == DVUnOfficialDocs.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVUnOfficialDocs.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
