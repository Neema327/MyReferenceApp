//
//  DVSelfSignViewModel.swift
//  DigitalVaultFramework
//
//  Created by MSP on 16/07/19.

import Foundation
import UIKit

import PromiseKit
class DVSelfSignViewModel {
    var searchActive: Bool = false
    var sortOrder: SortOrders = .name
    var searchText = ""
    var sortActive: Bool = false
    var currentPageNo = 0
    var isSelectAllMode = false
    var maxPageNo = 1
    var unOfficialDocsList: DVUnOfficialDocs?
    var presentmentDocDetails: [String: Any]?
    let evidenceViewModel = DVEvidenceViewModel()
    var  evidenceData: Data?
    let fileManager = DVFileManager()
    var documentLocation: String?

    init() {

    }
}
extension DVSelfSignViewModel {
    func fetchUnOfficialDocsData(completionHandler: @escaping SuccessClosure,
                                 failureHandler: @escaping FailureClosure) {
        self.getUnOfficialDocumentsList(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    func removeUnOfficialDocs(completionHandler: @escaping SuccessClosure,
                            failureHandler: @escaping FailureClosure) {
        self.removeUnOfficialDocuments(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    func submitAddOrReplaceUnOfficialDocForPresentment(completionHandler: @escaping SuccessClosure,
                                                     failureHandler: @escaping FailureClosure) {
        self.addOrReplaceDocumentForPresentment(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }

    func fetchEvidenceData(needToWrite: Bool, completionHandler: @escaping SuccessDataClosure,
                           failureHandler: @escaping FailureClosure) {
       let selectedCredentialDetails =   getSelectedCredentialDetails()
        self.fileManager.getEvidenceData(credentialId: selectedCredentialDetails.docId, credentialName: selectedCredentialDetails.docName, needToWrite: needToWrite, completionHandler: { [weak self] (_, evidenceData) in
            self?.documentLocation = self?.fileManager.documentLocation
            completionHandler(true, evidenceData)
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }

    private func addOrReplaceDocumentForPresentment(completionHandler: @escaping SuccessClosure,
                                                    failureHandler: @escaping FailureClosure) {
            self.invokeServiceForUnOfficialDocAddOrReplace()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }
    func getUnOfficialDocumentsList(completionHandler: @escaping SuccessClosure,
                                    failureHandler: @escaping FailureClosure) {
            self.invokeServiceForUnOfficialDocs()
                .done({ (unOfficialDocsList) in
                    self.maxPageNo = self.maxPageNo + 1
                    guard var newUnOfficialDocs = unOfficialDocsList as? DVUnOfficialDocs else {
                        failureHandler(false, dvDataError)
                        return
                    }
                    var updatedDocsArray = DVUnOfficialDocs()
                    if self.isSelectAllMode {
                        for doc in newUnOfficialDocs {
                            var curDoc = doc
                            curDoc.isSelected = true
                            updatedDocsArray.append(curDoc)
                        }
                        newUnOfficialDocs = updatedDocsArray
                    }
                    if self.currentPageNo != 0 {
                        if var currentUnOfficialDocsArray = self.unOfficialDocsList {
                            for doc in newUnOfficialDocs {
                                currentUnOfficialDocsArray.append(doc)
                            }

                            self.unOfficialDocsList = currentUnOfficialDocsArray
                        }
                    } else {
                        self.unOfficialDocsList = newUnOfficialDocs
                    }
                    if newUnOfficialDocs.count == 0 {
                        self.maxPageNo = self.currentPageNo
                    }
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error)
            }
    }

    func invokeServiceForUnOfficialDocs() -> Promise<Any> {
        return Promise {  seal in

            var  serviceURL: String =  baseURL + apiVersion + EndPoint.unofficialDocsDefault.rawValue + "\(currentPageNo)"
            if searchActive {
                serviceURL =   serviceURL + "&filterBy=\(searchText)"
            }
            if sortActive {
                let sortByText = sortOrder == .name ? "&sort=name,asc" : "&sort=date,desc"
                serviceURL =    serviceURL + sortByText
            } else {
                serviceURL =    serviceURL + "&sort=name,asc"
            }
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                //Decode server response
                DVCommon.decodeResponse(type: DVUnOfficialDocs.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                    .done({ (unOfficialDocsList) in
                        seal.fulfill(unOfficialDocsList)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    func removeUnOfficialDocuments(completionHandler: @escaping SuccessClosure,
                                 failureHandler: @escaping FailureClosure) {
            self.invokeServiceForUnOfficialDocsRemoval()
                .done({ (_) in
                    guard let unOffcialDocs = self.unOfficialDocsList else {
                        return
                    }
                    let selectedDocsForRemoval = unOffcialDocs.filter({ $0.isSelected == true})
                    for doc in selectedDocsForRemoval {
                        if let docId = doc.id {
                            if self.fileManager.isDocumentExistInDocumentDirectory(credentialId: docId) {
                                self.fileManager.deleteDocumentFromDirectory(credentialId: docId)
                            }
                        }
                    }
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error) //need to change
            }
    }
    func invokeServiceForUnOfficialDocsRemoval() -> Promise<Any> {
        return Promise {  seal in
        guard let unOffcialDocs = unOfficialDocsList else {
            return
        }
        let selectedDocsForRemoval = unOffcialDocs.filter({ $0.isSelected == true})
        var idsOfUnOfficialDocsToBeRemoved = ""
        for doc in selectedDocsForRemoval {
            if let docId = doc.id {
                idsOfUnOfficialDocsToBeRemoved = idsOfUnOfficialDocsToBeRemoved + docId + ","
            }
        }
        idsOfUnOfficialDocsToBeRemoved = String(idsOfUnOfficialDocsToBeRemoved.dropLast())
        let serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + idsOfUnOfficialDocsToBeRemoved + "/remove"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken
            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                (jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    private func invokeServiceForUnOfficialDocAddOrReplace() -> Promise<Any> {
        return Promise {  seal in
            guard let docs = unOfficialDocsList, let presDocDetails = presentmentDocDetails else {
                return
            }
            guard let presReqId = presDocDetails[DVConstants.requestIdKey] as? String, let requestedDocId = presDocDetails[DVConstants.documentIdKey] as? String  else {
                return
            }
            let selectedDocs = docs.filter({ $0.isSelected == true})
            var idOfSelectedDoc: String?
            for doc in selectedDocs {
                if let docId = doc.id {
                    idOfSelectedDoc = docId
                    break //only one doc can be selected for add/replace
                }
            }
            guard let selectedDocId = idOfSelectedDoc else {
                return
            }
            let serviceURL: String =  baseURL + apiVersion + EndPoint.presentmentDocAddReplace.rawValue + presReqId + "/documents/" + requestedDocId
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = ["vcid": selectedDocId] //selected doc id is passing as the vcid

            headerParams[authorization] = DVCommon.bearerToken
            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                ( jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    func selectOrUnselectAllDocs(select: Bool) {
        guard let unoffcialDocs = unOfficialDocsList else {
            return
        }
        var updatedUnOfficialDocs = DVUnOfficialDocs()
        for doc in unoffcialDocs {
            var newDoc = doc
            newDoc.isSelected = select
            updatedUnOfficialDocs.append(newDoc)
        }
        self.unOfficialDocsList = updatedUnOfficialDocs
    }

    func prepareTheAlertTitle() -> String? {
        guard let unOfficialDocuments = self.unOfficialDocsList else {
            return nil
        }
        let selectedDocsForRemoval = unOfficialDocuments.filter({ $0.isSelected == true})
        var messageString = ""
        if selectedDocsForRemoval.count == 1 {
            let doc = selectedDocsForRemoval[0]
            messageString = Documents.docRemovalSuccessMsg +  " <\(doc.docName ?? "")>"
        } else {
                messageString = Documents.docsRemovalSuccessMsg
        }
        return messageString
    }
    func prepareSuccessImageName() -> String? {
        guard let unOfficialDocuments = self.unOfficialDocsList else {
            return nil
        }
        let selectedDocsForRemoval = unOfficialDocuments.filter({ $0.isSelected == true})
        var imageName: String?
        if selectedDocsForRemoval.count > 1 {
            imageName = "success_multiple_docs_ico"
        } else {
            imageName = "success-doc-ico"
        }
        return imageName
    }
    func prepareNoOfDocsSelectedTitle() -> String? {
        guard let unOfficialDocuments = self.unOfficialDocsList else {
            return nil
        }
        let selectedDocs = unOfficialDocuments.filter({ $0.isSelected == true})
        let selectedDocString = (selectedDocs.count == 1) ?  Documents.singleDocSelcted : Documents.multipleDocSelcted
        return "(\(selectedDocs.count))" + selectedDocString
    }
    func prepareNoOfDocsSelectedTitleArabic() -> NSAttributedString? {
        guard let unOfficialDocuments = self.unOfficialDocsList else {
            return nil
        }
        let selectedDocs = unOfficialDocuments.filter({ $0.isSelected == true})
        let selectedDocString = (selectedDocs.count == 1) ?  Documents.singleDocSelcted : Documents.multipleDocSelcted
        let docCountString = "(\(selectedDocs.count))"
        let docCountTitleString = NSMutableAttributedString(string: docCountString, attributes:[
                   NSAttributedString.Key.foregroundColor: UIColor.white,
                   NSAttributedString.Key.font: UIFont(name: ArabicFont.regular.rawValue, size: 18) ?? UIFont.systemFont(ofSize: 18)])
        docCountTitleString.append(NSMutableAttributedString(string: selectedDocString, attributes:[
                   NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 18) ?? UIFont.systemFont(ofSize: 18)]))
        return docCountTitleString
    }
    func anyDocSelected() -> Bool {
        guard let unOfficialDocuments = self.unOfficialDocsList else {
            return false
        }
        let selectedDocs = unOfficialDocuments.filter({ $0.isSelected == true})
        return (selectedDocs.count == 0 ? false : true)
    }
    func resetPaginationDetails() {
       currentPageNo = 0
       maxPageNo = 1
       unOfficialDocsList = nil
    }
    func displayNoDocsAvailableView() -> TableRefreshType {
        var tableRefreshType: TableRefreshType = .dataError
        if let unOfficialDocsCount = unOfficialDocsList?.count {
            tableRefreshType =  (unOfficialDocsCount == 0) ? .noDocsAvailable  : .docsAvailable
        }
        return tableRefreshType
    }
    func noDocsAvlDetails() -> (title: String, text: String) {
        var titleMessage = ""
        var textMessage = ""
        if searchActive {
            titleMessage =  Documents.noRecordsMsg + " <\(searchText)>"
            textMessage =  IssuersList.validkeySearchMesssage + " <\(searchText)>"
        } else {
            titleMessage = Documents.noDocsMsg
            textMessage =  Documents.uploadDocsMsg
        }
        return (titleMessage, textMessage)
    }
}
extension DVSelfSignViewModel {
    func getSelectedUnOfficialCredentialCount() -> Int {
        guard let offcialDocs = unOfficialDocsList else {
            return 0
        }
        let selectedDocsForRemoval = offcialDocs.filter({ $0.isSelected == true})
        return selectedDocsForRemoval.count
    }
    func getSelectedCredentialDetails() -> (docId: String, docName: String) {
        guard let unOoffcialDocs = unOfficialDocsList else {
            return ("", "")
        }
        let selectedDocsForRemoval = unOoffcialDocs.filter({ $0.isSelected == true})
        var docIdSelected = "", docNameSelected = ""
        for doc in selectedDocsForRemoval {
            if let docId = doc.id, let documentName = doc.docName {
                docIdSelected =  docId
                docNameSelected =  documentName
                break // needed for multiple selection if needed
            }
        }
        return (docIdSelected, docNameSelected)
    }
    func shouldEnableSortButton() -> Bool {
        var enable = false
        if let unOfficialDocsCount = unOfficialDocsList?.count {
            enable =  (unOfficialDocsCount > 1) ? true : false
        }
        return enable
    }
    func checkWhehterAllUnOfficialDocsSelected() -> Bool {
        guard let unOffcialDocs = unOfficialDocsList else {
           return false
        }
        let selectedDocs = unOffcialDocs.filter({ $0.isSelected == true})
        return selectedDocs.count == unOffcialDocs.count
    }

}
