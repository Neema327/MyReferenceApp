//
//  DVUnofficialDataSource.swift
//  DigitalVaultAppSample
//
//  Created by MSP on 25/07/19.
//

import Foundation
import UIKit
protocol DVUnOfficialDocsDataSourceDelegate: class {
    func checkWhetherFetchFromServerIsRequiredForUnOfficial(indexPath: IndexPath)
    func displayOrHideRemoveButtonForUnofficial(display: Bool, addButtonEnabled: Bool, isAllDocsSelected:  Bool)
    func displayDocumentDetailViewForUnOfficial(indexPath: IndexPath)
    func tableRefreshRequiredForUnOfficial()
}
class DVUnofficialDataSource: NSObject {
    var tableView: UITableView?
    weak var delegate: DVUnOfficialDocsDataSourceDelegate?
    var selfSignViewModel: DVSelfSignViewModel?
    var isDocumentSelectionFlow = false
    var lastContentOffset: CGFloat = 0
    override init() {
       super.init()
    }
}

extension DVUnofficialDataSource: UITableViewDataSource {

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return self.selfSignViewModel?.unOfficialDocsList?.count ?? 0
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: DVOfficialDocTableViewCell.identifier, for: indexPath) as? DVOfficialDocTableViewCell {
            if let docs = selfSignViewModel?.unOfficialDocsList {
                let unOfficialDoc = docs[indexPath.row]
                cell.configureImageForSelctionButton(isDocSelection: isDocumentSelectionFlow)
                cell.configureUnOfficialCell(with: unOfficialDoc)
                cell.delegate = self
            }
            return cell
        }
        return UITableViewCell()
    }
}
extension DVUnofficialDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.delegate?.checkWhetherFetchFromServerIsRequiredForUnOfficial(indexPath: indexPath)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.displayDocumentDetailViewForUnOfficial(indexPath: indexPath)
    }
    // this delegate is called when the scrollView (i.e your UITableView) will start scrolling
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.lastContentOffset = scrollView.contentOffset.y
    }
    
    // while scrolling this delegate is being called so you may now check which direction your scrollView is being scrolled to
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if (self.lastContentOffset < scrollView.contentOffset.y) {
            DVConstants.docsSearchMode = .pagination
        } else if (self.lastContentOffset > scrollView.contentOffset.y) {
            DVConstants.docsSearchMode = .none
        } else {
            // didn't move
        }
    }
}
// MARK: - DVDocTableViewCellDelegate methods
extension DVUnofficialDataSource: DVDocTableViewCellDelegate {
    func selectOptionButtonClicked(sender: UIButton, cell: UITableViewCell) {
        if let unOfficialDocCell = cell as? DVOfficialDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
            if isDocumentSelectionFlow {
                if let currentIndexPath = currentTableView.indexPath(for: unOfficialDocCell) {
                    if var docs = selfSignViewModel?.unOfficialDocsList {
                        var currentDoc = docs[currentIndexPath.row]
                        selfSignViewModel?.selectOrUnselectAllDocs(select: false)
                        if !currentDoc.isSelected {
                            currentDoc.isSelected = !currentDoc.isSelected
                            selfSignViewModel?.unOfficialDocsList?[currentIndexPath.row] = currentDoc
                        }
                        self.delegate?.tableRefreshRequiredForUnOfficial()
                    }
                }
            } else {
                if let currentIndexPath = currentTableView.indexPath(for: unOfficialDocCell) {
                    if var docs = selfSignViewModel?.unOfficialDocsList {
                        var currentDoc = docs[currentIndexPath.row]
                        currentDoc.isSelected = !currentDoc.isSelected
                        docs[currentIndexPath.row] = currentDoc
                        selfSignViewModel?.unOfficialDocsList = docs
                        sender.isSelected = currentDoc.isSelected
                        let filteredItems = docs.filter({ $0.isSelected == true})
                        let displayRemoveButton = (filteredItems.count == 0 ? false : true)
                        let enableAddButton =  false
                        let allDocsSelected = selfSignViewModel?.checkWhehterAllUnOfficialDocsSelected() ?? false
                        self.delegate?.displayOrHideRemoveButtonForUnofficial(display: displayRemoveButton, addButtonEnabled: enableAddButton, isAllDocsSelected: allDocsSelected)

                    }
                }
            }
        }
}
}
