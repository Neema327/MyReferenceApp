//
//  DVViewEvidenceViewContoller.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 18/07/19.
//

import UIKit
import PDFKit
import WebKit

class DVViewEvidenceViewContoller: UIViewController, WKUIDelegate {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var evidencePdfView: PDFView!
    @IBOutlet weak var evidenceWebView: WKWebView!
    @IBOutlet weak var docNameLabel: UILabel!
    var isFromNotificationFlow = false
    let evidenceViewModel = DVEvidenceViewModel()
    let fileManager = DVFileManager()
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var docNameTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var downloadButtonLabel: UILabel!
    @IBOutlet weak var downlodTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var downloadButtonTrailingConstraint: NSLayoutConstraint!
    
    var credentialId: String?
    var credentialName: String?
    var detailTitle = ""
    var isFromOfficial = false
    var htmlString: String?

    lazy var progressIndicatorView: DVProgressIndicatorView = {
        let activityIndicator = DVProgressIndicatorView()
        return activityIndicator
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        if !isFromOfficial {
            WKWebView.clean()
        }
        downloadButtonLabel.text = Documents.download
        docNameLabel.text = self.detailTitle
        docNameLabel.adjustsFontSizeToFitWidth = true
        docNameLabel.minimumScaleFactor = 0.2
        configureViews()
        evidencePdfView.isHidden = true
        evidenceWebView.isHidden = false
        evidenceWebView.uiDelegate = self
     
        evidenceWebView.navigationDelegate = self

        if !isFromOfficial {
            if isFromNotificationFlow {
                docNameTrailingConstraint.constant = 15.0
                downloadButton.isHidden = true
                downloadButtonLabel.isHidden = true
            } else {
                docNameTrailingConstraint.constant = 85.0
                downloadButton.isHidden = false
                downloadButtonLabel.isHidden = false
            }
        } else {
            docNameTrailingConstraint.constant = 15.0
            downloadButton.isHidden = true
            downloadButtonLabel.isHidden = true
        }
        loadCredentialData()
        if DVConstants.uaepassArabicLocalization {
            self.navigationController?.navigationBar.semanticContentAttribute = .forceRightToLeft
//            docNameLabel.font = UIFont(name: ArabicFont.twoMedium.rawValue, size: 35.0)
            downloadButtonLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 12.0)
            downlodTrailingConstraint.constant = 19.0
            downloadButtonTrailingConstraint.constant = 18.0
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
        self.navigationController?.navigationBar.topItem?.title = DVConstants.Strings.emptyString
    }
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
}
extension DVViewEvidenceViewContoller {
    @IBAction func downloadBtnAction(sender: UIBarButtonItem) {
        loadEvidenceData(needToWrite: true)
    }
    func configureViews() {
        containerView.setUpRoundedCornerView(view: containerView)
        self.view.backgroundColor = UIColor.colorFromHex(rgbValue: 0xF8F8FB)
        progressIndicatorView.addActivityIndicatorToTheView(view: self.view)
    }
    func loadEvidenceHtml(with credentialId: String) {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.evidenceViewModel.fetchEvidenceHtmlData(credentialId: credentialId, completionHandler: { [weak self] (_, _) in
                DispatchQueue.main.async {
                    if let evidenceHtml = self?.evidenceViewModel.evidenceHtmlString {
                        self?.evidenceWebView.loadHTMLString(evidenceHtml, baseURL: nil)
                    }
                }
                }, failureHandler: {  (_, error) in
                    DispatchQueue.main.async {
                        DVCommon.hideActivityIndicatorView()
                        DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                    }
            })

        }
    }
    func loadCredentialData() {
        if isFromOfficial {
            DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
            loadEvidenceDetailsHtml()
        } else {
            guard let credId = credentialId else {
                return
            }
            loadEvidenceHtml(with: credId)
        }
    }
    func loadEvidenceDetailsHtml() {
        guard let htmlStr = self.htmlString else {
            return
        }
        let evidenceHtml = evidenceViewModel.makeEvidenceHtmlCodeVisible(with: htmlStr)
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
        self.evidenceWebView.loadHTMLString(evidenceHtml, baseURL: nil)
    }
    func loadEvidenceData(needToWrite: Bool) {
        guard let credId = credentialId, let credName = credentialName else {
            return
        }
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.downloadMessage)
        let dispatchQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        dispatchQueue.async {
            self.evidenceViewModel.fetchEvidenceData(credentialId: credId, credentialName: credName,  needToWrite: needToWrite, completionHandler: { [weak self] (_, evidenceData) in
                DispatchQueue.main.async {
                    if needToWrite {
                        DVCommon.hideActivityIndicatorView()
                        self?.storeToFiles()
                    } else {
                        guard let pdfData = evidenceData else {
                            return
                        }
                        self?.loadPdfData(pdfData: pdfData)
                    }
                }
            }, failureHandler: {  (_, error) in
                DispatchQueue.main.async {
                    DVCommon.hideActivityIndicatorView()
                    DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
                }
            })
        }
    }

    func loadPdfData(pdfData: Data) {
        if let pdfDocument = PDFDocument(data: pdfData) {
            self.evidencePdfView.displayMode = .singlePageContinuous
            self.evidencePdfView.autoScales = true
            self.evidencePdfView.document = pdfDocument
        } else {
            DVCommon.showError(serviceError: dvDataError, withSuccess: nil, andFailure: nil)
        }
        DVCommon.hideActivityIndicatorView()
    }
    private func storeToFiles() {
        guard let documentLocation = evidenceViewModel.documentLocation else { return }
        let fileUrl = URL(fileURLWithPath: documentLocation)
        let documentPicker = UIDocumentPickerViewController(url: fileUrl, in: .exportToService)
        documentPicker.delegate = self
        present(documentPicker, animated: true)
    }
}
// MARK: - WKNavigationDelegate Methods
extension DVViewEvidenceViewContoller: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DVCommon.hideActivityIndicatorView()
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
         DVCommon.hideActivityIndicatorView()
    }
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        //for making the content to fit with the device size
        
        if !isFromOfficial {
            let jscript = DVConstants.viewEvidenceJScript
            webView.evaluateJavaScript(jscript)
        } else {
            let jscript = "var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); document.getElementsByTagName('head')[0].appendChild(meta);"
            webView.evaluateJavaScript(jscript)
        }
    }
}

extension DVViewEvidenceViewContoller: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {

    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {

    }
}
