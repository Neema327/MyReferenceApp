//
//  DVEvidenceViewModel.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 03/08/19.
//

import Foundation
import PromiseKit

class DVEvidenceViewModel {
    var  evidenceData: Data?
    var  htmlString: String?
    var  evidenceHtmlString: String?
    let fileManager = DVFileManager()
    var documentLocation: String?
}
extension DVEvidenceViewModel {
    func fetchEvidenceData(credentialId: String, credentialName: String, needToWrite: Bool, completionHandler: @escaping SuccessDataClosure,
                           failureHandler: @escaping FailureClosure) {
        self.fileManager.getEvidenceData(credentialId: credentialId, credentialName: credentialName, needToWrite: needToWrite, completionHandler: { [weak self] (_, evidenceData) in
            self?.documentLocation = self?.fileManager.documentLocation
            completionHandler(true, evidenceData)
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    //To get the uploaded Evidence Data

    func fetchEvidenceHtmlData(credentialId: String, completionHandler: @escaping SuccessClosure,
                              failureHandler: @escaping FailureClosure) {
        self.getEvidenceHtml(credentialId: credentialId, completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, errorMessage) in
            failureHandler(false, errorMessage)
        })
    }
    func getEvidenceHtml(credentialId: String, completionHandler: @escaping SuccessClosure,
                        failureHandler: @escaping FailureClosure) {
        self.getEvidenceHtmlDetails(credentialId: credentialId)
            .done({ (detailHtml) in
                let htmlData = detailHtml as? Data
                let decodedHtmlString = htmlData?.utf8String
                guard let htmlString = decodedHtmlString else {
                    failureHandler(false, dvDataError)
                    return
                }
                self.evidenceHtmlString = htmlString
                completionHandler(true, "")

            })
            .catch { error in
                failureHandler(false, error) //need to change
        }
    }
    //To view credential's details html
    func getEvidenceHtmlDetails(credentialId: String) -> Promise<Any> {
        return Promise {  seal in

            let  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + credentialId + "/evidence"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = "application/html"
            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in

                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.html)
                    .done({ (decodedHtml) in
                        seal.fulfill(decodedHtml)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    //To view credential's details html
    func getCredentialDetails(credentialId: String) -> Promise<Any> {
        return Promise {  seal in

            let  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + credentialId
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[content] = ContentType.html.rawValue
            
            headerParams[authorization] = DVCommon.bearerToken
            dvService.fetchData(nil as DVSelfSignedCredential?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.html)
                    .done({ (decodedHtml) in
                        seal.fulfill(decodedHtml)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    
    func makeEvidenceHtmlCodeVisible(with html: String) -> String {
        let strData = "<div class=\"data\" style=\"display: visible;\">"
        let strReplacedData = "<div class=\"data\" style=\"display: none;\">"
        let strEvidence = "<div class=\"evidence\" style=\"display: none;\">"
        let strReplacedEvidence = "<div class=\"evidence\" style=\"display: visible;\">"
        let replaced = html.replacingOccurrences(of: strData, with: strReplacedData)
        let replaced2 = replaced.replacingOccurrences(of: strEvidence, with: strReplacedEvidence)
        return replaced2
    }
}
