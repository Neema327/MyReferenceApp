//
//  DVOfficialDoc.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 24/07/19.
//

import Foundation

// MARK: - DVOfficialDoc
struct DVOfficialDoc: Codable {
    let id, issuerName, issuerAddress, docMnemonic, issuedDate: String?
    let docName: String?
    var isSelected = false
    enum CodingKeys: String, CodingKey {
        case id
        case issuerName
        case issuerAddress
        case docMnemonic
        case issuedDate
        case docName
    }
}

// MARK: DVOfficialDoc convenience initializers and mutators

extension DVOfficialDoc {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVOfficialDoc.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        id: String?? = nil,
        issuerName: String?? = nil,
        issuerAddress: String?? = nil,
        docMnemonic: String?? = nil,
        issuedDate: String?? = nil,
        docName: String?? = nil
        ) -> DVOfficialDoc {
        return DVOfficialDoc(
            id: id ?? self.id,
            issuerName: issuerName ?? self.issuerName,
            issuerAddress: issuerAddress ?? self.issuerAddress,
            docMnemonic: docMnemonic ?? self.docMnemonic,
            issuedDate: issuedDate ?? self.issuedDate,
            docName: docName ?? self.docName,
            isSelected: self.isSelected
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

typealias DVOfficialDocs = [DVOfficialDoc]

extension Array where Element == DVOfficialDocs.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVOfficialDocs.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
