//
//  DVOfficialDocsViewModel.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 24/07/19.
//  View Model Class for Requested Documents

import Foundation
import UIKit
import PromiseKit

class DVOfficialDocsViewModel {
    var officialDocs: DVOfficialDocs?
    var presentmentDocDetails: [String: Any]?
    var searchActive: Bool = false
    var searchText = ""
    var sortActive: Bool = false
    var sortOrder: SortOrders = .name
    var isSelectAllMode = false
    var currentPageNo = 0
    var maxPageNo = 1
    init() {

    }
}
extension DVOfficialDocsViewModel {
    func fetchOfficialDocsData(completionHandler: @escaping SuccessClosure,
                               failureHandler: @escaping FailureClosure) {
        self.getOfficialDocumentsList(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func fetchOfficialDocsSearchData(completionHandler: @escaping SuccessClosure,
                               failureHandler: @escaping FailureClosure) {
        self.getOfficialDocumentsList(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }

    func removeOfficialDocs(completionHandler: @escaping SuccessClosure,
                               failureHandler: @escaping FailureClosure) {
        self.removeOfficialDocuments(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    func submitAddOrReplaceOfficialDocForPresentment(completionHandler: @escaping SuccessClosure,
                            failureHandler: @escaping FailureClosure) {
        self.addOrReplaceDocumentForPresentment(completionHandler: { (_, _) in
            completionHandler(true, "")
        }, failureHandler: {(_, error) in
            failureHandler(false, error)
        })
    }
    private func addOrReplaceDocumentForPresentment(completionHandler: @escaping SuccessClosure,
                                         failureHandler: @escaping FailureClosure) {
            self.invokeServiceForOfficialDocAddOrReplace()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error)
            }
    }
    
   private func removeOfficialDocuments(completionHandler: @escaping SuccessClosure,
                                   failureHandler: @escaping FailureClosure) {
            self.invokeServiceForOfficialDocsRemoval()
                .done({ (_) in
                    completionHandler(true, "")
                })
                .catch { error in
                    failureHandler(false, error)
            }
    }
    private func getOfficialDocumentsList(completionHandler: @escaping SuccessClosure,
                              failureHandler: @escaping FailureClosure) {
            self.invokeServiceForOfficialDocs()
                .done({ (officialDocsList) in
                    self.maxPageNo = self.maxPageNo + 1
                    guard var newOfficialDocs = officialDocsList as? DVOfficialDocs else {
                        failureHandler(false, dvDataError)
                        return
                    }
//                    print("***Resp Count is \(newOfficialDocs.count)")
                    var updatedDocsArray = DVOfficialDocs()
                    if self.isSelectAllMode {
                        for doc in newOfficialDocs {
                            var curDoc = doc
                            curDoc.isSelected = true
                            updatedDocsArray.append(curDoc)
                        }
                        newOfficialDocs = updatedDocsArray
                    }
                    if self.currentPageNo != 0 {
                        if var currentOfficialDocsArray = self.officialDocs {
                            for doc in newOfficialDocs {
                                currentOfficialDocsArray.append(doc)
                            }
                            self.officialDocs = currentOfficialDocsArray
                        }
                    } else {
                        self.officialDocs = newOfficialDocs
                    }
                    if newOfficialDocs.count == 0 {
                        self.maxPageNo = self.currentPageNo
                    }
                    completionHandler(true, "")
              })
              .catch { error in
                    failureHandler(false, error) //need to change
            }
    }
    private func invokeServiceForOfficialDocs() -> Promise<Any> {
        return Promise {  seal in
            
            var  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDefault.rawValue + "\(currentPageNo)"
            if searchActive {
                serviceURL = serviceURL + "&filterBy=\(searchText)"
            }
            if sortActive {
                let sortByText = sortOrder == .name ? "&sort=name,asc" : "&sort=date,desc"
                serviceURL =    serviceURL + sortByText
            } else {
                serviceURL =    serviceURL + "&sort=name,asc"
            }
            
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]
            
            headerParams[authorization] = DVCommon.bearerToken
            let  dvService = DVServiceManager()
            dvService.fetchData(nil as DVOfficialDoc?, serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.GET) {
                (jsonResponse, respError) in
                //Decode server response
                DVCommon.decodeResponse(type: DVOfficialDocs.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.model)
                .done({ (officialDocsList) in
                    seal.fulfill(officialDocsList)
                }).catch { error in
                    seal.reject(error)
                }
            }
        }
    }
    private func invokeServiceForOfficialDocsRemoval() -> Promise<Any> {
        return Promise {  seal in
            guard let offcialDocs = officialDocs else {
                return
            }
            let selectedDocsForRemoval = offcialDocs.filter({ $0.isSelected == true})
            var idsOfOfficialDocsToBeRemoved = ""
            for doc in selectedDocsForRemoval {
                if let docId = doc.id {
                    idsOfOfficialDocsToBeRemoved = idsOfOfficialDocsToBeRemoved + docId + ","
                }
            }
            idsOfOfficialDocsToBeRemoved = String(idsOfOfficialDocsToBeRemoved.dropLast())
            let serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue + idsOfOfficialDocsToBeRemoved + "/remove"
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                (jsonResponse, _, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }
    private func invokeServiceForOfficialDocAddOrReplace() -> Promise<Any> {
        return Promise {  seal in
            guard let docs = officialDocs, let presDocDetails = presentmentDocDetails else {
                return
            }
            guard let presReqId = presDocDetails[DVConstants.requestIdKey] as? String, let requestedDocId = presDocDetails[DVConstants.documentIdKey] as? String  else {
                return
            }
            let selectedDocs = docs.filter({ $0.isSelected == true})
            var idOfSelectedDoc: String?
            for doc in selectedDocs {
                if let docId = doc.id {
                    idOfSelectedDoc = docId
                    break //only one doc can be selected for add/replace
                }
            }
            guard let selectedDocId = idOfSelectedDoc else {
                return
            }
            let serviceURL: String =  baseURL + apiVersion + EndPoint.presentmentDocAddReplace.rawValue + presReqId + "/documents/" + requestedDocId
            let  dvService = DVServiceManager()
            var headerParams: HeaderParams = [:]
            var reqParameters: RequestParams = [:] //selected doc id is passing as the vcid
            let dict = ["vcid": selectedDocId]
            reqParameters = dict
            headerParams[authorization] = DVCommon.bearerToken
            headerParams[content] = ContentType.json.rawValue

            dvService.submitData(serverURL: (serviceURL), headerParams: headerParams, parameters: reqParameters, method: HttpMethod.PUT) {
                 (jsonResponse,_, respError) in
                
                DVCommon.decodeResponse(type:DVSelfSignedCredential.self, respData: jsonResponse, errorData: respError,decodeOpt: DecodeOption.data)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }

    func selectOrUnselectAllDocs(select: Bool) {
        guard let officialDocsList = officialDocs else {
            return
        }
        var docsList = DVOfficialDocs()
        for doc in officialDocsList {
            var newDoc = doc
            newDoc.isSelected = select
            docsList.append(newDoc)
        }
        self.officialDocs = docsList
    }
    func getTheIdsOfSelctedOfficialDocsForRemoval() -> [String]? {
        guard let officialDocuments = self.officialDocs else {
            return nil
        }
        let selectedDocsForRemoval = officialDocuments.filter({ $0.isSelected == true})
        var docsIds = [String]()
        for selectedDoc in selectedDocsForRemoval {
            if let docId = selectedDoc.id {
                docsIds.append(docId)
            }
        }
        return docsIds
    }

    func prepareTheAlertTitle() -> String? {
        guard let officialDocuments = self.officialDocs else {
            return nil
        }
        let selectedDocsForRemoval = officialDocuments.filter({ $0.isSelected == true})
        var messageString: String?
        if selectedDocsForRemoval.count == 1 {
            let doc = selectedDocsForRemoval[0]
             messageString = Documents.docRemovalSuccessMsg + " <\(doc.docName ?? "")>"
        } else {
                messageString = Documents.docsRemovalSuccessMsg
        }
        return messageString
    }
    func prepareSuccessImageName() -> String? {
        guard let officialDocuments = self.officialDocs else {
            return nil
        }
        let selectedDocsForRemoval = officialDocuments.filter({ $0.isSelected == true})
        var imageName: String?
        if selectedDocsForRemoval.count > 1 {
            imageName = "success_multiple_docs_ico"
        } else {
            imageName = "success-doc-ico"
        }
        return imageName
    }
    func prepareNoOfDocsSelectedTitle() -> String? {
        guard let officialDocuments = self.officialDocs else {
            return nil
        }
        let selectedDocs = officialDocuments.filter({ $0.isSelected == true})
        let selectedDocString = (selectedDocs.count == 1) ?  Documents.singleDocSelcted : Documents.multipleDocSelcted
        return "(\(selectedDocs.count))" + selectedDocString
    }
    
    func prepareNoOfDocsSelectedTitleArabic() -> NSAttributedString? {
        guard let officialDocuments = self.officialDocs else {
            return nil
        }
        let selectedDocs = officialDocuments.filter({ $0.isSelected == true})
        let selectedDocString = (selectedDocs.count == 1) ?  Documents.singleDocSelcted : Documents.multipleDocSelcted
        let docCountString = "(\(selectedDocs.count))"
        let docCountTitleString = NSMutableAttributedString(string: docCountString, attributes:[
                   NSAttributedString.Key.foregroundColor: UIColor.white,
                   NSAttributedString.Key.font: UIFont(name: ArabicFont.regular.rawValue, size: 18) ?? UIFont.systemFont(ofSize: 18)])
        docCountTitleString.append(NSMutableAttributedString(string: selectedDocString, attributes:[
                   NSAttributedString.Key.font: UIFont(name: ArabicFont.twoMedium.rawValue, size: 18) ?? UIFont.systemFont(ofSize: 18)]))
        return docCountTitleString
    }
    func anyDocSelected() -> Bool {
        guard let officialDocuments = self.officialDocs else {
            return false
        }
        let selectedDocs = officialDocuments.filter({ $0.isSelected == true})
        return (selectedDocs.count == 0 ? false : true)
    }
    // resetting the currentPageNo, maxPageNo and officialDocs for a new default pagination/sort/search
    func resetPaginationDetails() {
        currentPageNo = 0
        maxPageNo = 1
        officialDocs = nil
    }
    func displayNoDocsAvailableView() -> TableRefreshType {
        var tableRefreshType: TableRefreshType = .dataError
        if let officialDocsCount = officialDocs?.count {
            tableRefreshType =  (officialDocsCount == 0) ? .noDocsAvailable  : .docsAvailable
        }
        return tableRefreshType
    }
    func noDocsAvlDetails() -> (title: String, text: String) {
        var titleMessage = ""
        var textMessage = ""
        if searchActive {
            titleMessage = Documents.noRecordsMsg + " <\(searchText)>"
            textMessage = IssuersList.validkeySearchMesssage + " <\(searchText)>"
        } else {
            titleMessage = Documents.noDocsMsg
            textMessage = Documents.addDocsMsg
        }
        return (titleMessage, textMessage)
    }
    func getSelectedOfficialCredentialCount() -> Int {
        guard let offcialDocs = officialDocs else {
            return 0
        }
        let selectedDocsForRemoval = offcialDocs.filter({ $0.isSelected == true})
        return selectedDocsForRemoval.count
    }
    func shouldEnableSortButton() -> Bool {
        var enable = false
        if let officialDocsCount = officialDocs?.count {
            enable =  (officialDocsCount > 1) ? true  : false
        }
        return enable
    }
    func checkWhehterAllOfficialDocsSelected() -> Bool {
        guard let offcialDocs = officialDocs else {
           return false
        }
        let selectedDocs = offcialDocs.filter({ $0.isSelected == true})
        return selectedDocs.count == offcialDocs.count
    }

}
