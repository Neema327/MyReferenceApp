//
//  DVCredentialCell.swift
//  DigitalVaultFramework
//
//  Created by CDB_Int1 on 25/06/19.
//

import UIKit
protocol DVDocTableViewCellDelegate: class {
    func selectOptionButtonClicked(sender: UIButton, cell: UITableViewCell)
}
class DVOfficialDocTableViewCell: UITableViewCell {
        @IBOutlet weak var credentialNameLbl: UILabel!
        @IBOutlet weak var credentialDescLabel: UILabel!
        @IBOutlet weak var credentialImgView: UIImageView!
        @IBOutlet weak var credentialDateLabel: UILabel!
        @IBOutlet weak var selectBtn: UIButton!
        @IBOutlet weak var arrowBtn: UIButton!
        @IBOutlet weak var selectBtnWidthConstraint: NSLayoutConstraint!
        @IBOutlet weak var selectBtnContainerView: UIView!

        weak var delegate: DVDocTableViewCellDelegate?
        @IBOutlet weak var verifiedImgView: UIImageView!

    override func awakeFromNib() {
        selectBtn.isUserInteractionEnabled = false
        credentialDateLabel.minimumScaleFactor = 0.5
        credentialDateLabel.adjustsFontSizeToFitWidth = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        tap.delegate = self
        selectBtnContainerView.addGestureRecognizer(tap)
        if DVConstants.uaepassArabicLocalization {
            credentialNameLbl.font = UIFont(name: ArabicFont.bold.rawValue, size: 18)
            credentialDescLabel.font =  UIFont(name: ArabicFont.regular.rawValue, size: 14)
            credentialDateLabel.font = UIFont(name: ArabicFont.regular.rawValue, size: 14)
            arrowBtn.setImage(DVCommon.getImage(named: "Disclosure-Indicator-flipped-ico.png"), for: .normal)
        }
        super.awakeFromNib()
    }
    static var nib: UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
    static var identifier: String {
        return String(describing: self)
    }
    override func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return touch.view == selectBtnContainerView
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {
        self.delegate?.selectOptionButtonClicked(sender: selectBtn, cell: self)
    }
    @IBAction func selectBtnAction(_ sender: Any) {
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    func configureImageForSelctionButton(isDocSelection: Bool) {
        if isDocSelection {
            selectBtn.setImage(DVCommon.getImage(named: "radio-btn-ico"), for: .normal)
            selectBtn.setImage(DVCommon.getImage(named: "selected-radio-btn-ico"), for: .selected)
        } else {
            selectBtn.setImage(DVCommon.getImage(named: "checkbox-ico"), for: .normal)
            selectBtn.setImage(DVCommon.getImage(named: "checkbox-selected"), for: .selected)
        }
    }

    func configureOfficialCell(with officialDoc: DVOfficialDoc) {
        self.credentialNameLbl.text = officialDoc.docName ?? ""
        self.credentialDescLabel.text =  officialDoc.issuerName ?? ""
        if let credentialDateString = Date.getFormattedDate(date: officialDoc.issuedDate ?? "") {
            self.credentialDateLabel.text = credentialDateString
        }
        self.verifiedImgView.isHidden = false
        updateDocImage(with: "mandatory-docs-ico.png")
        self.selectBtn.isSelected = officialDoc.isSelected
    }

     func configureUnOfficialCell(with unOfficialDoc: DVSelfSignedCredential) {
        
        let updatedDocMnemonic = Documents.category + " " + (unOfficialDoc.docTypeName ?? "")
        self.credentialNameLbl.text = unOfficialDoc.docName ?? ""
        self.credentialDescLabel.text =  updatedDocMnemonic
        if let uploadedDate = unOfficialDoc.uploadedAt {
            self.credentialDateLabel.text = Date.getFormattedDate(date: uploadedDate )
        }
        self.verifiedImgView.isHidden = false
        updateDocImage(with: "unofficial_doc_small_ico.png")
        self.selectBtn.isSelected = unOfficialDoc.isSelected
    }

    func updateDocImage(with imageName: String) {
        let tempCredentialImage = UIImage(contentsOfFile: DVCommon.digitalVaultResourceBundlePath + imageName)
        self.verifiedImgView.image = tempCredentialImage

    }
}
