//
//  DVOfficialDocsDataSource.swift
//  DigitalVaultFramework
//
//  Created by Lija George on 25/07/19.
//

import Foundation
import UIKit
import Kingfisher

protocol DVOfficialDocsDataSourceDelegate: class {
    func checkWhetherFetchFromServerIsRequired(indexPath: IndexPath)
    func displayOrHideRemoveButton(display: Bool, addButtonEnabled: Bool, isAllDocsSelected: Bool)
    func displayDocumentDetailView(indexPath: IndexPath)
    func tableRefreshRequired()
}
class DVOfficialDocsDataSource: NSObject {
    var tableView: UITableView?
    weak var delegate: DVOfficialDocsDataSourceDelegate?
    var officialDocsViewModel: DVOfficialDocsViewModel?
    var isDocumentSelectionFlow = false
    var lastContentOffset: CGFloat = 0

    override init() {
        super.init()
    }
}
extension DVOfficialDocsDataSource: UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return  self.officialDocsViewModel?.officialDocs?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: DVOfficialDocTableViewCell.identifier,
                                                    for: indexPath) as? DVOfficialDocTableViewCell {
            if let docs = officialDocsViewModel?.officialDocs {
                let officialDoc = docs[indexPath.row]
                cell.configureImageForSelctionButton(isDocSelection: isDocumentSelectionFlow)
                cell.configureOfficialCell(with: officialDoc)
                cell.delegate = self
            }
            return cell
        }
        return UITableViewCell()
    }
}

extension DVOfficialDocsDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        self.delegate?.checkWhetherFetchFromServerIsRequired(indexPath: indexPath)
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.displayDocumentDetailView(indexPath: indexPath)
    }
    // this delegate is called when the scrollView (i.e your UITableView) will start scrolling
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.lastContentOffset = scrollView.contentOffset.y
    }
    
    // while scrolling this delegate is being called so you may now check which direction your scrollView is being scrolled to
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (self.lastContentOffset < scrollView.contentOffset.y) {
            DVConstants.docsSearchMode = .pagination
        } else if (self.lastContentOffset > scrollView.contentOffset.y) {
             DVConstants.docsSearchMode = .none
        } else {
            // didn't move
        }
    }
}
// MARK: - DVDocTableViewCellDelegate methods
extension DVOfficialDocsDataSource: DVDocTableViewCellDelegate {
    func selectOptionButtonClicked(sender: UIButton, cell: UITableViewCell) {
        if let officialDocCell = cell as? DVOfficialDocTableViewCell {
            guard let currentTableView = self.tableView else {
                return
            }
             if isDocumentSelectionFlow {
                if let currentIndexPath = currentTableView.indexPath(for: officialDocCell) {
                   if var docs = officialDocsViewModel?.officialDocs {
                        var currentDoc = docs[currentIndexPath.row]
                        officialDocsViewModel?.selectOrUnselectAllDocs(select: false)
                        if !currentDoc.isSelected {
                            currentDoc.isSelected = !currentDoc.isSelected
                            officialDocsViewModel?.officialDocs?[currentIndexPath.row] = currentDoc
                        }
                        self.delegate?.tableRefreshRequired()
                    }
                }
             } else {
                if let currentIndexPath = currentTableView.indexPath(for: officialDocCell) {
                if var docs = officialDocsViewModel?.officialDocs {
                    var currentDoc = docs[currentIndexPath.row]
                    currentDoc.isSelected = !currentDoc.isSelected
                    docs[currentIndexPath.row] = currentDoc
                    officialDocsViewModel?.officialDocs = docs
                    sender.isSelected = currentDoc.isSelected

                    let filteredItems = docs.filter({ $0.isSelected == true})
                    let displayRemoveButton = (filteredItems.count == 0 ? false : true)
                    let enableAddButton =  false
                    let allDocsSelected = officialDocsViewModel?.checkWhehterAllOfficialDocsSelected() ?? false
                    self.delegate?.displayOrHideRemoveButton(display: displayRemoveButton, addButtonEnabled: enableAddButton, isAllDocsSelected: allDocsSelected)

                }
            }
        }
        }
    }
}
