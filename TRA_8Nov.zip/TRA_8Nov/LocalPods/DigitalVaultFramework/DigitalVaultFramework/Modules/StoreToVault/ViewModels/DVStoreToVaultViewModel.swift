//
//  DVStoreToVaultViewModel.swift
//  DigitalVaultFramework
//
//  Created by Saiaswanth on 7/24/19.
//  View Model Class for storing documents under specific category

import Foundation
import PromiseKit

class DVStoreToVaultViewModel: DVBaseViewModel {
    var categories: DVStoreToVaultCategories?
    let dvService = DVServiceManager()
    var updatedCategories: [String]?

    func getNumberOfCategories() -> Int {
        if let categories = categories {
            return categories.count
        }
        return 0
    }

    func getCategoryName(for row: Int) -> String {

        guard let categories = categories else {
            return ""
        }

        if let categoryName = categories[row].name {
            return categoryName
        }
        return ""
    }

    func getCategoryMnemonic(for row: Int) -> String {

        guard let categories = categories else {
            return ""
        }
        if let categoryName = categories[row].docMnemonic {
            return categoryName
        }
        return ""
    }
    
    func isDocumentNameScreeVisible(for row: Int) -> Bool {
        
        return true
        
//        if getCategoryName(for: row).capitalized.contains(StoreToVault.newCategoryTitle.capitalized) {
//            return true
//        }
//        return false
    }

    func uploadDocument(with url: String, name: String, mnemonic: String, successHandler: @escaping SuccessClosure, failureHandler: @escaping FailureClosure) {

        invokeConfirmationServie(of: url, with: name, documentMnemonic: mnemonic).done({ (status) in

            guard let confirmationStatus = status as? Bool else {
                failureHandler(false, dvDataError)
                return
            }

            if confirmationStatus {
                successHandler(true, DVConstants.Strings.storeToVaultSuccessMessage)
            } else {
                failureHandler(true, dvDataError)
            }
        }).catch({ error in
                failureHandler(false,error)
            })
    }

    func getCategoryList(successHandler: @escaping SuccessClosure, failureHandler: @escaping FailureClosure) {

        let serviceQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        serviceQueue.sync {

            invokeServiceForDocumentCategories().done { [weak self] (documentCategoryList) in

                guard let documentCategoryList = documentCategoryList as? DVStoreToVaultCategories else {
                    failureHandler(false, dvDataError)
                    return
                }
                self?.categories = documentCategoryList
                successHandler(true, "Fetched category list succesfully")
            }
                .catch({ error in
                    failureHandler(false, error)
                })
        }
    }

    private func invokeServiceForDocumentCategories() -> Promise<Any> {

        return Promise { seal in

            let  serviceURL: String =  baseURL + apiVersion + EndPoint.storeToVaultDocumentCategories.rawValue
            var headerParams: HeaderParams = [:]
            let reqParameters: RequestParams = [:]

            headerParams[authorization] = DVCommon.bearerToken

            dvService.fetchData(nil as DVStoreToVaultCategoryList?, serverURL: serviceURL, headerParams: headerParams, parameters: reqParameters, method: .GET) { (jsonResponse, responseError) in
                
                DVCommon.decodeResponse(type:DVStoreToVaultCategories.self, respData: jsonResponse, errorData: responseError,decodeOpt: DecodeOption.model)
                    .done({ (decodedData) in
                        seal.fulfill(decodedData)
                    }).catch { error in
                        seal.reject(error)
                }
            }
        }
    }

    private func invokeConfirmationServie(of documentUrl: String, with documentName: String, documentMnemonic: String) -> Promise<Any> {

        return Promise { seal in

            let  serviceURL: String =  baseURL + apiVersion + EndPoint.officialDocsDetail.rawValue
            var headerParams: HeaderParams = [:]
            var reqParameters: RequestParams = [:]
            headerParams[authorization] = DVCommon.bearerToken
            
            reqParameters["name"] = documentName
            reqParameters["mnemonic"] = documentMnemonic
            reqParameters["fileUrl"] = documentUrl

            dvService.submitData(serverURL: serviceURL, headerParams: headerParams, parameters: reqParameters, method: .POST, completion: { (jsonData, _, responseError) in

                DVCommon.decodeResponse(type:DVStoreToVaultCategories.self, respData: jsonData, errorData: responseError,decodeOpt: DecodeOption.data)
                    .done({ (_) in
                        seal.fulfill(true)
                    }).catch { error in
                        seal.reject(error)
                }
                
//                if let _ = jsonData {
//                    seal.fulfill(true)
//                } else {
//                    if let responseError = responseError {
//                        seal.reject(responseError)
//                    } else {
//                        seal.fulfill(false)
//                    }
//                }
            })
        }
    }
}
