//
//  DVStoreToVaultViewController.swift
//  Alamofire
//
//  Created by Saiaswanth on 7/18/19.
//  View class for storing documents under specific category

import UIKit
import SwiftEventBus

class DVStoreToVaultViewController: DVBaseViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var containerViewTitleLabel: UILabel!
    @IBOutlet weak var containerViewCancelButton: UIButton!
    @IBOutlet weak var confirmView: UIView!
    @IBOutlet weak var confirmViewTitleLabel: UILabel!
    @IBOutlet weak var confirmViewCancelButton: UIButton!
    @IBOutlet weak var documentNameTextField: UITextField!
    @IBOutlet weak var documentCategoryTableView: UITableView!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var successView: UIView!
    @IBOutlet weak var successOkButton: UIButton!
    @IBOutlet weak var successLogo: UIImageView!
    @IBOutlet weak var successLabel: UILabel!
    @IBOutlet weak var successMessageLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var sucessMessageView: UIView!
    @IBOutlet weak var documentNameBottomView: UIView!
    @IBOutlet weak var documentNameLabel: UILabel!
    @IBOutlet weak var documentNameValidationLabel1: UILabel!
    @IBOutlet weak var documentNameValidationLabel2: UILabel!
    @IBOutlet weak var validationStackView: UIStackView!
    @IBOutlet weak var confirmViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var errorContentLabel: UILabel!
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var exitButton: UIButton!
    @IBOutlet weak var errorView: UIView!
    
    var documentUrl: String?
    private let viewModel = DVStoreToVaultViewModel()
    private let documentCategoryCellIdentifier = DVStoreToDocumentCategoryCell.identifier
    private let window = UIApplication.shared.keyWindow
    private var selectedDocumentName: String?
    private var selectedDocumentMnemonic: String?

    override func viewDidLoad() {
        super.viewDidLoad()

        configureUI()
        getCategoryList()
        documentNameTextField.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DVEventHandler.sharedInstance.startUAEPassOperationsResolving()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        DVEventHandler.sharedInstance.stopUAEPassOperationResolving()
    }
    
    private func configureUI() {
        
        confirmView.setUpRoundedCornerView(view: confirmView)
        containerView.setUpRoundedCornerView(view: containerView)
        sucessMessageView.setUpRoundedCornerView(view: sucessMessageView)
        errorView.setUpRoundedCornerView(view: errorView)
        
        confirmButton.setViewsLayer(layer: confirmButton.layer, shouldLayerBorderClearColor: false)
        successOkButton.setViewsLayer(layer: successOkButton.layer, shouldLayerBorderClearColor: false)
        downloadButton.setViewsLayer(layer: downloadButton.layer, shouldLayerBorderClearColor: false)

        confirmView.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)
        containerView.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)
        sucessMessageView.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)
        errorView.roundCorners(corners: [.topLeft, .topRight], radius: 15.0)

        successOkButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        documentNameBottomView.backgroundColor = UIColor.colorFromHex(rgbValue: 0xCFCFCF)
        documentNameLabel.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        documentNameValidationLabel1.textColor = UIColor.colorFromHex(rgbValue: 0x99A2B4)
        documentNameValidationLabel2.textColor = UIColor.colorFromHex(rgbValue: 0x99A2B4)
        errorContentLabel.textColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        downloadButton.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
        documentNameTextField.textColor = UIColor.colorFromHex(rgbValue: 0x454F63)
        documentNameTextField.textColor?.withAlphaComponent(0.80)

        containerViewCancelButton.setTitle(Documents.cancelButtonTitle, for: .normal)
        confirmButton.setTitle(StoreToVault.confirmButtonTitle, for: .normal)
        confirmViewCancelButton.setTitle(Documents.cancelButtonTitle, for: .normal)
        successOkButton.setTitle(StoreToVault.okTitle, for: .normal)
        downloadButton.setTitle(StoreToVault.download, for: .normal)
        exitButton.setTitle(StoreToVault.exit, for: .normal)
        
        containerViewTitleLabel.text = StoreToVault.storeToDocumentsTitle
        documentNameLabel.text = StoreToVault.documentNameTitle
        documentNameValidationLabel1.text = StoreToVault.documetNameLengthValidation
        documentNameValidationLabel2.text = StoreToVault.documetNameSpecialCharacterValidation
        successLabel.text = StoreToVault.success
        successMessageLabel.text = StoreToVault.successMessage
        subTitleLabel.text = StoreToVault.storeToDocuments
        
        documentNameTextField.placeholder = StoreToVault.documentNamePlaceholder

        confirmView.isHidden = true
        containerView.isHidden = true
        successView.isHidden = true
        errorView.isHidden = true
        
        UITableView.registerCellWithIdentifier(cellIdentifier: documentCategoryCellIdentifier, tblVw: documentCategoryTableView)
    }

    private func getCategoryList() {
        displayActivityIndicatorView()
        viewModel.getCategoryList(successHandler: { [weak self] (_, _) in
            DispatchQueue.main.async {
                self?.hideActivityIndicatorView()
                self?.containerView.isHidden = false
                self?.documentCategoryTableView.reloadData()
            }
        }, failureHandler: { (_, error) in
            DispatchQueue.main.async {
                self.hideActivityIndicatorView()
                self.removeFromParent()
                self.view.removeFromSuperview()
                DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
            }
        })
    }

    private func onUploadDocumentStatus(with message: String) {

        self.documentNameTextField.text = ""

        confirmView.isHidden = true
        containerView.isHidden = true
        errorView.isHidden = true
        successView.isHidden = false

    }

    private func uploadDocument(with url: String, name: String, mnemonic: String ) {
        displayActivityIndicatorView()
        let serviceQueue = DispatchQueue(label: backGroundQueue, qos: .userInitiated)
        serviceQueue.sync {
        viewModel.uploadDocument(with: url, name: name, mnemonic: mnemonic, successHandler: { [weak self] (_, message) in

            DispatchQueue.main.async {
                self?.hideActivityIndicatorView()
                self?.onUploadDocumentStatus(with: message)
            }
            }, failureHandler: { [weak self] (_, error) in
                DispatchQueue.main.async {
                    self?.showError(for: error)
                }
            })
        }
    }
    
    private func showError(for error: Error) {
        hideActivityIndicatorView()
        let serverError = error as NSError
        if let downloadErrorCode = serverError.userInfo[dvFileDownloadErrorKey] as? String, let errorString = serverError.userInfo[dvServerErrorKey] as? String, downloadErrorCode == DVConstants.selfUploadLimitErrorCode {
//            print(downloadErrorCode)
//            print(errorString)
            confirmView.isHidden = true
            containerView.isHidden = true
            errorView.isHidden = false
            successView.isHidden = true
            
            errorContentLabel.text = errorString
        } else {
            DVCommon.showError(serviceError: error, withSuccess: nil, andFailure: nil)
        }
    }

    private func removeViews() {
        
        DVEventHandler.sharedInstance.postStoreToVaultResponse()
    }
    
    private func displayActivityIndicatorView() {
        DVCommon.displayActivityIndicatorView(with: LoaderMessages.defaultMessage)
    }
    
    private func hideActivityIndicatorView() {
        DVCommon.hideActivityIndicatorView()
    }

    @IBAction func cancelButtonTapped(_ sender: Any) {

        if DVCommon.isSignFlowFromDocuments {
            removeViews()
        } else {
            //To remove existing view
            self.removeFromParent()
            self.view.removeFromSuperview()
        }
    }

    @IBAction func confirmButtonTapped(_ sender: Any) {

        if let documentUrl = documentUrl, let documentName = documentNameTextField.text, !documentName.isEmpty, let documentMnemonic = selectedDocumentMnemonic {

            uploadDocument(with: documentUrl, name: documentName, mnemonic: documentMnemonic)
        }
    }

    @IBAction func confirmScreenCancelButtonTapped(_ sender: Any) {

        documentNameTextField.text = ""
        documentNameValidationLabel1.isHidden = false
        documentNameValidationLabel2.isHidden = false
        confirmViewHeightConstraint.constant = 353
        confirmView.isHidden = true
        containerView.isHidden = false
        successView.isHidden = true
        errorView.isHidden = true
    }

    @IBAction func successOkayButtonTapped(_ sender: Any) {

        removeViews()
    }
    
    @IBAction func downloadButtonTapped(_ sender: Any) {
        
        if let documentName = documentNameTextField.text {
            DVEventHandler.sharedInstance.downloadDocument(with: documentName + ".pdf")
        }
    }
    
    @IBAction func exitButtonTapped(_ sender: Any) {
        
        removeViews()
    }
}

extension DVStoreToVaultViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        let isDocumentNameScreeVisible = viewModel.isDocumentNameScreeVisible(for: indexPath.row)
        selectedDocumentName = viewModel.getCategoryName(for: indexPath.row)
        selectedDocumentMnemonic = viewModel.getCategoryMnemonic(for: indexPath.row)
        confirmViewTitleLabel.text = selectedDocumentName

        if let documentUrl = documentUrl {
            if isDocumentNameScreeVisible {
                confirmView.isHidden = !isDocumentNameScreeVisible
                containerView.isHidden = isDocumentNameScreeVisible
                successView.isHidden = isDocumentNameScreeVisible
                errorView.isHidden = isDocumentNameScreeVisible
            } else {
                uploadDocument(with: documentUrl, name: viewModel.getCategoryName(for: indexPath.row), mnemonic: viewModel.getCategoryMnemonic(for: indexPath.row))
            }
        }
    }
}

extension DVStoreToVaultViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfCategories()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let categoryCell = tableView.dequeueReusableCell(withIdentifier: documentCategoryCellIdentifier,
                                                    for: indexPath) as? DVStoreToDocumentCategoryCell {
            categoryCell.selectionStyle = UITableViewCell.SelectionStyle.none
            categoryCell.categoryLabel.text = viewModel.getCategoryName(for: indexPath.row)
            return categoryCell
        }
        return UITableViewCell()
    }
}

extension DVStoreToVaultViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let acceptedCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 جةىءئغظضذخثتشرقصفعسنملكيطحزوهدبا"
        let invertedChars = NSCharacterSet(charactersIn: acceptedCharacters).inverted
        let filtered = string.components(separatedBy: invertedChars).joined(separator: "")
        
        if let text = textField.text {
            let updatedText = (text as NSString).replacingCharacters(in: range, with: string)
            if updatedText.isEmpty {
                documentNameValidationLabel1.isHidden = false
                documentNameValidationLabel2.isHidden = false
                confirmViewHeightConstraint.constant = 353
                documentNameBottomView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x78849E)
            } else {
                documentNameValidationLabel1.isHidden = true
                documentNameValidationLabel2.isHidden = true
                confirmViewHeightConstraint.constant = 312
                documentNameBottomView.backgroundColor = UIColor.colorFromHex(rgbValue: 0x00A36A)
            }
        }
        
        if string.isEmpty || (string == filtered) && textField.text?.count ?? 0 < DVConstants.documentNameMaxLength {
            return true
        } else {
            return false
        }
    }
}
