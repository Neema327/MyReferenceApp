//
//  DVStoreToVaultCategoryList.swift
//  DigitalVaultFramework
//
//  Created by Saiaswanth on 7/29/19.
//

import Foundation

/*
 "docMnemonic": "DrivingLicense",
 "credentialType": "ISSUED",
 "typeOfEntity": "NA",
 "issuingEntity": "NA",
 "emiratesCode": "NA",
 "name": "Driving License",
 "language": "en"
*/

typealias DVStoreToVaultCategories = [DVStoreToVaultCategoryList]

struct DVStoreToVaultCategoryList: Codable {
    let name: String?
    let docMnemonic: String?
    let issuingEntity: String?
    let language: String?
    let credentialType: String?
    let typeOfEntity: String?
    let emiratesCode: String?

    enum CodingKeys: String, CodingKey {
        case name
        case docMnemonic
        case issuingEntity
        case language
        case credentialType
        case typeOfEntity
        case emiratesCode
    }
}

// MARK: DVSelfSignedCredential convenience inizzzztializers and mutators

extension DVStoreToVaultCategoryList {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVStoreToVaultCategoryList.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func with(
        name: String?? = nil,
        docMnemonic: String?? = nil,
        issuingEntity: String?? = nil,
        language: String?? = nil,
        credentialType: String?? = nil,
        typeOfEntity: String?? = nil,
        emiratesCode: String?? = nil
        ) -> DVStoreToVaultCategoryList {
        return DVStoreToVaultCategoryList(
            name: name ?? self.name,
            docMnemonic: docMnemonic ?? self.docMnemonic,
            issuingEntity: issuingEntity ?? self.issuingEntity,
            language: language ?? self.language,
            credentialType: credentialType ?? self.credentialType,
            typeOfEntity: typeOfEntity ?? self.typeOfEntity,
            emiratesCode: emiratesCode ?? self.emiratesCode
        )
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}

extension Array where Element == DVStoreToVaultCategories.Element {
    init(data: Data) throws {
        self = try newJSONDecoder().decode(DVStoreToVaultCategories.self, from: data)
    }

    init(_ json: String, using encoding: String.Encoding = .utf8) throws {
        guard let data = json.data(using: encoding) else {
            throw NSError(domain: "JSONDecoding", code: 0, userInfo: nil)
        }
        try self.init(data: data)
    }

    init(fromURL url: URL) throws {
        try self.init(data: try Data(contentsOf: url))
    }

    func jsonData() throws -> Data {
        return try newJSONEncoder().encode(self)
    }

    func jsonString(encoding: String.Encoding = .utf8) throws -> String? {
        return String(data: try self.jsonData(), encoding: encoding)
    }
}
