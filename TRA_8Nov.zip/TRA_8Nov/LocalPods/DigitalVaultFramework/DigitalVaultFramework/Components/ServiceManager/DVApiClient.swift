// DVServiceManager.swift
// DigitalVaultAppSample
//
//  Created by MSP on 18/07/19.
//  Copyright © 2019 TRA. All rights reserved.
// swiftlint:disable line_length

import PromiseKit

class DVApiClient {
    var dataTask: URLSessionDataTask?

    public func cancel() {
        self.dataTask?.cancel()
    }
    func fetchData<T: Codable>(_ value: T?, serverURL: String, headerParams: HeaderParams, parameters: RequestParams, method: HttpMethod, completion: @escaping (Data?, HTTPURLResponse?, Error?) -> Void) {
//url encoding
        let expectedCharSet = NSCharacterSet.urlQueryAllowed
        guard let allowedURL = serverURL.addingPercentEncoding(withAllowedCharacters: expectedCharSet) else {
            return
        }
        guard let unwrappedURL = URL(string: allowedURL) else {
            return
        }

        //let url = URL(string: serverURL)
        let session = URLSession.shared
       // guard let unwrappedURL = url else { print("Error unwrapping URL"); return }

        var request = URLRequest(url: unwrappedURL)
        request.httpMethod = method.rawValue

        if headerParams.count > 0 {
            for (key, value) in headerParams {
                request.addValue(value, forHTTPHeaderField: key)
            }
        }

        request.timeoutInterval = timeOutInterval
        var jsonData = Data()
        let jsonEncoder = JSONEncoder()

        let dateFormatter = DateFormatter()
        dateFormatter.calendar = Calendar(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        jsonEncoder.dateEncodingStrategy = .formatted(dateFormatter)

        do {
            if let val = value {
                jsonData = try jsonEncoder.encode(val)
                let jsonString = String(data: jsonData, encoding: .utf8)!
                request.httpBody = jsonString.data(using: .utf8)
            } else {
                if parameters.count > 0 {
                    request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
                }
            }
        } catch {
//            print("Error deserializing JSON: \(error)")
            completion(nil, nil, error)
        }

        self.dataTask = session.dataTask(with: request) { (data, response, error) in
//            print("Url: \(unwrappedURL), Fetch Data: \(data), Response: \(response as? HTTPURLResponse), error: \(error)")
            
            if let httpResponse = response as? HTTPURLResponse {
//                print("fetch data: \(data)")
//                print("fetch Response: \(httpResponse)")
//                print("fetch Error: \(error)")
                if httpResponse.statusCode == DVStatusCode.success.rawValue {
                    self.dataTask?.cancel()
                    completion(data, response as? HTTPURLResponse, error)
                } else {
                    self.dataTask?.cancel()
                    let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                    completion(data, response as? HTTPURLResponse, serverError)
                }
            } else {
                self.dataTask?.cancel()
                let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                completion(data, response as? HTTPURLResponse, serverError)
            }
        }
        self.dataTask?.resume()
    }
    func submitData(serverURL: String, headerParams: HeaderParams, parameters: RequestArrayParams, method: HttpMethod, completion: @escaping (Data?, HTTPURLResponse?, Error?) -> Void) {
//url encoding
        let expectedCharSet = NSCharacterSet.urlQueryAllowed
        guard let allowedURL = serverURL.addingPercentEncoding(withAllowedCharacters: expectedCharSet) else {
            return
        }
        guard let unwrappedURL = URL(string: allowedURL) else {
            return
        }
        //let url = URL(string: serverURL)
        let session = URLSession.shared
        //guard let unwrappedURL = url else { print("Error unwrapping URL"); return }

        var request = URLRequest(url: unwrappedURL)
        request.httpMethod = method.rawValue

        if headerParams.count > 0 {
            for (key, value) in headerParams {
                request.addValue(value, forHTTPHeaderField: key)
            }
        }

        request.timeoutInterval = timeOutInterval
//[String: Any] can't be encoded so mapping to model class in case of Add/ Replace document
        if let vcidString = parameters["vcid"] as? String {
            let model = DVPresentmentAddModel(vcId: vcidString)
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            do {
                let jsonData = try encoder.encode(model)
                request.httpBody = jsonData

            } catch {
//                print(error.localizedDescription)
                completion(nil, nil, NSError.init())
            }
        } else {
            do {
                if parameters.count > 0 {
                    request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
                }
            } catch {
//                print("Error deserializing JSON: \(error)")
                completion(nil, nil, error)
            }
        }
        self.dataTask = session.dataTask(with: request) { (data, response, error) in
//            print("Url: \(unwrappedURL), Submit Data: \(data), Response: \(response as? HTTPURLResponse), error: \(error)")
            
            if let httpResponse = response as? HTTPURLResponse {
//                print("submit data: \(data)")
//                print("submit Response: \(httpResponse)")
//                print("submit Error: \(error)")
                if httpResponse.statusCode == DVStatusCode.success.rawValue {
                    self.dataTask?.cancel()
                    completion(data, response as? HTTPURLResponse, error)
                } else {
                    self.dataTask?.cancel()
                    let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                    completion(data, response as? HTTPURLResponse, serverError)
                }
            } else {
                self.dataTask?.cancel()
                let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                completion(data, response as? HTTPURLResponse, serverError)
            }
        }
        self.dataTask?.resume()
    }

    func fetchAuthData<T: Codable>(_ value: T?, serverURL: String, headerParams: HeaderParams, parameters: RequestParams, method: HttpMethod, completion: @escaping (Data?,String?, Error?) -> Void) {
        let url = URL(string: serverURL)
        let session = URLSession.shared
        guard let unwrappedURL = url else { return }

        var request = URLRequest(url: unwrappedURL)
        request.httpMethod = method.rawValue

        if headerParams.count > 0 {
            for (key, value) in headerParams {
                request.addValue(value, forHTTPHeaderField: key)
            }
        }

        request.timeoutInterval = timeOutInterval
        var jsonData = Data()
        let jsonEncoder = JSONEncoder()

        let dateFormatter = DateFormatter()
        dateFormatter.calendar = Calendar(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        jsonEncoder.dateEncodingStrategy = .formatted(dateFormatter)

        do {
            if let val = value {
                jsonData = try jsonEncoder.encode(val)
                let jsonString = String(data: jsonData, encoding: .utf8)!
                request.httpBody = jsonString.data(using: .utf8)
            } else {
                if parameters.count > 0 {
                    request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
                }
            }
        } catch {
//            print("Error deserializing JSON: \(error)")
            completion(nil, nil, error)
        }

        self.dataTask = session.dataTask(with: request) { (data, response, error) in
           // print("response", response!)
//            print("Auth data: \(data)")
//            print("Auth Response: \(response)")
//            print("Auth Error: \(error)")
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode == DVStatusCode.authCode.rawValue {
                    var bearerToken = ""
                    if let httpResponse = response as? HTTPURLResponse {
                        if let accessToken = httpResponse.allHeaderFields[authorization] as? String {
                            bearerToken = accessToken
                            self.dataTask?.cancel()
                            completion(nil, bearerToken, nil)
                        } else {
                            self.dataTask?.cancel()
                            let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                            completion(nil, nil, serverError)
                        }
                    } else {
                        self.dataTask?.cancel()
                        completion(nil, nil, error)
                    }
                } else {
                    self.dataTask?.cancel()
                    let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                    completion(data, nil, serverError)
                }
            } else {
                self.dataTask?.cancel()
                let serverError:NSError? =  self.createErrorObject(jsonData: data, urlReponse: response as? HTTPURLResponse, error: error)
                completion(data, nil, serverError)
            }
        }
        self.dataTask?.resume()
    }
    
    func createErrorObject(jsonData: Data?, urlReponse:HTTPURLResponse?, error:Error?) -> NSError {
        if let responseData = jsonData , let response = urlReponse {
            do {
                let errorModel = try DVServerError(data: responseData)//Decode the error json
//                print("Error Model: \(errorModel)")
                let error = NSError(domain: dvErrorDomain, code: response.statusCode, userInfo: [dvServerErrorKey: errorModel.message ?? dvServerErrorMessage, dvFileDownloadErrorKey: errorModel.code])
                return error
            } catch {
               let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
                return error
            }
        }
        var  errorCode:Int  = DVStatusCode.serverError.rawValue
        if let serviceError = error as NSError? {
            
            if serviceError.code == URLError.Code.notConnectedToInternet.rawValue {
                let updatedServiceError  = NSError(domain: dvErrorDomain, code: serviceError.code, userInfo: [dvServerErrorKey:  dvNoNetworkErrorMessage])
                return updatedServiceError
            }
            
            if let response = urlReponse {
                errorCode = response.statusCode
            }
        }
        let serviceError = NSError(domain: dvErrorDomain, code: errorCode, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
        return serviceError
    }

}
