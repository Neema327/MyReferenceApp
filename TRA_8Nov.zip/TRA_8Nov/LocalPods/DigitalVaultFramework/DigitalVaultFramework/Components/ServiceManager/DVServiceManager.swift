//  DVServiceManager.swift
//  DigitalVaultAppSample
//
//  Created by MSP on 18/07/19.
//  Copyright © 2019 TRA. All rights reserved.
// swiftlint:disable line_length
import PromiseKit

class DVServiceManager {
    
    var dataTask: URLSessionDataTask?
    func getCurrentTask() -> URLSessionDataTask? {
        return dataTask
    }
    func fetchData<T: Codable>(_ value: T?, serverURL: String, headerParams: HeaderParams, parameters: RequestParams, method: HttpMethod, completion: @escaping (Data?, Error?) -> Void) {
        
        var updatedServerUrl = serverURL
        if DVConstants.uaepassArabicLocalization {
            updatedServerUrl = prepareArabicUrl(with: updatedServerUrl)
        }
//        print("Fetch Data: \(updatedServerUrl)")
        if DVConstants.uaepassDemoIntegration || DVCommon.isPresentmentAppToAppFlow {
            
            var authHeaderParams: HeaderParams = [:]
            let authReqParameters: RequestParams = [:]
            //authheaderParams[content] = ContentType.json.rawValue
            authHeaderParams[authorization] = DVCommon.presentmentToken
            if DVConstants.uaepassDemoIntegration {
                authHeaderParams[authorization] = DVCommon.authToken
            }
            let  authApiClient = DVApiClient()
            
            authApiClient.fetchAuthData(nil as DVSelfSignedCredential?, serverURL: baseURL + apiVersion+EndPoint.login.rawValue, headerParams: authHeaderParams, parameters: authReqParameters, method: HttpMethod.POST) {(data, bearerToken, respError)  in
                if let token = bearerToken {
                    DVCommon.bearerToken = token
                    var newHeaderParams = headerParams
                    newHeaderParams[authorization] = DVCommon.bearerToken
                    let  apiClient = DVApiClient()
                    apiClient.fetchData(nil as DVSelfSignedCredential?, serverURL: (updatedServerUrl), headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, urlresponse, respError) in
                        
                        if let jsonData = jsonResponse, let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue {
                            completion(jsonData, respError)
                        } else {
                            completion(nil, respError)
                        }
                    }
                } else {
                    
                    if DVCommon.isPresentmentAppToAppFlow {
                        completion(nil, respError)
                    } else {
                        
                        self.retryAuthService(completion: { (bearerToken, error) in
                            
                            if let token = bearerToken {
                                DVCommon.bearerToken = token
                                var newHeaderParams = headerParams
                                newHeaderParams[authorization] = DVCommon.bearerToken
                                let  apiClient = DVApiClient()
                                apiClient.fetchData(nil as DVSelfSignedCredential?, serverURL: (updatedServerUrl), headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, urlresponse, respError) in
                                    
                                    if let jsonData = jsonResponse, let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue {
                                        completion(jsonData, respError)
                                    } else {
                                        completion(nil, respError)
                                    }
                                }
                            } else {
                                completion(nil, error)
                            }
                        })
                    }
                }
            }
        } else {
            let  apiClient = DVApiClient()
            apiClient.fetchData(nil as DVSelfSignedCredential?, serverURL: (updatedServerUrl), headerParams: headerParams, parameters: parameters, method: method) {(jsonResponse, urlresponse, respError) in
                
                if let jsonData = jsonResponse, let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue {
                    completion(jsonData, respError)
                } else {
                    
                    if let httpResponse = urlresponse {
                        if httpResponse.statusCode == DVStatusCode.loginFailed.rawValue {
                            
                            var authHeaderParams: HeaderParams = [:]
                            let authReqParameters: RequestParams = [:]
                            //authheaderParams[content] = ContentType.json.rawValue
                            authHeaderParams[authorization] = DVCommon.authToken
                            let  authApiClient = DVApiClient()
                            
                            authApiClient.fetchAuthData(nil as DVSelfSignedCredential?, serverURL: baseURL + apiVersion+EndPoint.login.rawValue, headerParams: authHeaderParams, parameters: authReqParameters, method: HttpMethod.POST) { (_, bearerToken, respError) in
//                                print("Service Manager bearer token: \(bearerToken) ")
//                                print("Service Manager respError: \(respError) ")
                                if let token = bearerToken {
                                    DVCommon.bearerToken = token
                                    var newHeaderParams = headerParams
                                    newHeaderParams[authorization] = DVCommon.bearerToken
                                    let  apiClient = DVApiClient()
                                    apiClient.fetchData(nil as DVSelfSignedCredential?, serverURL: (updatedServerUrl), headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, urlresponse, respError) in
                                        
                                        if let jsonData = jsonResponse, let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue {
                                            completion(jsonData, respError)
                                        } else {
                                            completion(nil, respError)
                                        }
                                        
                                    }
                                } else {
                                    
                                    self.retryAuthService(completion: { (bearerToken, error) in
                                        
                                        if let token = bearerToken {
                                            DVCommon.bearerToken = token
                                            var newHeaderParams = headerParams
                                            newHeaderParams[authorization] = DVCommon.bearerToken
                                            let  apiClient = DVApiClient()
                                            apiClient.fetchData(nil as DVSelfSignedCredential?, serverURL: (updatedServerUrl), headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, urlresponse, respError) in
                                                
                                                if let jsonData = jsonResponse, let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue {
                                                    completion(jsonData, respError)
                                                } else {
                                                    completion(nil, respError)
                                                }
                                                
                                            }
                                        } else {
                                            completion(nil, error)
                                        }
                                    })
                                }
                            }
                        } else {
                            completion(nil, respError)
                        }
                    } else {
                        completion(nil, respError)
                    }
                }
            }
        }
    }
    
    func submitData(serverURL: String, headerParams: HeaderParams, parameters: RequestArrayParams, method: HttpMethod, completion: @escaping (Data?, HTTPURLResponse?, Error?) -> Void) {
        var updatedServerUrl = serverURL
        if DVConstants.uaepassArabicLocalization {
            updatedServerUrl = prepareArabicUrl(with: updatedServerUrl)
        }
        //        print("Submit Data: \(updatedServerUrl)")
        let  apiClient = DVApiClient()
        var updatedHeaderParams = headerParams
        updatedHeaderParams[content] = ContentType.json.rawValue
        
        apiClient.submitData(serverURL: updatedServerUrl, headerParams: updatedHeaderParams, parameters: parameters, method: method) { (jsonData, urlresponse, respError) in
            
            if let httpResponse = urlresponse, httpResponse.statusCode == DVStatusCode.success.rawValue, let jsonData = jsonData {
                completion( jsonData, httpResponse, respError)
            } else {
                if let httpResponse = urlresponse {
                    if httpResponse.statusCode == DVStatusCode.loginFailed.rawValue {
                        
                        var authHeaderParams: HeaderParams = [:]
                        let authReqParameters: RequestParams = [:]
                        authHeaderParams[authorization] = DVCommon.authToken
                        let  authApiClient = DVApiClient()
                        
                        authApiClient.fetchAuthData(nil as DVSelfSignedCredential?, serverURL: baseURL + apiVersion+EndPoint.login.rawValue, headerParams: authHeaderParams, parameters: authReqParameters, method: HttpMethod.POST) {(data, bearerToken, respError) in
                            if let token = bearerToken {
                                DVCommon.bearerToken = token
                                var newHeaderParams = headerParams
                                newHeaderParams[authorization] = DVCommon.bearerToken
                                newHeaderParams[content] = ContentType.json.rawValue
                                let  apiClient = DVApiClient()
                                apiClient.submitData(serverURL: serverURL, headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, _, respError) in
                                    if let jsonData = jsonResponse {
                                        completion(jsonData, nil, respError)
                                    } else {
                                        completion(nil, nil, respError)
                                    }
                                }
                            } else {
                                if DVCommon.isPresentmentAppToAppFlow {
                                    completion(nil, nil, respError)
                                } else {
                                    self.retryAuthService(completion: { (bearerToken, error) in
                                        
                                        if let token = bearerToken {
                                            DVCommon.bearerToken = token
                                            var newHeaderParams = headerParams
                                            newHeaderParams[authorization] = DVCommon.bearerToken
                                            newHeaderParams[content] = ContentType.json.rawValue
                                            let  apiClient = DVApiClient()
                                            apiClient.submitData(serverURL: serverURL, headerParams: newHeaderParams, parameters: parameters, method: method) {(jsonResponse, _, respError) in
                                                if let jsonData = jsonResponse {
                                                    completion(jsonData, nil, respError)
                                                } else {
                                                    completion(nil, nil, respError)
                                                }
                                            }
                                        } else {
                                            completion(nil, nil, error)
                                        }
                                    })
                                }
                            }
                        }
                    } else {
                        completion(nil, nil, respError)
                    }
                } else {
                    completion(nil, nil, respError)
                }
            }
        }
    }
    
    func retryAuthService( completion: @escaping (String?, Error?) -> Void) {
//        print("Retry Test Service")
        //Wait and get get UAEPass access token if required
        if let currentAccessToken = DVEventHandler.sharedInstance.getRenewedAccessToken() {
            if DVConstants.uaepassIntegerationEnabled {
                DVCommon.accessToken = currentAccessToken
                DVCommon.authToken = "accessToken " + currentAccessToken
//                print("Retry Test Service: New access token")
                
                var authHeaderParams: HeaderParams = [:]
                let authReqParameters: RequestParams = [:]
                authHeaderParams[authorization] = DVCommon.authToken
                let  authApiClient = DVApiClient()
                
                authApiClient.fetchAuthData(nil as DVSelfSignedCredential?, serverURL: baseURL + apiVersion+EndPoint.login.rawValue, headerParams: authHeaderParams, parameters: authReqParameters, method: HttpMethod.POST) {(data, bearerToken, respError) in
                    if let token = bearerToken {
//                        print("Retry Test Bearer token: \(token)")
                        DVCommon.bearerToken = token
                        completion(token, respError)
                    } else {
                        completion(nil, respError)
                    }
                }
            }
        } else {
//            print("Retry Test Service: Failed")
            let error = NSError(domain: dvErrorDomain, code: DVStatusCode.serverError.rawValue, userInfo: [dvServerErrorKey:  dvServerErrorMessage])
            completion(nil, error)
        }
    }
    
    func cancel() {
    }
    
    func prepareArabicUrl(with url: String) -> String {
        var updatedServerUrl = url
        var isArabicNormalStringAppend = true  // &lang=ar
        let notificationRelatedService = updatedServerUrl.contains("/alert-messages/")
        if notificationRelatedService {
            let unreadCountFound = updatedServerUrl.contains("/alert-messages/unreadcount")
            let notificationListFound = updatedServerUrl.contains("/alert-messages/?size=10&page=")
            let notificationStateUpdate = updatedServerUrl.contains("state=READ")
            
            if unreadCountFound {
                return updatedServerUrl
            }
            
            if !(unreadCountFound == true || notificationListFound == true) {
                isArabicNormalStringAppend = false
            }
            
            if notificationStateUpdate {
                isArabicNormalStringAppend = true
            }
        }
        let credentialDetailRelatedService = updatedServerUrl.contains("/credentials/")
        if credentialDetailRelatedService {
            let docsListFetchService = updatedServerUrl.contains("/credentials/?type=")
            if docsListFetchService {
                isArabicNormalStringAppend = true
            } else {
                isArabicNormalStringAppend = false
            }
        }
        
        let credentialRequestRelatedService = updatedServerUrl.contains("/credential-requests/")
        if credentialRequestRelatedService {
            isArabicNormalStringAppend = false
        }
        
        let replaceDocumentRelatedService = updatedServerUrl.contains("/documents/")
        if replaceDocumentRelatedService {
            isArabicNormalStringAppend = false
        }
        
        if isArabicNormalStringAppend {
            updatedServerUrl = updatedServerUrl + langArabic
        } else {
            updatedServerUrl = updatedServerUrl + langArabicNotificationDetail
        }
        
        return updatedServerUrl
    }
    
}
