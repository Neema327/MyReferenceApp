//
//  ViewController.swift
//  SampelServiceProviderApp
//
//  Created by Saiaswanth on 9/2/19.
//  Copyright © 2019 Saiaswanth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func launchUaePassButtonTapped(_ sender: Any) {

        let successUrl = "providerapp://success"
        let failureUrl = "providerapp://failure"
        let urlString = "uaepass://?action=PRESENTMENT&clientid=UAEPASSCLIENTID&accestoken=2a5b592bc38c7b7b3ca2033ff9b3860c68f13ec92fa01c74729a951bf3f434ff&requesteid=4570612930&successurl=\(successUrl)&failureurl=\(failureUrl)"

        if let url = URL(string: urlString) {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }

}
