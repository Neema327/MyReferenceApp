//
//  Service.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 12/27/18.
//  Copyright © 2018 Waqas Qadeer Soomro. All rights reserved.
//

import Foundation
import Alamofire

class Service {

    static let shared = Service()
    private init() {}

    // MARK: - Get UAE Pass Token
    func getUAEPassToken(code: String, completion: @escaping (String) -> Void, onError: @escaping (ServiceErrorType) -> Void) {
        let path: String = UAEPassConfiguration.getServiceUrlForType(serviceType: .token)
        let parameters: [String: String] = ["grant_type": "authorization_code", "redirect_uri": UAEPAssParams.redirectUriLogin.get(), "code": code]

        let authUser = Router.shared.uaePassConfig.clientID
        let authPass = Router.shared.uaePassConfig.clientPass
        let authStr = "\(authUser):\(authPass)"
        let authData = authStr.data(using: .ascii)!
        let authValue = "Basic \(authData.base64EncodedString(options: []))"

        let headers = ["Authorization": authValue,
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded"]
        Alamofire.request(path, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: headers).responseString { response in
            if response.result.error != nil {
                onError(.unAuthorizedUAEPass)
            }
            if let data = response.data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let responseModel = try jsonDecoder.decode(UAEPassToken.self, from: data)

                    if responseModel.error != nil {
                        if responseModel.error == "invalid_request" {
                            onError(.unAuthorizedUAEPass)
                        } else {
                            onError(.unknown)
                        }
                    } else {
                        Router.shared.uaePassToken = responseModel.accessToken ?? nil
                        print("### UAE Pass Token : \(responseModel.accessToken ?? "")")
                        completion(responseModel.accessToken ?? "")

                    }
                } catch {
                    debugPrint(error)
                    onError(.unAuthorizedUAEPass)
                }
            } else {
                completion("")
            }
        }
    }

    // MARK: - Get UAE Pass User Profile
    func getUAEPassUserProfile(token: String, completion: @escaping (UAEPassUserProfile?) -> Void, onError: @escaping (ServiceErrorType) -> Void) {
        let path: String = UAEPassConfiguration.getServiceUrlForType(serviceType: .userProfileURL)
        let headers = ["Authorization": "Bearer \(token)",
                       "Accept": "application/json",
                       "Content-Type": "application/x-www-form-urlencoded"]
        Alamofire.request(path, method: .get, encoding: URLEncoding.httpBody, headers: headers).responseString { response in
            if response.result.error != nil {
                onError(.unAuthorizedUAEPass)
            }
            if let data = response.data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let responseModel = try jsonDecoder.decode(UAEPassUserProfile.self, from: data)
                         print("### UAE Pass User email : \(responseModel.email ?? "")")
                        completion(responseModel)

                } catch {
                    debugPrint(error)
                    onError(.unAuthorizedUAEPass)
                }
            } else {
                completion(nil)
            }
        }
    }

    // MARK: - Downloading the document -
    func downloadPdf(pdfName: String, uaePassToken: String, completion: @escaping (String, Bool) -> Void, onError: @escaping (ServiceErrorType) -> Void) {
        let downloadUrl: String = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
        let destinationPath: DownloadRequest.DownloadFileDestination = { _, _ in
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let fileURL = documentsURL.appendingPathComponent(pdfName)
                return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }

        print(downloadUrl)
        Alamofire.download(downloadUrl, method: .get, to: destinationPath)
            .downloadProgress { progress in
                print("Download progress : \(progress)")
            }
            .responseData { response in
                print("response: \(response)")
                if response.response?.statusCode == 401 {
                    onError(.unAuthorizedUAEPass)
                    return
                }
                switch response.result {
                case .success:
                    if response.destinationURL != nil, let filePath = response.destinationURL?.absoluteString {
                        completion(filePath, true)
                    }
                case .failure:
                    completion("", false)
                }
        }
    }

    func downloadSignedPdf(pdfID: String, pdfName: String, completion: @escaping (String, Bool) -> Void, onError: @escaping (ServiceErrorType) -> Void) {
        let downloadUrl: String = "https://qa-id.uaepass.ae/trustedx-resources/esignsp/v2/documents/\(pdfID)/content"
        let destinationPath: DownloadRequest.DownloadFileDestination = { _, _ in
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = documentsURL.appendingPathComponent(pdfName)
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }

        let uaePassSigningToken = UserDefaults.standard.string(forKey: "UAEPassSigningBearer") ?? ""
        let headers: HTTPHeaders = [
            "Authorization": "Bearer \(uaePassSigningToken)"
        ]
        print(downloadUrl)
        Alamofire.download(downloadUrl, method: .get, headers: headers, to: destinationPath)
            .downloadProgress { progress in
                print("Download progress : \(progress)")
            }
            .responseData { response in
                print("response: \(response)")
                if response.response?.statusCode == 401 {
                    onError(.unAuthorizedUAEPass)
                    return
                }
                switch response.result {
                case .success:
                    if response.destinationURL != nil, let filePath = response.destinationURL?.absoluteString {
                        completion(filePath, true)
                    }
                case .failure:
                    completion("", false)
                }
        }
    }

    func normalUAEPassRequest(requestData: UAEPassSigningRequest,
                              completion: @escaping (String?) -> Void,
                              onError: @escaping (ServiceErrorType) -> Void) {

        guard let urlRequest = self.buildUAEPASSSigningRequest(requestData: requestData) else {
            onError(.unknown)
            return
        }
        Alamofire.request(urlRequest).responseJSON { response in

            if let error = response.result.error {
                debugPrint(error)
                return
            }
            if let data = response.data {
                do {
                    let str = String(data: data, encoding: .utf8) ?? ""
                    print(str)
                    guard let serviceType = requestData.serviceType else {
                        return
                    }
                    let jsonDecoder = JSONDecoder()
                    switch serviceType {
                    case .token:
                        let responseModel = try jsonDecoder.decode(UAEPassToken.self, from: data)
                        UserDefaults.standard.set(responseModel.accessToken ?? "", forKey: "UAEPassSigningBearer")
                        completion("DONE")
                    case .deleteFile:
                        completion("DONE")
                    default:
                        break
                    }
                } catch { debugPrint(error)
                    onError(.optionaWrappingError)
                }
            }
        }
    }

    // MARK: - Uploading the document to UAE Pass -

    func uploadDocument(requestData: UAEPassSigningRequest, pdfName: String, completionHandler: @escaping(UploadSignDocumentResponse?, Bool) -> Void) {

        let url = UAEPassConfiguration.getServiceUrlForType(serviceType: .uploadFile)
        let token = UserDefaults.standard.string(forKey: "UAEPassSigningBearer") ?? ""

        var paramsProcess = requestData.processParams

        let headers: HTTPHeaders = [
            "Authorization": "Bearer \(token)",  /*in case you need authorization header */
            "Content-type": requestData.serviceType?.getContentType() ?? ""
        ]
        // swiftlint:disable next multiple_closures_with_trailing_closure
        Alamofire.upload(multipartFormData: { (multipartFormData) in

            let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let fileURL = URL(fileURLWithPath: documentsPath, isDirectory: true).appendingPathComponent(pdfName)
            do {
                paramsProcess?.finishCallbackUrl = HandleURLScheme.externalURLSchemeSuccess()
                let paramsJsonStrong = try JSONEncoder().encode(paramsProcess)
                let jsonString = String(data: paramsJsonStrong, encoding: .utf8)!
                multipartFormData.append(jsonString.data(using: String.Encoding.utf8)!, withName: "process" as String)
            } catch {
                print(error)
            }
            multipartFormData.append(fileURL, withName: "document")

        }, usingThreshold: UInt64.init(),
           to: url, method: .post,
           headers: headers) { (result) in
            switch result {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    if let data = response.data {
                        do {
                            let jsonDecoder = JSONDecoder()
                            let responseModel = try jsonDecoder.decode(UploadSignDocumentResponse.self, from: data)
                            let str = String(data: data, encoding: .utf8) ?? ""
                            print(str)
                            print("Succesfully uploaded")
                            completionHandler(responseModel, true)
                            return
                        } catch {
                            completionHandler(nil, false)
                        }
                    }
                    if response.error != nil {
                        completionHandler(nil, false)
                        return
                    }
                    completionHandler(nil, true)
                }
            case .failure(let error):
                print("Error in upload: \(error.localizedDescription)")
                completionHandler(nil, false)
            }
        }
    }

    func buildUAEPASSSigningRequest(requestData: UAEPassSigningRequest) -> URLRequest? {
        do {
            guard let serviceType = requestData.serviceType else {
                return nil
            }
            let path: String = UAEPassConfiguration.getServiceUrlForType(serviceType: serviceType)
            guard let url = URL(string: path) else {
                return nil
            }
            print(url)

            var urlRequest = URLRequest(url: url)
            urlRequest.httpMethod = serviceType.getRequestType()
            if let contentType = serviceType.getContentType() {
                urlRequest.setValue(contentType, forHTTPHeaderField: "Content-type")
            }

            let authUser = Router.shared.uaePassConfig.clientID
            let authPass = Router.shared.uaePassConfig.clientPass
            let authStr = "\(authUser):\(authPass)"
            let authData = authStr.data(using: .ascii)!
            let authValue = "Basic \(authData.base64EncodedString(options: []))"

            urlRequest.setValue(authValue, forHTTPHeaderField: "Authorization")
            let postData = NSMutableData(data: "grant_type=client_credentials".data(using: String.Encoding.utf8)!)
            postData.append("&scope=\(UAEPAssParams.signScope.get())".data(using: String.Encoding.utf8)!)
            urlRequest.httpBody = postData as Data

            debugPrint(urlRequest)
            return urlRequest
        }
    }
}
