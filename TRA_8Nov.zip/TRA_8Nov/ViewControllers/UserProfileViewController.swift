//
//  UserProfileViewController1.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 12/30/18.
//  Copyright © 2018 Waqas Qadeer Soomro. All rights reserved.
//

import NVActivityIndicatorView
import UIKit
import WebKit

@objc public class UserProfileViewController: UIViewController, NVActivityIndicatorViewable, UIDocumentInteractionControllerDelegate, WKNavigationDelegate {
    @IBOutlet var labelName: UILabel!
    @IBOutlet var labelEmail: UILabel!
    @IBOutlet var labelMobile: UILabel!
    @IBOutlet var labelDateOfBirth: UILabel!
    @IBOutlet var labelNationality: UILabel!

    @IBOutlet var webViewContainer: WKWebView!

    var userProfile: UAEPassUserProfile!
    @objc public var userToken: String!
    public var pdfName: String?
    public var pdfID: String?

    public override func viewDidLoad() {
        self.title = "Profile"
        self.labelName.text = self.userProfile.firstnameEN
        self.labelEmail.text = self.userProfile.email
        self.labelMobile.text = self.userProfile.mobile
        self.labelDateOfBirth.text = self.userProfile.dob
        self.labelNationality.text = self.userProfile.nationalityEN

        self.webViewContainer.isHidden = true
    }

    public func webView(_: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        var action: WKNavigationActionPolicy?
        defer {
            decisionHandler(action ?? .allow)
        }
        guard let urlString = navigationAction.request.mainDocumentURL?.absoluteString else { return }

        print(">>>> URL STRING : \(urlString)")
        if urlString.contains("error=access_denied") {
            stopAnimating()
            self.webViewContainer.isHidden = true
        } else if urlString.contains(UAEPAssParams.uaePassSchemeURL.get()) {
            let listItems = urlString.components(separatedBy: "successurl")
            if listItems.count > 0 {
                if let customScheme = listItems.first {
                    let paprelessSchemeSuccess = HandleURLScheme.externalURLSchemeSuccess()
                    let paprelessSchemeFail = HandleURLScheme.externalURLSchemeFail()
                    let urlScheme = "\(customScheme)successurl=\(paprelessSchemeSuccess)&failureurl=\(paprelessSchemeFail)&closeondone=true"
                    print("urlScheme: \(urlScheme)")
                    HandleURLScheme.openCustomApp(fullUrl: urlScheme)
                }
            }
        } else if urlString.contains("status=finished") {
            stopAnimating()
            self.webViewContainer.isHidden = true
            self.startAnimating(message: "Downloading signed PDF", type: .pacman)
            Router.shared.downloadSignedODF(pdfID: pdfID ?? "", pdfName: "SamplePDF.pdf")
        } else if urlString.contains("status=") {
            stopAnimating()
            self.webViewContainer.isHidden = true
        }
    }

    @IBAction func downloadFile(_ sender: Any) {
        // download and start signing
        print("download and start signing")
        let bundle = Bundle(for: type(of: self))
        guard let uaePassSigningParameters = ReadJSONHelper().getUAEPAssSigningParametersFrom(fileName: "testSignData", bundle) else { return }
        Router.shared.startSigningProcess(uaePassToken: userToken, signingParams: uaePassSigningParameters, pdfName: "SamplePDF.pdf")
    }

    @objc func loadUAEPASSWebView(stringURL: String) {
        self.webViewContainer.isHidden = false
        Router.shared.webView.frame = self.webViewContainer.frame
        self.webViewContainer.addSubview(Router.shared.webView)
        Router.shared.webView.navigationDelegate = self
        let url = URL(string: stringURL)
        Router.shared.webView.load(URLRequest(url: url!))
    }

    // MARK: - SHOW PDF FILE -
    func showPDFFile(fileURL: URL) {
        self.webViewContainer.isHidden = true
        let documentController = UIDocumentInteractionController(url: fileURL)
        documentController.delegate = self
        documentController.presentPreview(animated: true)
    }
    // MARK: - UIDocumentInteractionController delegates -
    public func documentInteractionControllerViewControllerForPreview(_: UIDocumentInteractionController) -> UIViewController {
        return self
    }
    @IBAction func launchDVScreen(_ sender: Any) {

        let frameworkLaunchVC = self.storyboard?.instantiateViewController(withIdentifier: "DVFramewokLaunchViewController") as? DVFramewokLaunchViewController
        if let frameworkLaunchVC = frameworkLaunchVC {
            frameworkLaunchVC.userProfile = userProfile
            frameworkLaunchVC.userAccessToken = userToken
            self.navigationController?.pushViewController(frameworkLaunchVC, animated: true)
        }
    }
}
