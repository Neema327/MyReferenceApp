//
//  DVFramewokLaunchViewController.swift
//  UaePassDemo
//
//  Created by Saiaswanth on 7/10/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import UIKit
import DigitalVaultFramework
import SwiftEventBus

enum DVFrameworkAPIResponse: Int {
    case notificationCount = 1
}

class DVFramewokLaunchViewController: UIViewController {

    var userProfile: UAEPassUserProfile!
    var userAccessToken: String!
    var nationality: String?
    var emiratesID: String?
    var uuid: String?

    var moduleDictionary = [String: AnyObject]()
    var apiDictionary = [String: Any]()

    @IBOutlet weak var alertLabel: UILabel!
    @IBOutlet weak var dvAlertView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        dvAlertView.isHidden = true

        //Sai: Need to  uncomment for using authentication with UAE Pass
//        nationality = userProfile.nationalityEN
//        emiratesID = userProfile.idn
//        uuid = userProfile.uuid

        moduleDictionary["accessToken"] = userAccessToken as AnyObject?
        moduleDictionary["navigationController"] = self.navigationController
        moduleDictionary["emiratesId"] = emiratesID as AnyObject?
        moduleDictionary["uuid"] = uuid as AnyObject?
        moduleDictionary["currentLanguage"] = "en" as AnyObject?

        launchSignScreen()
        displayAlert()
        launchPinScreen()
        fetchNewAccessToken()
        storeToVaultResponse()
        getNotificationUnreadCount()
    }

    // To launch sign screen after getting an event from DV
    private func launchSignScreen() {

        SwiftEventBus.onMainThread(self, name: "UP_LaunchSignScreen") { [weak self] _ in

            self?.navigationController?.popToViewController(self!, animated: true)
            self?.showAlert(title: "Sign Screen", message: "Sign Screen Launched")
        }
    }

    // To Display an alert after getting an event from DV
    private func displayAlert() {

        SwiftEventBus.onMainThread(self, name: "UP_DisplayAlert") { [weak self] result in

            if let result = result, let alertDictionary = result.userInfo, let message = alertDictionary["message"] as? String {
                self?.navigationController?.popToViewController(self!, animated: true)
                self?.showAlert(title: "Alert", message: message)
            }
        }
    }

    // To Launch pin screen after getting an event from DV
    private func launchPinScreen() {

        SwiftEventBus.onMainThread(self, name: "UP_ShowPinScreen") { [weak self] _ in

            self?.navigationController?.popToViewController(self!, animated: true)
            self?.showAlert(title: "Pin Screen", message: "Pin Screen Launched")
        }
    }

    //Send an event related to pin confirmation to DV
    private func postPinConfirmationStatus() {
        var pinConfirmationStatus = [String: String]()
        pinConfirmationStatus["stausCode"] = "200"
        pinConfirmationStatus["statusMessage"] = "Pin confirmation successful"
        SwiftEventBus.post("DV_PinConfirmation", userInfo: pinConfirmationStatus)
    }

    // To fetch new access token after getting an event from DV
    private func fetchNewAccessToken() {

        var accessTokenResponseDictionary = [String: String]()

        SwiftEventBus.onMainThread(self, name: "UP_GetNewAccessToken") { _ in

            accessTokenResponseDictionary["accessToken"] = "NewAcessToken"
            accessTokenResponseDictionary["stausCode"] = "200"
            accessTokenResponseDictionary["statusMessage"] = "Pin confirmation successful"
            SwiftEventBus.post("DV_NewAccessToken", userInfo: accessTokenResponseDictionary)
        }

        SwiftEventBus.onMainThread(self, name: "UP_GetRenewedAccessToken") { _ in

            accessTokenResponseDictionary["accessToken"] = "NewAcessToken"
            accessTokenResponseDictionary["stausCode"] = "200"
            accessTokenResponseDictionary["statusMessage"] = "Pin confirmation successful"
            SwiftEventBus.post("DV_GetRenewedAccessToken", userInfo: accessTokenResponseDictionary)
        }
    }

    //To show store to vault response
    func storeToVaultResponse() {

        SwiftEventBus.onMainThread(self, name: "UP_StoreToVaultResponse") { [weak self] result in

            if let result = result, let storeToVaultResponseDictionary = result.userInfo, let message =
            storeToVaultResponseDictionary["statusMessage"] as? String {

                self?.navigationController?.popToViewController(self!, animated: true)
                self?.showAlert(title: "Store to Vault", message: message)
            }
        }
    }

    private func getNotificationUnreadCount() {

        SwiftEventBus.onMainThread(self, name: "UP_NotificationUnreadCount") { [weak self] result in
            if let result = result, let notificationUnreadCountDictionary = result.userInfo, let count = notificationUnreadCountDictionary["count"] as? Int {

                let notificationUnreadCount = String(count)
                self?.showAlert(title: "Notification Count", message: "Notfication unread count is \(notificationUnreadCount)")
            }
        }
    }

    @IBAction func requestCredentialButtonTapped(_ sender: Any) {
        moduleDictionary["moduleId"] = 1 as AnyObject
        postNotification(for: "DV_LoadModule", with: moduleDictionary)
    }

    @IBAction func notificationButtonTapped(_ sender: Any) {

        SwiftEventBus.onMainThread(self, name: "UP_LoadNotificationView") { [weak self] result in

            if let result = result, let viewDictionary = result.userInfo, let notificationController = viewDictionary["viewController"] as? UIViewController {

                self?.navigationController?.pushViewController(notificationController, animated: true)
            }
        }

        moduleDictionary["moduleId"] = 2 as AnyObject
        moduleDictionary["params"] = ["notificationId": "<Push notification ID>"] as AnyObject
        postNotification(for: "DV_LoadModule", with: moduleDictionary)
    }

    @IBAction func issuedDocumentsButtonTapped(_ sender: Any) {

        SwiftEventBus.onMainThread(self, name: "UP_LoadDocumentsView") { [weak self] result in

            if let result = result, let viewDictionary = result.userInfo, let documentsController = viewDictionary["viewController"] as? UIViewController {

                self?.navigationController?.pushViewController(documentsController, animated: true)
            }
        }

        moduleDictionary["moduleId"] = 3 as AnyObject
        postNotification(for: "DV_LoadModule", with: moduleDictionary)
    }

    @IBAction func myQRCodeButtonTapped(_ sender: Any) {
        moduleDictionary["moduleId"] = 4 as AnyObject
        let profileImage = UIImage(named: "Login_Bottom")

         moduleDictionary["params"] = ["profileImage": profileImage] as AnyObject
        postNotification(for: "DV_LoadModule", with: moduleDictionary)
    }

    @IBAction func selfSignButtonTapped(_ sender: Any) {
        moduleDictionary["moduleId"] = 5 as AnyObject
        postNotification(for: "DV_LoadModule", with: moduleDictionary)
    }

    @IBAction func pinConfirmationButtonTapped(_ sender: Any) {
        postPinConfirmationStatus()
    }

    @IBAction func storeToVaultButtonTapped(_ sender: Any) {
        var storeToVaultRequestDict = [String: Any]()

        storeToVaultRequestDict["accessToken"] = userAccessToken as AnyObject?
        storeToVaultRequestDict["documentUrl"] = "www.google.com"
        storeToVaultRequestDict["currentViewController"] = self
        storeToVaultRequestDict["emiratesId"] = emiratesID as AnyObject?
        storeToVaultRequestDict["uuid"] = uuid as AnyObject?
        storeToVaultRequestDict["currentLanguage"] = "en" as AnyObject?
        SwiftEventBus.post("DV_StoreToVaultRequest", userInfo: storeToVaultRequestDict)
    }

    @IBAction func getNotificationCountButtonTapped(_ sender: Any) {
        var notificationCountDictionary = [String: Any]()
        notificationCountDictionary["accessToken"] = userAccessToken as AnyObject?
        notificationCountDictionary["emiratesId"] = emiratesID as AnyObject?
        notificationCountDictionary["uuid"] = uuid as AnyObject?

        SwiftEventBus.post("DV_FetchNotificationCount", userInfo: notificationCountDictionary)
    }

    @IBAction func alertCloseButtonTapped(_ sender: Any) {
        dvAlertView.isHidden = true
    }

    private func postNotification(for eventName: String, with dataDictionary: [String: AnyObject]) {

        SwiftEventBus.post(eventName, userInfo: dataDictionary)
    }

    private func showAlert(title: String, message: String) {

        alertLabel.text = message
        dvAlertView.isHidden = false
//        alertLabel.text = ""
        /*
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Ok", style: .default) { (action:UIAlertAction) in
        }
        alertController.addAction(action1)
        self.present(alertController, animated: true, completion: nil)
         */
    }
    @IBAction func apptoAppButtonTapped(_ sender: Any) {
        let alert = UIAlertController(title: "Request", message: "", preferredStyle: .alert)
        alert.addTextField { (textField:UITextField) in
            textField.placeholder = "Enter Request id"
            textField.keyboardType = UIKeyboardType.numberPad
        }
        alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: { (action:UIAlertAction) in
            guard let textField =  alert.textFields?.first else {
                return
            }
            self.launchApp(with: textField.text ?? "")
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    //5571064225
    
    private func launchApp(with requestId: String) {
        let successUrl = "uaepassdemoapp://success"
        let failureUrl = "uaepassdemoapp://failure"
        if let accessToken = userAccessToken {
            let urlString = "uaepass://?action=PRESENTMENT&clientid=UAEPASSCLIENTID&accestoken=\(accessToken)&requesteid=\(requestId)&successurl=\(successUrl)&failureurl=\(failureUrl)"
            
            if let url = URL(string: urlString) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }
        }
    }
}
