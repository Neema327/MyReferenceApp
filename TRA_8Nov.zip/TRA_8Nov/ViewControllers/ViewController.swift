//
//  NewViewController.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 1/2/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import NVActivityIndicatorView
import UIKit
import SwiftEventBus

@objc public class ViewController: UIViewController, NVActivityIndicatorViewable {

    @objc public var uaePassAccessToken: String!
    var accessCode: String?=""

    public override func viewDidLoad() {
         SwiftEventBus.onMainThread(self, name: "performAuth") { result in

         if let result = result, let accessTokenResponseDictionary = result.userInfo, let accessCode = accessTokenResponseDictionary["code"] as? String {
         print("Got code: \(accessCode)")
             self.accessCode = (accessCode)
            }
        }

    }
    public override func viewDidAppear(_ animated: Bool) {

        if let code = accessCode {
            if(code.count > 0) {
                self.startAnimating(message: "Generating Login Token", type: .pacman)
                self.getUaePassTokenForCode(code: code)
            }
        }

    }

    @IBAction func actionLoginWithUaePass(_ sender: Any) {

        //Sai: Need to comment for using authentication with UAE Pass

//        let frameworkLaunchVC = self.storyboard?.instantiateViewController(withIdentifier: "DVFramewokLaunchViewController") as? DVFramewokLaunchViewController
//        if let frameworkLaunchVC = frameworkLaunchVC {
////            frameworkLaunchVC.userProfile = userProfile
////            frameworkLaunchVC.userAccessToken = userToken
//            self.navigationController?.pushViewController(frameworkLaunchVC, animated: true)
//        }

        //Sai: Need to  uncomment for using authentication with UAE Pass
        let webVC = self.storyboard?.instantiateViewController(withIdentifier: "UAEPassWebViewController") as? UAEPassWebViewController
        webVC?.urlString = UAEPassConfiguration.getServiceUrlForType(serviceType: .loginURL)
        webVC?.onUAEPassSuccessBlock = {(code: String?) -> Void in
            if let code = code {
                self.startAnimating(message: "Generating Login Token", type: .pacman)
                self.getUaePassTokenForCode(code: code)
            }
        }
        webVC?.onUAEPassFailureBlock = {(response: String?) -> Void in
        }
        if let viewController = webVC {
            self.navigationController?.pushViewController(viewController, animated: true)
        }

    }

    func getUaePassTokenForCode(code: String) {
        Service.shared.getUAEPassToken(code: code, completion: { (uaePassToken) in
            self.stopAnimating()
            self.accessCode = ""
            if uaePassToken.isEmpty {
                self.showErrorAlert(title: "Error", message: "Unable to get user token, Please try again.")
                return
            }
            self.uaePassAccessToken = uaePassToken
            self.getUaePassProfileForToken(token: uaePassToken)

        }) { (error) in
            self.accessCode = ""
            self.stopAnimating()
            self.showErrorAlert(title: "Error", message: error.rawValue)
        }
    }

    func getUaePassProfileForToken(token: String) {
        Service.shared.getUAEPassUserProfile(token: token, completion: { (userProfile) in
            if let userProfile = userProfile {
                self.showProfileDetails(userProfile: userProfile, userToken: token)
            } else {
                self.showErrorAlert(title: "Error", message: "Couldn't get user profile, Please try again later")
            }
        }) { (error) in
            self.showErrorAlert(title: "Error", message: error.rawValue)
        }
    }

    func showProfileDetails(userProfile: UAEPassUserProfile, userToken: String) {

        let userProfileVC = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileViewController") as? UserProfileViewController
        userProfileVC?.userProfile = userProfile
        userProfileVC?.userToken = userToken
        if let userProfileVC = userProfileVC {
            self.navigationController?.pushViewController(userProfileVC, animated: true)
        } else {
            self.showErrorAlert(title: "Error", message: "Can't find User Profile View, Please check your storyboard")
        }
    }

    func showErrorAlert(title: String, message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Ok", style: .default) { (_: UIAlertAction) in
        }
        alertController.addAction(action1)
        self.present(alertController, animated: true, completion: nil)
    }
}
