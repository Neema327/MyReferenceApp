//
//  UAEPassWebViewController.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 1/2/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import UIKit
import WebKit
import SwiftEventBus

@objc public class UAEPassWebViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet var webViewContainer: UIView!

    public var urlString: String!
    public var onUAEPassSuccessBlock: ((String) -> Void)?
    public var onUAEPassFailureBlock: ((String) -> Void)?

    public override func viewDidLoad() {

        self.title = "UAE PASS"
        let wv = Router.shared.webView
        wv?.navigationDelegate = self
        self.webViewContainer.isHidden = true
        self.view = wv
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        if !self.urlString.isEmpty {
            let url = URL(string: urlString)!
            wv?.load(URLRequest(url: url))
        }

    }

    public func webView(_: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            var action: WKNavigationActionPolicy?
            //sleep(1)
            defer {
                decisionHandler(action ?? .allow)
            }
            //print("webview")
            let url = navigationAction.request.url
            guard let urlString = navigationAction.request.mainDocumentURL?.absoluteString else { return }

            if urlString.contains("error=access_denied") {
                self.navigationController?.popViewController(animated: true)
            } else if urlString.contains(UAEPAssParams.redirectUriLogin.get()) && urlString.contains("code=") {
                if let url = url, let token = url.valueOf("code") {
                    print(token)
                    print("### code Recieved : \(urlString)")
                    //if onUAEPassSuccessBlock != nil && !token.isEmpty {

                    //onUAEPassSuccessBlock?(token)

                    let websiteDataTypes = WKWebsiteDataStore.allWebsiteDataTypes()
                    let cdate = NSDate(timeIntervalSince1970: 0)

                    WKWebsiteDataStore.default().removeData(ofTypes: websiteDataTypes, modifiedSince: cdate as Date, completionHandler: {
                        print("remove all data in wkwbeview")
                    })

                    var apiResonseDictionary = [String: Any]()
                    apiResonseDictionary["code"] = token
                    SwiftEventBus.post("performAuth", userInfo: apiResonseDictionary)
                    self.navigationController?.popViewController(animated: true)
                    //}
                }
            } else if urlString.contains(UAEPAssParams.uaePassSchemeURL.get()) {
                // isUAEPassOpened = true
                let listItems = urlString.components(separatedBy: "successurl")
                if listItems.count > 0 {
                    if let customScheme = listItems.first {
                        let paprelessSchemeSuccess = HandleURLScheme.externalURLSchemeSuccess()
                        let paprelessSchemeFail = HandleURLScheme.externalURLSchemeFail()
                        let urlScheme = "\(customScheme)successurl=\(paprelessSchemeSuccess)&failureurl=\(paprelessSchemeFail)&closeondone=true"
                        print("urlScheme: \(urlScheme)")
                        if UIApplication.shared.canOpenURL(URL(string: urlScheme)!) {
                            HandleURLScheme.openCustomApp(fullUrl: urlScheme)
                        }
                    }
                }
            }
        })

    }
}
