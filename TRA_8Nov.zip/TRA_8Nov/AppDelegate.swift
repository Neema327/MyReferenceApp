//
//  AppDelegate.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 1/3/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import UIKit
import SwiftEventBus
import DigitalVaultFramework

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    static let shared = UIApplication.shared.delegate as? AppDelegate
    var window: UIWindow?

    func application(_: UIApplication, handleOpen url: URL) -> Bool {
        print("<><><><> appDelegate URL : \(url.absoluteString)")
        if url.absoluteString.contains(HandleURLScheme.externalURLSchemeSuccess()) {
            return true
        } else if url.absoluteString.contains(HandleURLScheme.externalURLSchemeFail()) {
            let alertController = UIAlertController(title: "UAE Pass", message: "Failed with UAE PASS Login, Would you like to try again ?", preferredStyle: .actionSheet)
            let okAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default) { _ in
                NSLog("OK Pressed")
            }
            let cancelAction = UIAlertAction(title: "No", style: UIAlertAction.Style.cancel) { _ in
                NSLog("Cancel Pressed")
            }
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)

            self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
            return false
        }
        return true
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {

        DVEventHandler.sharedInstance.loadEventHandler()

        return true
    }
}
