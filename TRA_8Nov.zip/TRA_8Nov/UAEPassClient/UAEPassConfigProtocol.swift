//
//  UAEPassConfigProtocol.swift
//
//  Created by Syed Absar Karim on 11/4/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import Foundation

protocol UAEPassConfigProtocol {

    // MARK: **** UAE Pass Configuration ****

    var uaePassBaseURL: String { get }
    var clientID: String { get }
    var clientPass: String { get }

}
