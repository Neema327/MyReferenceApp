//
//  Configuration+UAEPassSigning.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 10/22/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import Foundation
import UIKit
//1 - Generate the token
// trustedx-authserver/oauth/main-as/token
//2 - Upload the file with it's properties to be signed
// trustedx-resources/esignsp/v2/signer_processes
//3 Open it in the browser (form tasks.pending.url which received from previous step)  :
// trustedx-resources/esignsp/v2/ui?signerProcessId=4cbhkk9afnceq0ebevs0s7be1el33rbn
//4 Download signed dowcument.
// trustedx-resources/esignsp/v2/documents/dngo2mlsng3h6qn48jv2msuc7264aovl/content
//5 - Delete signed document.
// trustedx-resources/esignsp/v2/signer_processes/unab297j63dl44umiu3n6d42h0vr88m1
// User Profile
//trustedx-resources/openid/v1/users/me

public enum UAEPAssParams: String {

    case responseType = "code"
    case loginScope = "urn:uae:digitalid:profile"
    case signScope = "urn:safelayer:eidas:sign:process:document"
    case state = "UzkLPOzcsHs4SL9cNZ7bFATd" //Randomly Generated Code 24 alpha numeric.

    case uaePassSchemeURL = "uaepass://"
    case successSchemeURL = "uaePassSuccess://"
    case failSchemeURL = "uaePassFail://"

    case acrValuesAppToApp = "urn:digitalid:authentication:flow:mobileondevice"
    case acrValuesWebView = "urn:safelayer:tws:policies:authentication:level:low"

    case redirectUriLogin = "https://oauthtest.com/authorization/return"
    case redirectUriSign = "https://oauthtest.com/sign/return"

    public func get() -> String {
        return rawValue
    }
}

public enum UAEPassServiceType: String {
    case loginURL
    case userProfileURL
    case token
    case uploadFile
    case downloadFile
    case deleteFile

    public func getRequestType() -> String? {
        switch self {
        case .token : return "POST"
        case .userProfileURL: return "GET"
        case .uploadFile : return "POST"
        case .downloadFile: return "GET"
        case .deleteFile: return "DELETE"
        case .loginURL: return nil
        }
    }

    public func getContentType() -> String? {
        switch self {
        case .token : return "application/x-www-form-urlencoded"
        case .userProfileURL : return "application/x-www-form-urlencoded"
        case .uploadFile : return "multipart/form-data"
        case .downloadFile: return nil
        case .deleteFile: return nil
        case .loginURL: return nil
        }
    }

}
public struct UAEPassConfiguration {

    static let isQAUAEPass = false
    static let isDevUAEPass = false
    static var isProdUAEPass = true

    public static func getServiceUrlForType(serviceType: UAEPassServiceType) -> String {
        let baseURL = Router.shared.uaePassConfig.uaePassBaseURL
        switch serviceType {
        case .loginURL:
            var serviceUrl = baseURL + "trustedx-authserver/oauth/main-as?"
            serviceUrl += "redirect_uri=" + UAEPAssParams.redirectUriLogin.get()
            serviceUrl += "&client_id=" + Router.shared.uaePassConfig.clientID
            serviceUrl += "&response_type=" + UAEPAssParams.responseType.get()
            serviceUrl += "&state=" + UAEPAssParams.state.get()
            serviceUrl += "&scope=" + UAEPAssParams.loginScope.get()

            //Check If UAE Pass App is installed to redirect, otherwise open AppStore Link.
            let schemeString = UAEPAssParams.uaePassSchemeURL.get()
            if UIApplication.shared.canOpenURL(URL(string: schemeString)!) {
                serviceUrl += "&acr_values=" + UAEPAssParams.acrValuesAppToApp.get()
            } else {
                serviceUrl += "&acr_values=" + UAEPAssParams.acrValuesWebView.get()
            }
            return serviceUrl
        case .token:
            return baseURL + "trustedx-authserver/oauth/main-as/token"
        case .userProfileURL:
            return baseURL + "trustedx-resources/openid/v1/users/me"
        case .uploadFile:
            return baseURL + "trustedx-resources/esignsp/v2/signer_processes"
        case .downloadFile:
            return baseURL + "trustedx-resources/esignsp/v2/documents/"
        case .deleteFile:
            return baseURL + "trustedx-resources/esignsp/v2/signer_processes/"
        }
    }
}
