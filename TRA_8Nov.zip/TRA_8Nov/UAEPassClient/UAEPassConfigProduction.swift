//
//  UAEPassConfigQA.swift
//
//  Created by Mohammed Gomaa on 11/19/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import UIKit

class UAEPassConfigProduction: UAEPassConfigProtocol {
    // MARK: **** UAE Pass Configuration ****
    var uaePassBaseURL = "https://id.uaepass.ae/"
    var clientID = "" // Add your own client ID
    var clientPass = "" // Add your own client pass

}
