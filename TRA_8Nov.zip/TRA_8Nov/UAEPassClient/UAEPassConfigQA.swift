//
//  UAEPassConfigQA.swift
//
//  Created by Mohammed Gomaa on 11/19/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import UIKit

class UAEPassConfigQA: UAEPassConfigProtocol {

    // MARK: **** UAE Pass Configuration ****
    var uaePassBaseURL = "https://qa-id.uaepass.ae/"
    var clientID = "digivault_stage" // Add your own client ID
    var clientPass = "bDC5XeZDABdETzn" // Add your own client pass

}
