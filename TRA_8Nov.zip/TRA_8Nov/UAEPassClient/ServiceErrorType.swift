//
//  ErrorType.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 9/26/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import Foundation

public enum ServiceErrorType: String {
    case optionaWrappingError             = "optionaWrappingError"
    case unAuthorizedUAEPassResolved      = "UnAuthorizedUAEPassResolved"
    case unknown                          = "Unknown"
    case unAuthorizedUAEPass              = "UnAuthorizedUAEPass"
    case userNotVerifiedUAEPass
}
