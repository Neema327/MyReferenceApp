//
//  UploadSignDocumentResponse.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 10/22/18.
//  Copyright © 2018 Mobile DevOps. All rights reserved.
//

import Foundation
struct UploadSignDocumentResponse: Codable {
    let processType: String?
    let processID: String?
    let selfURL: String?
    let tasks: Tasks?
    let documents: [Documents]?

    enum CodingKeys: String, CodingKey {
        case processType = "process_type"
        case processID = "id"
        case selfURL = "self"
        case tasks
        case documents
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        processType = try values.decodeIfPresent(String.self, forKey: .processType)
        processID = try values.decodeIfPresent(String.self, forKey: .processID)
        selfURL = try values.decodeIfPresent(String.self, forKey: .selfURL)
        tasks = try values.decodeIfPresent(Tasks.self, forKey: .tasks)
        documents = try values.decodeIfPresent([Documents].self, forKey: .documents)
    }
}

struct Tasks: Codable {
    let pending: [Pending]?

    enum CodingKeys: String, CodingKey {
        case pending
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        pending = try values.decodeIfPresent([Pending].self, forKey: .pending)
    }

}

struct Documents: Codable {
    let docID: String?
    let url: String?
    let content: String?

    enum CodingKeys: String, CodingKey {
        case docID = "id"
        case url
        case content
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        docID = try values.decodeIfPresent(String.self, forKey: .docID)
        url = try values.decodeIfPresent(String.self, forKey: .url)
        content = try values.decodeIfPresent(String.self, forKey: .content)
    }

}

struct Pending: Codable {
    let type: String?
    let pendingID: String?
    let url: String?

    enum CodingKeys: String, CodingKey {
        case type
        case pendingID = "id"
        case url
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        pendingID = try values.decodeIfPresent(String.self, forKey: .pendingID)
        url = try values.decodeIfPresent(String.self, forKey: .url)
    }
}
