//
//  UAEPassToken.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 1/2/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import Foundation

struct UAEPassToken: Codable {
    let scope: String?
    let tokenType: String?
    let accessToken: String?
    let expiresIn: Int?
    let idToken: String?

    let error: String?
    let errorDescription: String?

    enum CodingKeys: String, CodingKey {
        case scope
        case tokenType = "token_type"
        case accessToken = "access_token"
        case expiresIn = "expires_in"
        case idToken = "id_token"
        case error
        case errorDescription = "error_description"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        scope = try values.decodeIfPresent(String.self, forKey: .scope)
        tokenType = try values.decodeIfPresent(String.self, forKey: .tokenType)
        accessToken = try values.decodeIfPresent(String.self, forKey: .accessToken)
        expiresIn = try values.decodeIfPresent(Int.self, forKey: .expiresIn)
        idToken = try values.decodeIfPresent(String.self, forKey: .idToken)
        error = try values.decodeIfPresent(String.self, forKey: .error)
        errorDescription = try values.decodeIfPresent(String.self, forKey: .errorDescription)
    }
}
