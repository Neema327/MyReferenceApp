//
//  UAEPassUserProfile.swift
//  UaePassDemo
//
//  Created by Mohammed Gomaa on 1/2/19.
//  Copyright © 2019 Waqas Qadeer Soomro. All rights reserved.
//

import Foundation

struct UAEPassUserProfile: Codable {
    let uuid: String?
    let acr: String?
    let idCardExpiryDate: String?
    let mobile: String?
    let nationalityEN: String?
    let dob: String?
    let domain: String?
    let userType: String?
    let firstnameEN: String?
    let sub: String?
    let lastnameEN: String?
    let email: String?
    let gender: String?
    let homeAddressEmirateCode: String?
    let amr: [String]?
    let idn: String?

    enum CodingKeys: String, CodingKey {
        case uuid
        case acr
        case idCardExpiryDate
        case mobile
        case nationalityEN
        case dob
        case domain
        case userType
        case firstnameEN
        case sub
        case lastnameEN
        case email
        case gender
        case homeAddressEmirateCode
        case amr
        case idn

    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        uuid = try values.decodeIfPresent(String.self, forKey: .uuid)
        acr = try values.decodeIfPresent(String.self, forKey: .acr)
        idCardExpiryDate = try values.decodeIfPresent(String.self, forKey: .idCardExpiryDate)
        mobile = try values.decodeIfPresent(String.self, forKey: .mobile)
        nationalityEN = try values.decodeIfPresent(String.self, forKey: .nationalityEN)
        dob = try values.decodeIfPresent(String.self, forKey: .dob)
        domain = try values.decodeIfPresent(String.self, forKey: .domain)
        userType = try values.decodeIfPresent(String.self, forKey: .userType)
        firstnameEN = try values.decodeIfPresent(String.self, forKey: .firstnameEN)
        sub = try values.decodeIfPresent(String.self, forKey: .sub)
        lastnameEN = try values.decodeIfPresent(String.self, forKey: .lastnameEN)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        gender = try values.decodeIfPresent(String.self, forKey: .gender)
        homeAddressEmirateCode = try values.decodeIfPresent(String.self, forKey: .homeAddressEmirateCode)
        amr = try values.decodeIfPresent([String].self, forKey: .amr)
        idn = try values.decodeIfPresent(String.self, forKey: .idn)
    }
}
